# 2FA Verification App [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/App-2.1)

**Author:** Kamran Khalid

## Table of Contents

- [Introduction](#introduction)
- [Route](#route)
- [Flow Diagram](#flow-diagram)
- [Method: verifyAppTwoFactorAuthV1](#method-verifyapptwofactorauthv1)

## Introduction

This API endpoint is used in the login process to verify a user's two-factor authentication and perform additional actions based on the user's status and other conditions.

## Route

`/auth/2fa-verification-app`

## Flow Diagram

```mermaid
graph TD;
    A[Start] --> B[User Retrieval];
    B -->|User Not Found| C[Invalid Response];
    B -->|User Found, No Related CustomerUser or CustomerUserCustomer| D[Not Found Response];
    B -->|User Found, Has Related CustomerUser and CustomerUserCustomer| E[App Action Determination];
    E -->|App Action is 'CUSTOMER_LOGIN'| F[Two-Factor Authentication Verification];
    F -->|Verification Fails| G[ApiValidationException];
    F -->|Verification Succeeds| H[Trusted Device Registration];
    H --> I[Registration Token Generation];
    I --> J[KYC Documents Token Generation];
    J --> K[KYC Start Tracking];
    K --> L[Delivery Days Calculation];
    L --> M[Success Response];
    C --> N[End];
    D --> N;
    G --> N;
    M --> N;
```

## Method: `verifyAppTwoFactorAuthV1`

This method performs the following steps:

1. **User Retrieval**: It attempts to retrieve a user based on the 'login' field from the request data. The user must also have a related `customerUser`.

2. **User Verification**: If no user is found, it returns an invalid response as a protection against username guessing. If a user is found but does not have a related `customerUser` or `customerUserCustomer`, it returns a not found response.

3. **App Action Determination**: It determines the next app action based on the customer status and other conditions. If the app action is 'CUSTOMER_LOGIN', it verifies the two-factor authentication for the portal.

4. **Two-Factor Authentication Verification**: It retrieves the latest two-factor authentication request for the user and verifies it. If the verification fails, it throws an `ApiValidationException`.

5. **Trusted Device Registration**: It registers the user's trusted device. This is done using the `registerUserTrustedDevice` method of the `UsersService` class.

6. **Registration Token Generation**: It generates a new registration token for the user and updates the user's `customerUser` with the new token and its expiration time. It also keeps a history of revoked tokens.

7. **KYC Documents Token Generation**: If the user does not have a KYC documents token, it generates a new one and updates the user's `customerUser` with the new token and its expiration time.

8. **KYC Start Tracking**: If the user is the main applicant or a shareholder/partner and has not started KYC, it sets the `kyc_started_at` field to the current time and saves the changes. It also processes the first login of the seller customer if the user is the main applicant.

9. **Delivery Days Calculation**: It calculates the delivery days for each of the user's addresses. This is done using the `getDeliveryDaysForAddress` method of the `CustomerDeliveryService` class.

10. **Success Response**: It returns a successful response with the verification status, registration token, KYC documents token, default customer, applicant, additional KYC, shareholders invite message, and branding.

## **Next Step > [Complete Flow Diagram](diagram.md)**

*For a complete flow diagram of the App 2.1 API, please refer to the [diagram.md](diagram.md) file.*

**[⬆ back to top](#table-of-contents)**
