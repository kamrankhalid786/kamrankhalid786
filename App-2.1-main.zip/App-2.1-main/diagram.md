# Application Flow Diagram

This diagram represents the flow of operations in the application. Each node represents a step in the process, and the arrows indicate the direction of flow. The flow starts at the 'Start' node and ends at the 'End' node.

```mermaid
graph TD;
    A[Start] --> B{App Version Validation};
    B -->|Valid| C[User Retrieval];
    B -->|Invalid| D[Return 'INVALIDATED APP VERSION'];
    C -->|User Found| E[Portal Determination];
    C -->|User Not Found| F[Fake Response];
    E --> G[Return Portal Information];
    F --> H[Return Fake Success];
    G --> I[End];
    H --> I;
    D --> J[End];

    I --> K[User Retrieval];
    K -->|User Found| L[Customer User Retrieval];
    K -->|User Not Found| M[Fake Response];
    L -->|Customer User Found| N[App Action Determination];
    L -->|Customer User Not Found| O[Return 'Not Found'];
    N --> P[2FA];
    P -->|App Action is 'CUSTOMER_LOGIN'| Q[Initiate 2FA];
    P -->|App Action is not 'CUSTOMER_LOGIN'| R[Initiate 2FA unless login starts with '+52'];
    M --> S[End];
    Q --> T[Success Response];
    R --> T;
    O --> U[End];

    T --> V[Variable Initialization];
    V --> W{Additional KYC Check};
    W -->|Additional KYC Awaiting| X[Return 'CUSTOMER_REGISTRATION_ADDITIONAL_KYC'];
    W -->|No Additional KYC| Y{Main Applicant Check};
    Y -->|Main Applicant| Z[Return Appropriate Action];
    Y -->|Not Main Applicant| AA{Shareholder/Partner Check};
    AA -->|Shareholder/Partner| AB[Return 'CUSTOMER_REGISTRATION_PARTNER_SHAREHOLDER'];
    AA -->|Not Shareholder/Partner| AC{Active Customer Check};
    AC -->|Active Customer| AD[Return Appropriate Action];
    AC -->|Not Active Customer| AE[Return 'ACTION_NOT_DEFINED'];
    X --> AF[End];
    Z --> AF;
    AB --> AF;
    AD --> AF;
    AE --> AF;

    AF --> AG[User Retrieval];
    AG -->|User Found| AH[Pre-Login Actions];
    AG -->|User Not Found| AI[Fake Response];
    AH --> AJ{2FA Check};
    AJ -->|Requires 2FA| AK[Initiate 2FA];
    AJ -->|Does Not Require 2FA| AL[Success Response];
    AI --> AM[End];
    AK --> AN[End];
    AL --> AN;

    AN --> AO[User Retrieval];
    AO -->|User Not Found| AP[Invalid Response];
    AO -->|User Found, No Related CustomerUser or CustomerUserCustomer| AQ[Not Found Response];
    AO -->|User Found, Has Related CustomerUser and CustomerUserCustomer| AR[App Action Determination];
    AR -->|App Action is 'CUSTOMER_LOGIN'| AS[2FA Verification];
    AS -->|Verification Fails| AT[ApiValidationException];
    AS -->|Verification Succeeds| AU[Trusted Device Registration];
    AU --> AV[Registration Token Generation];
    AV --> AW[KYC Documents Token Generation];
    AW --> AX[KYC Start Tracking];
    AX --> AY[Delivery Days Calculation];
    AY --> AZ[Success Response];
    AP --> BA[End];
    AQ --> BA;
    AT --> BA;
    AZ --> BA;
```
