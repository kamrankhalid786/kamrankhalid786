# User Check App [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/App-2.1)

**Author:** Kamran Khalid

## Table of Contents

- [Introduction](#introduction)
- [Route](#route)
- [Flow Diagram: loginAppCheckUserV1](#flow-diagram-loginappcheckuserv1)
- [Flow Diagram: getAppAction](#flow-diagram-getappaction)
- [Method: loginAppCheckUserV1](#method-loginappcheckuserv1)
- [Method: getAppAction](#method-getappaction)

## Introduction

This API endpoint is used in the login process to check a user's login credentials, determine the appropriate app action, and initiate two-factor authentication if necessary.

## Route

`/auth/user-check-app`

## Flow Diagram: `loginAppCheckUserV1`

```mermaid
graph TD;
    A[Start] --> B[User Retrieval];
    B -->|User Found| C[Customer User Retrieval];
    B -->|User Not Found| D[Fake Response];
    C -->|Customer User Found| E[App Action Determination];
    C -->|Customer User Not Found| F[Return 'Not Found'];
    E --> G[Two-Factor Authentication];
    G -->|App Action is 'CUSTOMER_LOGIN'| H[Initiate Two-Factor Authentication];
    G -->|App Action is not 'CUSTOMER_LOGIN'| I[Initiate Two-Factor Authentication unless login starts with '+52'];
    D --> J[End];
    H --> K[Success Response];
    I --> K;
    F --> L[End];
```

## Flow Diagram: `getAppAction`

```mermaid
graph TD;
    A[Start] --> B[Variable Initialization];
    B --> C{Additional KYC Check};
    C -->|Additional KYC Awaiting| D[Return 'CUSTOMER_REGISTRATION_ADDITIONAL_KYC'];
    C -->|No Additional KYC| E{Main Applicant Check};
    E -->|Main Applicant| F[Return Appropriate Action];
    E -->|Not Main Applicant| G{Shareholder/Partner Check};
    G -->|Shareholder/Partner| H[Return 'CUSTOMER_REGISTRATION_PARTNER_SHAREHOLDER'];
    G -->|Not Shareholder/Partner| I{Active Customer Check};
    I -->|Active Customer| J[Return Appropriate Action];
    I -->|Not Active Customer| K[Return 'ACTION_NOT_DEFINED'];
    D --> L[End];
    F --> L;
    H --> L;
    J --> L;
    K --> L;
```

### Method: `loginAppCheckUserV1`

This method performs the following steps:

1. **User Retrieval**: It attempts to retrieve a user based on the 'login' field from the request data. This is done using the `whereEncrypted` method of the `User` model. The user must also have a related `customerUser`.

2. **Fake Response**: If no user is found, it returns a fake success response. This is done to protect against username guessing. The response includes a fake two-factor authentication request ID, an app action of 'CUSTOMER_LOGIN', and various other user and customer status information.

3. **Customer User Retrieval**: If a user is found, it retrieves the related `customerUser` and the default `customerUserCustomer`. If neither of these are found, it returns a 'not found' response.

4. **App Action Determination**: It determines the app action based on the customer status, the customer user, the customer user customer, and whether the customer user customer is the main user. This is done using the `getAppAction` method.

5. **Two-Factor Authentication**: If the app action is 'CUSTOMER_LOGIN' and the user requires two-factor authentication, it initiates a two-factor authentication request. If the app action is not 'CUSTOMER_LOGIN', it initiates a two-factor authentication request unless the login starts with '+52', in which case it uses a hardcoded request ID of '12345678'. The two-factor authentication request is done using the `secondFactorLogin: JWT Token` method.

6. **Success Response**: It returns a successful response that includes the two-factor authentication request ID and method, the app action, whether KYC is required, whether the customer user customer is the main user, the user status, and the customer status.

### Method: `getAppAction`

This method in the `LoginController` class is used to determine the next action for the app based on the customer status, customer user, customer, and whether the customer user is the main user. It performs the following steps:

- **Variable Initialization**: It initializes several variables based on the `customerUser` and `customer` parameters. These variables include whether KYC (Know Your Customer) is required, the user status, whether the customer user is a shareholder, whether KYC is done, and whether additional KYC is awaiting.

- **Additional KYC Check**: If additional KYC is awaiting and the customer status is either 'AWAITING_COMPLETION' or 'AWAITING_ACTIVATION', it returns 'CUSTOMER_REGISTRATION_ADDITIONAL_KYC'.

- **Main Applicant Check**: If the customer status is 'AWAITING_MAIN_COMPLETION', it checks whether the customer user is the main user and whether KYC is required. Depending on these conditions, it returns 'CUSTOMER_REGISTRATION_MAIN_APPLICANT', 'CUSTOMER_REGISTRATION_MAIN_APPLICANT_WITHOUT_KYC', 'CUSTOMER_REGISTRATION_PARTNER_SHAREHOLDER', or 'CUSTOMER_LOGIN'.

- **Shareholder/Partner Check**: If the customer status is 'AWAITING_COMPLETION', the customer user is a shareholder, and KYC is not done, it returns 'CUSTOMER_REGISTRATION_PARTNER_SHAREHOLDER'.

- **Active Customer Check**: If the customer status is 'AWAITING_COMPLETION' or higher, it checks the user status and whether KYC is required and done. Depending on these conditions, it returns 'CUSTOMER_LOGIN', 'CUSTOMER_USER_ACCOUNT_ACTIVATION', or 'CUSTOMER_USER_ACCOUNT_ACTIVATION'.

- **Default Action**: If none of the above conditions are met, it returns 'ACTION_NOT_DEFINED'.

## **Next Step > [User Check](user-check.md)**

*For a complete flow diagram of the App 2.1 API, please refer to the [diagram.md](diagram.md) file.*

**[⬆ back to top](#table-of-contents)**
