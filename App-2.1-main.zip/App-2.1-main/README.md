# App-2.1 API Documentation

Welcome to the ✨ _*App 2.1 Api documentation_ ✨ repository. This repository contains the API documentation for App 2.1.

## Table of Contents

1. [User Check Login](user-check-login.md)
    - [Code Flow Diagram](user-check-login.md#flow-diagram)
2. [User Check App](user-check-app.md)
    - [Code Flow Diagram: loginAppCheckUserV1](user-check-app.md#flow-diagram-loginappcheckuserv1)
    - [Code Flow Diagram: getAppAction](user-check-app.md#flow-diagram-getappaction)
3. [User Check](user-check.md)
    - [Code Flow Diagram](user-check.md#flow-diagram)
4. [2FA Verification App](2fa-verification-app.md)
    - [Code Flow Diagram](2fa-verification-app.md#flow-diagram)

## Complete Flow Diagram

For a complete flow diagram of the App 2.1 API, please refer to the [diagram.md](diagram.md) file.

![App-2.1 Flow Diagram](app-2.1.png)

## About the Author

Hello, I'm Kamran Khalid. Here's a bit about me:

- 🔭 I’m currently working on V9 FinTech products.
- 🌱 I’m learning Go language.
- 👯 I’m interested in collaborating on open-source AI models.
- 🤔 I’m looking for help with ?? 🐬
- 📫 You can reach me at <kamrankhalid06@gmail.com>.
- ⚡ Fun fact: I love to play cricket and watch movies.
