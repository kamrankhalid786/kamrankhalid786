# User Check [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/App-2.1)

**Author:** Kamran Khalid

## Table of Contents

- [Introduction](#introduction)
- [Route](#route)
- [Flow Diagram](#flow-diagram)
- [Method: loginCheckUserV1](#method-logincheckuserv1)

## Introduction

This API endpoint is used in the login process to check a user's login credentials and initiate two-factor authentication if necessary.

## Route

`/auth/user-check`

## Flow Diagram

```mermaid
graph TD;
    A[Start] --> B[User Retrieval];
    B -->|User Found| C[Pre-Login Actions];
    B -->|User Not Found| D[Fake Response];
    C --> E{Two-Factor Authentication Check};
    E -->|Requires Two-Factor Authentication| F[Initiate Two-Factor Authentication];
    E -->|Does Not Require Two-Factor Authentication| G[Success Response];
    D --> H[End];
    F --> I[End];
    G --> I;
```

## Method: `loginCheckUserV1`

This method performs the following steps:

1. **User Retrieval**: It attempts to retrieve a user based on the 'login' field from the request data. This is done using the `whereEncrypted` method of the `User` model. The user must also have a related `customerUser`.

2. **Fake Response**: If no user is found, it returns a fake success response. This is done to protect against username guessing. The response includes a fake two-factor authentication request ID and method.

3. **Pre-Login Actions**: If a user is found, it performs any necessary actions before login. This is done using the `beforeLogin` method of the `User` model.

4. **Two-Factor Authentication**: If the user requires two-factor authentication, it initiates a two-factor authentication request. This is done using the `secondFactorLogin` method. The response includes the two-factor authentication request ID and method.

5. **Success Response**: If the user does not require two-factor authentication, it returns a successful response with a null two-factor authentication request.

## **Next Step > [2FA Verification App](2fa-verification-app.md)**

*For a complete flow diagram of the App 2.1 API, please refer to the [diagram.md](diagram.md) file.*

**[⬆ back to top](#table-of-contents)**
