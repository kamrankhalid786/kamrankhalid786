# v1/user-check-login [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/App-2.1)

**Author:** Kamran Khalid

## Table of Contents

- [Introduction](#introduction)
- [Route](#route)
- [Flow Diagram](#flow-diagram)
- [Method: checkLoginBelongsToWhichPortalV1](#method-checkloginbelongstowhichportalv1)

## Introduction

This API endpoint is used to check which portal a login belongs to.

## Route

`/v1/user-check-login`

## Flow Diagram

```mermaid
graph TD;
    A[Start] --> B{App Version Validation};
    B -->|Valid| C[User Retrieval];
    B -->|Invalid| D[Return 'INVALIDATED APP VERSION'];
    C -->|User Found| E[Portal Determination];
    C -->|User Not Found| F[Fake Response];
    E --> G[Return Portal Information];
    F --> H[Return Fake Success];
    G --> I[End];
    H --> I;
    D --> J[End];
```

## Method: checkLoginBelongsToWhichPortalV1

This method performs the following steps:

1. **App Version Validation**: If the request is coming from a mobile app, it checks if the app version is valid. If the app version is not valid, it returns an error response with the message 'INVALIDATED APP VERSION'.

2. **User Retrieval**: It attempts to retrieve a user based on the 'login' field from the request data. This is done using the `getUserByLogin` method of the `userCheckApiService`.

3. **Fake Response**: If no user is found, it returns a fake success response. This is done to protect against username guessing. The response indicates that the login belongs to either the customer portal or the partner portal, chosen randomly.

4. **Portal Determination**: If a user is found, it determines whether the user belongs to the customer portal, the partner portal, or both. This is done using the `customerUserCustomerExist` and `partnerUserExist` methods of the `userCheckApiService`. The response includes this information.

## **Next Step > [User Check App](user-check-app.md)**

*For a complete flow diagram of the App 2.1 API, please refer to the [diagram.md](diagram.md) file.*

**[⬆ back to top](#table-of-contents)**
