## Send Finance Agreement with `SendFinanceAgreementsCronJob`

**Author:** Anouar

### Table of Contents
- [Overview](#overview)
- [Code Process](#code-process)
  -  [Prepare Agreement to be Sent](#prepare-agreement-to-be-sent)
  -  [Send Company Data to First Data](#send-company-data-to-first-data)
     - [JSON Format Process Description](#json-format-process-description)
     - [Emailing Documents Process Description](#emailing-documents-process-description)

### Overview

When `BamboraSubmerchantService@processEnrollmentResults` is invoked, we process the **Bambora** results and approve the submerchant. We set the `CustomerMid` `mid`, and then the event `CustomerMidApproved` is fired, triggering the listener `OnCustomerMidApproved`. This listener, in turn, invokes the function `midApproved` under `CustomerMidService`, which dispatches the job `SendFinanceAgreementsCronJob`.

### Code Process

1. Dispatching the job `SendFinanceAgreementsCronJob` will execute the `SendFinanceAgreementsCron` command:
   - Fetch all the `CustomerFinanceAgreement` with the following conditions:
     - **attention is free** and the `status` `READY_TO_SEND_DATA` or `NEW`
     - Has at least one `CustomerContract` that belongs to an **active** customer with no shareholder applicants who did not complete their KYC.
     - Has at least one `CustomerContract` that has `CustomerProduct` that has **approved mids**
   - For each `CustomerFinanceAgreement` we will take the following actions:
     - IF its `status` is equal to `NEW`, the `CustomerFinanceService@prepareAgreementToBeSent` is invoked which prepares the agreement document. The details on how this is processed will be covered under [Prepare Agreement to be Sent](#prepare-agreement-to-be-sent).
     - IF its `status` is equal to `READY_TO_SEND_DATA`, the `CustomerFinanceService@sendToFinanceCompany` is invoked which sends finance company data to FirstData. The details on how this is processed will be covered under [Send Company Data to FirstData](#send-company-data-to-first-data).

#### Prepare Agreement to be Sent

When this function is invoked by calling `CustomerFinanceService@prepareAgreementToBeSent`, the following actions will be taken:

1. Generate the PDF file for the first `CustomerFinanceAgreement` and return the `CustomerDocument` attached to it. Check the process below:
   - Fetch `CustomerContract` from the `CustomerFinanceAgreement` instance.
   - Fetch `Customer` from the `CustomerContract`.
   - Fetch the `docType` details (static array) from `CustomerDocType` class using the `FINANCE_AGREEMENT` ID.
   - Prepare file data and return it:
     - Fetch the latest `CustomerProduct` within the given `customer_contract_id`.
     - Fetch all `CustomerStandardFee` which are only chargeable for `CHARGED_WITHIN_FINANCE` within the given `customer_contract_id`.
     - Fetch `CustomerContract` from the `CustomerFinanceAgreement` instance.
     - Fetch the `contract_length` from the `CustomerContract` instance.
     - For all the fetched `CustomerProduct`, build a `productData` by taking the following actions:
       - Assign the product name depending on the product code:
         - IF `PAX_A920_MOBILE` product name will be assigned to `PAX A920 Pro (Wifi/GPRS)`.
         - IF `PAX_A920_CHARGING_CRADLE` will be assigned to `PAX A920 Pro cradle`.
         - IF `VIRTUAL_TERMINAL` or `PAY_BY_LINK` will be assigned to `Payment Gateway`.
       - Fill the product info within the `productsData` list, which is a 2D array. It will be keyed using the `index` of the current product, with each value being an associative array containing the following keys: `name`, `price`, `qty`, and `vat`. If a product with the same name has already been added, accumulate the price. Additionally, if the product is not equal to `Payment Gateway`, accumulate the quantity as well.

     ```php
     $productData = [
        0 => [
            'name' => ,
            'price' => ,
            'qty' => ,
            'vat' => ,
        ],
        1 => [
            'name' => ,
            'price' => ,
            'qty' => ,
            'vat' => ,
        ],
        //...
     ]
     ```

     - Loop over all the fetched `CustomerStandardFee` and add the `PCI_PLUS` details to the `productsData`.
     - Fetch the customer `businessAddress`, `deliveryAddress`, `country`, `applicants`, `authorizedSignerFullName` and `yearsOfBusiness` which will be used to build the data needed for generating the finance agreement file.
     - The initial `data` list (associative array) will contain the following details:

        | Field                                  | Value                                                 |
        |----------------------------------------|-------------------------------------------------------|
        | agreement_reference                    | 20170301PIABTC                                        |
        | Trading Name if different_es_:signer   | $this->formatTradingName($customer->trading_name)     |
        | Merchant Business Name_es_:signer      | $customer->legal_name                                 |
        | Address Line 1_es_:signer              | $businessAddress->getFullStreetAddress(true)          |
        | Address Line 2 optional_es_:signer     | $businessAddress->address_line_1                      |
        | TownCity_es_:signer                    | $businessAddress->city                                |
        | Postcode_es_:signer                    | $businessAddress->postcode                            |
        | Country_es_:signer                     | $country->name                                        |
        | Business Phone number_es_:signer1      | $customer->primary_contact_phone                      |
        | Business Website_es_:signer            | $customer->website_url                                |
        | Email Address_es_:signer               | $customer->primary_contact_email                      |
        | Years in Business_es_:signer           | $yearsOfBusiness                                      |
        | Minimumterm_es_:prefill                | ContractLengthModel::getMonths($contactLength)        |
        | Onsite Installation Payment_es_:prefill| 0                                                     |
        | Signature of Merchant_es_:signer       | $authorizedSignerFullName                             |
        | Signature of Merchant_es_:signer:Date  | $customerContract->signed_at?->format('d/m/Y')        |
        | Signature of Merchant_es_:signer:device_id| $signPack->signed_on_device_id                     |
        | Company Registration Number_es_:signer | $customer->registration_number                        |
        | VAT No_es_:signer                      | $customer->vat_number                                 |
        | Contact Name_es_:signer:fullname       | $authorizedSignerFullName                             |
        | Position_es_:signer                    | $applicants->occupation                               |
        | Installation Address_es_:signer        | $applicants->phone                                    |
        | Contact Phone Number_es_:signer        | $deliveryAddress                                      |
        | Account holder name_es_:signer         | $bankAccount->account_name                            |
        | Account number_es_:signer              | $bankAccount->account_number                          |
        | Sortcode_es_:signer                    | $bankAccount->sort_code                               |
        | Bank Name                              | $bankAccount->bank_name                               |
        | Date                                   | $todayDateFormatted                                   |
        | Bank address1_es_:signer               | $bankAccount->bank_address                            |
        | Post Code_es_:signer                   | $bankAccount->bank_zip                                |
        | Signature                              |                                                       |
        | image                                  |                                                       |
        | Telephone_es_:signer                   | Yes                                                   |
        | Post_es_:signer                        | Yes                                                   |
        | SMS_es_:signer                         |                                                       |
        | Serial NumberRow1_es_:prefill          |                                                       |
        | Equipment ModelRow1_es_:prefill        |                                                       |
        | ManufacturerRow1_es_:prefill           |                                                       |
        | QuantityRow1_es_:prefill               |                                                       |
        | Serial NumberRow2_es_:prefill          |                                                       |
        | Equipment ModelRow2_es_:prefill        |                                                       |
        | ManufacturerRow2_es_:prefill           |                                                       |
        | QuantityRow2_es_:prefill               |                                                       |
        | Serial NumberRow3_es_:prefill          |                                                       |
        | Equipment ModelRow3_es_:prefill        |                                                       |
        | ManufacturerRow3_es_:prefill           |                                                       |
        | QuantityRow3_es_:prefill               |                                                       |
        | Serial NumberRow4_es_:prefill          |                                                       |
        | Equipment ModelRow4_es_:prefill        |                                                       |
        | ManufacturerRow4_es_:prefill           |                                                       |
        | QuantityRow4_es_:prefill               |                                                       |

     - Loop through the `productsData` that we have populated to set the following keys within the `data` array: `"Equipment ModelRow".$tempCountMc.'_es_:prefill'`, `"QuantityRow".$tempCountMc.'_es_:prefill'`, `"ManufacturerRow".$tempCountMc.'_es_:prefill'`. The `tempCountMc` will be set to the number of products in the current loop (we have 4 products max).
     - Then populate the values for `"Total Monthly Payment_es_:prefill"`, `mc_sum_vat`, and `Total Monthly` from the `Customer` instance.
     - Return the `data`.

   - Get document settings by invoking the function `DocumentTemplateService@getDocumentTemplate` for the type `TEMPLATE_FIRST_FINANCE`.
   - Define a temporary local path.
   - Build the `S3` template path using the fetched template settings.
   - Copy the S3 template to a local temporary path using the file name from the template settings, and then return its path.
   - Generate a `filename` to save the document as (`CustomerDocumentType::FINANCE_AGREEMENT) . ' - ' . $financeAgreement->id.'.pdf'`)
   - Invoking the function `DocumentTemplateService@fillTemplate`, we will use the `mikehaertl\pdftk\Pdf` library to fill the template with the provided data. Subsequently, we will generate the PDF file and save it locally.
   - Fetch the `CustomerApplicant` signature by invoking the function `CustomerApplicantDocumentsService@getSignatureLocalCopy`:
     - We fetch the customer applicant `CustomerApplicantDocument` using the `SIGNATURE` as doc type.
     - Fetch the signature file from S3 using the `file_path` field of the `CustomerApplicantDocument` and save it locally with the same name.
     - Return the local full path to it.
   - Adding the fetched signature file to the filled document path by invoking the function `DocumentSignService@signFirstDataAgreement` using the `Fpdi`. We will add the signature image to the correct position depending on the page we are in.
   - Invoking the function `CustomerDocumentsService@createFile`, we will define the `s3` path for the created document then upload it to `s3` under that path.
   - Create `CustomerDocument` for the given doc type and return it.

2. If the document is not generated and not created, we will update `CustomerFinanceAgreement` `is_attention_required` to `true` and return early.
3. Associate the created document with the agreement `$document->financeAgreement()->associate($financeAgreement)`.
4. Generate additional data for **firstData**
   - First, we fetch the first customer `CustomerMid` within the given `customer_contract_id`.
   - If not found, we throw an exception and return early.
   - We define an array list that contains company data:
   
    | Key                                              | Value                                       |
    |--------------------------------------------------|---------------------------------------------|
    | Company name                                     | $customer->legal_name                       |
    | MID                                              | $mid ? $mid->getPfAccountId() : ''          |
    | Registered office address in country of incorporation | $businessAddress->getFullAddress() |
    | Business address                                 | $businessAddress->getFullAddress()          |
    | KYB - Companies House link (will only be added to company) | https://find-and-update.company-information.service.gov.uk/company/{customer-_registration_number} |

   - Then we will loop through all the customer applicants and add their info to the 2D array:

    | Key                                              | Value                                       |
    |--------------------------------------------------|---------------------------------------------|
    | Name                                             | $applicant->getFullNameAttribute()          |
    | Address                                          | $applicant->getFullAddress()                |
    | DOB                                              | $applicant->dob                             |
    | Nationality                                      | $applicant->country()->first()->nationality_name |
    | Country of Residence                             | $applicant->country()->first()->name        |
   
   - Generate the PDF file using the `FPDF` service by passing the applicants' data and the company data.
   - Then we fetch the document type for `FIRST_DATA_ADD_INFO`.
   - By invoking the function `CustomerDocumentsService@createFile`, we will define the S3 path using the provided `FIRST_DATA_ADD_INFO` ID for the created document. Subsequently, we will upload it to S3 under that path, create the `CustomerDocument`, and return it.
   - Finally, we will return the created `CustomerDocument`.
   - If any exception is thrown, we will log it with the `LogService`.
  
5. If the document is not created, we will update `CustomerFinanceAgreement` `is_attention_required` to true and return early.
6. Associate `CustomerFinanceAgreement` with the newly created additional info document.
7. We check if a site visit is required for the customer, but at this point, the customer is already activated, so no site visit is required.
8. We check if the customer has a valid Google address.
   - If yes, we fetch the `google_address_validation_log` from the customer's `CustomerExternalData`. Then, we define the S3 path using the customer ID and the document type. Subsequently, we upload the encoded Google log result to S3. After that, we create the `CustomerDocument` and return it.
   - Then we invoke the function `CustomerFinanceService@onFinanceReadyForAuditTrail`, which triggers the following actions:
      - Update `CustomerFinanceAgreement` `status` to `READY_FOR_AUDIT_TRAIL`.
      - Fetch the `SignPack` from the `customerContract` with the customer agreement, then update `status` to `STATUS_READY_FOR_AUDIT_TRAIL`.
      - Report the operation log for `FINANCE_READY_FOR_AUDIT_TRAIL` by creating a new `CustomerOperationLog`.
9. We dispatch the job `SignCustomerDocumentsCronJob` which executes the cron job `SignCustomerDocumentsCron`. [Sign customer Documents Cron](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/sign-customer-docs-cron.md)
   - Then we return `true`.

#### Send Company Data to First Data

When invoked through `CustomerFinanceService@sendToFinanceCompany`, this function essentially sends two types of data to **First Data**. First, it sends customer and business details in JSON format. Second, it emails them a list of documents including ID, agreement, additional info, proof of address, etc. The order of dispatching this data depends on the `CustomerAgreement` `status`.

##### Process Descriptions
First, we check the `CustomerFinanceAgreement` status. If it equals `FIRST_DATA_STATUS_NEW`, we start by sending the [customer and business details in JSON format](#json-format-process-description). If the status equals `FIRST_DATA_STATUS_API_SENT`, we will [consider emailing them the documents needed](#emailing-documents-process-description).

##### JSON Format Process Description
- We will invoke the `FirstDataService@sendMerchantData`, which will do the following:
   - Fetch the `Customer` from the finance agreement contract.
   - If the customer is not found, we will stop there and throw an exception.
   - Fetch customer business-related details such as `business address`, `contact name`, `business start month`, `business start date MM/YYYY`.
   - Fetch the first `CustomerMid` with the finance agreement contract.
   - Fetch outlets (locations) and loop through them to define the `outletData`.

   | Field              | Value                                             |
   |--------------------|---------------------------------------------------|
   | Ext_Merchant_ID    | $mid                                              |
   | Chain_Chn          |                                                   |
   | DBA_Name           | $this->formatTradingName($customer->trading_name) |
   | Legal_Name         | $customer->legal_name                             |
   | Buss_Address1      | $outlet->customerAddress->house_name_number       |
   | Buss_Address2      | $outlet->customerAddress->street_name             |
   | Buss_Address3      | $outlet->customerAddress->address_line_1          |
   | Buss_City          | $outlet->customerAddress->city                    |
   | Buss_State         | $outlet->customerAddress->state_name              |
   | Buss_Zip           | $outlet->customerAddress->postcode                |
   | Buss_Country       | $outlet->customerAddress?->country?->alpha_3_code |
   | Buss_Phone         | str_replace(' ', '', $phone)                      |
   | Buss_Emailaddress  |                                                   |
   | Contact_Name       | $contactName                                      |
   | Contact_Phone      | str_replace(' ', '', $phone)                      |
   | Contact_Fax        |                                                   |
   | AR_Name            | $contactName                                      |
   | AR_Address1        | $outlet->customerAddress->house_name_number       |
   | AR_Address2        | $outlet->customerAddress->street_name             |
   | AR_Address3        | $outlet->customerAddress->address_line_1          |
   | AR_City            | $outlet->customerAddress->city                    |
   | AR_State           | $outlet->customerAddress->state_name              |
   | AR_Zip             | $outlet->customerAddress->postcode                |
   | Bank_Nbr           | $outlet->customerBankAccount->sort_code           |
   | Account_Nbr        | $outlet->customerBankAccount->account_number      |
   | BIC                |                                                   |
   | IBAN               |                                                   |
   | SIC_Code           |                                                   |
   | Prior_Lease_Nbr    |                                                   |
   | Prior_Lease_Ind    |                                                   |
   | Request_Nbr        |                                                   |
   | Billing_Type_Info  | 'Billing_Type' => [ 'Lease_Term' => ContractLengthModel::getMonths($financeAgreement->customerContract->contract_length), 'Billing_Method' => 'LEASE', REQUIRED, 'Asset_Info' => ['Asset' => $this->assets($outlet, $financeAgreement) ]] |

   - Within the `Billing_Type_Info` and under `Asset_Info` with `Billing_Type`, we define the `Asset` value by invoking the function `FirstDataService@assets`. [Process description for `asset()`](#process-description-for-asset).
   - Fetch the shareholders and for each one, we will store their principal info. The following is the list of the info we use:

   | Field               | Value                                                                                         |
   |---------------------|-----------------------------------------------------------------------------------------------|
   | Prin_Guarantor_Code | PRINCIPAL                                                                                     |
   | Title               | !empty($customerApplicant->title) ? $customerApplicant->title : 'n/a'                         |
   | First_Name          | $customerApplicant->first_name                                                                |
   | Last_Name           | $customerApplicant->last_name                                                                 |
   | Address1            | $customerApplicant->getFullStreetAddress()                                                    |
   | Address2            | substr($customerApplicant->address_line_1, 0, 32)                                             |
   | Address3            | $customerApplicant->address_line_2                                                            |
   | City                | $customerApplicant->city                                                                      |
   | State               |                                                                                               |
   | Zip                 | $customerApplicant->postcode                                                                  |
   | Country             | $customerApplicant?->country?->alpha_3_code                                                   |
   | Phone               | str_replace(' ', '', $phone)                                                                  |
   | DOB                 | $customerApplicant->dob_obj?->format('m/d/Y')                                                 |
   | SSN                 |                                                                                               |
   | PCT_Own             |                                                                                               |

   - Next, we construct the data array that we will send to the **First Data** API using the details we previously gathered. This data will be included with the `ApplicationInfo` key.

   | Field                | Value                                                                                         |
   |----------------------|-----------------------------------------------------------------------------------------------|
   | XMLSeqid             | $id                                                                                           |
   | Ext_Merchant_ID      | $mid                                                                                          |
   | Operating_Type       | NEW                                                                                           |
   | Source_System        | V9                                                                                            |
   | Platform             | UK                                                                                            |
   | UID                  | $id                                                                                           |
   | Bank_Code            | self::BANK_CODE                                                                              |
   | DBA_Name             | $this->formatTradingName($customer->trading_name)                                            |
   | Legal_Name           | $customer->legal_name                                                                        |
   | Credit_Score         |                                                                                               |
   | Number_Of_Outlets    | 1                                                                                             |
   | Buss_Address1        | $businessAddress->house_name_number                                                          |
   | Buss_Address2        | $businessAddress->street_name                                                                |
   | Buss_Address3        | $businessAddress->address_line_1                                                             |
   | Buss_City            | $businessAddress->city                                                                       |
   | Buss_State           | $businessAddress->state_name                                                                 |
   | Buss_Zip             | $businessAddress->postcode                                                                   |
   | Buss_Country         | $businessAddress?->country?->alpha_3_code                                                    |
   | Buss_Phone           | str_replace(' ', '', $phone)                                                                  |
   | Contact_Name         | $contactName                                                                                  |
   | Contact_Phone        | str_replace(' ', '', $phone)                                                                  |
   | Contact_Fax          |                                                                                               |
   | SIC_Code             | $sicCode                                                                                     |
   | FED_TAX_ID           | $customer->registration_number                                                               |
   | VAT_Reg_No           | $customer->vat_number                                                                         |
   | Bank_Nbr             | $bankAccount->sort_code                                                                      |
   | Account_Nbr          | $bankAccount->account_number                                                                 |
   | BIC                  |                                                                                               |
   | IBAN                 |                                                                                               |
   | Buss_Type            | $businessType                                                                                 |
   | Buss_Start_Date      | $businessStartDate                                                                            |
   | AR_Name              | $contactName                                                                                  |
   | AR_Address1          | $businessAddress->house_name_number                                                          |
   | AR_Address2          | $businessAddress->street_name                                                                |
   | AR_Address3          | $businessAddress->address_line_1                                                             |
   | AR_City              | $businessAddress->city                                                                       |
   | AR_State             | $businessAddress->state_name                                                                 |
   | AR_Zip               | $businessAddress->postcode                                                                   |
   | AR_Attention         |                                                                                               |
   | Rep_ID               | V9                                                                                            |
   | Signer_Name          |                                                                                               |
   | Signer_Phone         |                                                                                               |
   | Buss_Emailaddress    |                                                                                               |
   | Sysprin              |                                                                                               |
   | Multi_App            | N                                                                                             |
   | Principal_Info       |                                                                                               |
   | Principal            | $principalInfo                                                                                |
   | Outlet_Info          |                                                                                               |
   | Outlet               | $dataOutlet ?? []                                                                             |

   - At the end, we invoke the function `FirstDataApiService@sendToFirstData`, which will send data to **First Data** API.
   - Finally, we return the manually generated UUID. This ID is set as the `XMLSeqid` within the payload we send.
   - Using the return ID, we will update the following `CustomerFinanceAgreement` fields:
     - `first_data_id`: updated to the value of `id` returned
     - `first_data_status`: updated to `FIRST_DATA_STATUS_API_SENT`

#### Process description for `asset()`

1. First we fetch all the `CustomerProduct` where the `CustomerContract` is related to the contract we have attached to `CustomerFinanceAgreement`.
2. Then for each product, we assign the `TID` by calling the `PaxService@assignPaxTid`, which will do the following:
   - First, we ensure that the product is `PAX_A920_MOBILE` or `PAX_A920_PORTABLE`.
   - If the product already has a `tid` assigned, we return the `CustomerProduct` and do nothing.
   - If the product does not require a `tid`, we return the `CustomerProduct` and do nothing.
   - Within an infinite `do` loop, we will continuously attempt to fetch an unused `tid` by calling the `releaseNewTid` function of the `PaxTid` model, as long as the `tid` is already assigned to another `CustomerProduct`.
   - Then we assign it to the `CustomerProduct` `tid`.
   - We also assign the same `tid` to the `CustomerProduct` of type `CHARGING_CRADLE`.
   - At the end, we return the product.
3. When looping through all the fetched products, we will also push the product details to the `assets` list:

   | Field           | Value                                                                 |
   |-----------------|-----------------------------------------------------------------------|
   | Equip_Type      | TERMINAL                                                              |
   | Manufacturer    | $manufacturer                                                         |
   | Equip_Code      | $equipmentCode                                                        |
   | Vendor_Order_No |                                                                      |
   | Terminal_ID     | $product->tid                                                         |
   | Lease_Amt       | $monthlyCost                                                          |
   | Lease_Term      | ContractLengthModel::getMonths($product->contract->contract_length)   |
   | Old_Serial_Nbr  |                                                                      |
   | Serial_Nbr      | 0000000000000                                                         |
   | Deploy_Date     | $date                                                                 |
   | Asset_Rep_Id    |                                                                      |

4. We fetch all the customer standard fees for the given `CustomerFinanceAgreement` `customer_contract_id` by invoking the function `CustomerStandardFeesService@getCustomerFeesForFinanceAgreement`.
5. Then, for each `CustomerStandardFee`, we will push the asset data depending on the `qty` of that standard fee. So, if the current `CustomerStandardFee` has a `qty` of `2`, we will loop depending on the number of quantities and push the new asset:

   | Field           | Value                                                                 |
   |-----------------|-----------------------------------------------------------------------|
   | Equip_Type      | FEE                                                                   |
   | Manufacturer    | V9                                                                    |
   | Equip_Code      | $equipmentCode                                                        |
   | Vendor_Order_No | ''                                                                    |
   | Terminal_ID     | ''                                                                    |
   | Lease_Amt       | $monthlyCost                                                          |
   | Lease_Term      | ContractLengthModel::getMonths($financeAgreement->customerContract->contract_length) |
   | Old_Serial_Nbr  | ''                                                                    |
   | Serial_Nbr      | 0000000000000                                                         |
   | Deploy_Date     | $date                                                                 |
   | Asset_Rep_Id    | ''                                                                    |

6. At the end, we return the `assets` list with all the data.

#### Emailing Documents Process Description

- We will invoke the `FirstDataService@sendEmailToFirstData`, which will do the following:
  - Fetching customer and site visit requirement.
  - Fetching customer applicants:
    - If the customer business is `PARTNERSHIP`, we fetch all the `CustomerApplicant` shareholders.
    - If not, we only fetch the main applicant.
  - Then for each applicant, we will fetch their documents (ID front, ID back) and add them to an attachment list. If a document is missing, we throw an exception.
  - Fetching the `SignPack` from the customer finance agreement contract.
  - Fetching the envelope document using the given `SignPack` id and push it to the attachment. If not found, an exception is thrown.
  - Fetching the agreement document using the given `CustomerFinanceAgreement` id and push it to the attachment. If not found, an exception is thrown.
  - Fetching the additional information document. If not found, an exception is thrown.
  - If the customer has proof of trading address, we will fetch documents for `PROOF_ADDRESS_DOCUMENT`, `PROOF_ADDRESS_DOCUMENT_2`, and `PROOF_ADDRESS_ALTERNATIVE` and add them to the attachment list.
  - If a site visit is required for the customer, we will fetch the following docs:
    - Fetching `FIRST_DATA_SITE_VISIT_CONFIRMATION` document and add it to the attachment. If not found, an exception will be thrown.
    - Fetching `SITE_VISIT_OVERVIEW_PHOTO` document; if found, push it to the attachment list.
    - Fetching `SITE_VISIT_INSIDE_PHOTO` document; if found, push it to the attachment list.
    - Fetching `SITE_VISIT_FRONT_PHOTO` document; if found, push it to the attachment list.
    - Fetching `SITE_VISIT_STOCK_PHOTO` document; if found, push it to the attachment list.
  - If the customer has a valid Google address, we fetch the document `GOOGLE_ADDRESS_VALIDATION_RESULT`; if found, we will add it to the attachment list.
  - Fetching `POA_GOOGLE_SCREENSHOT` document; if found, we will push it to the attachment list.
  - At the end, we proceed by sending these attachments to **First Data** by email (`api.first_data.email`), invoking the function `MailingService@sendEmail`. If successful, we return true; if not, we log the error `MAILING_FAILED` with `LogService` and return false.
  - If the response is false, we log `FIRST_DATA_API_EXCEPTION` with `LogService`.

- If nothing goes wrong, we will update the `CustomerFinanceAgreement` `first_data_status` to `FIRST_DATA_STATUS_EMAIL_SENT`.
- Then we invoke the function `CustomerFinanceService@onFinanceSent`, which will update the `CustomerFinanceAgreement` `status` to `PENDING` and `sent_at` to the current time.
- If an exception is thrown when sending data, we will log `FIRST_DATA_API_EXCEPTION` with `LogService` and update the `CustomerFinanceAgreement` `is_attention_required` to true, then return `false`.
- At the end, if nothing goes wrong, we will return `true`.
