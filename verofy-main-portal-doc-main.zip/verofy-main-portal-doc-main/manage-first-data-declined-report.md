## Check First Data Declined Reports
**Author:** Anouar

### Table of Content
- [Overview](#overview)
- [Code Process](#code-process)
- [Process Declined Messages](#process-declined-messages)
- [Create Dirst Data Declined Case Process Description](#create-first-data-declined-case-process-description)
### Overview

After sending the JSON data and the email with all the attachments, we have a scheduled `CheckFirstDataDeclinedReportsCronJob` job that runs every five minutes in `production` environment to check the First Data declined reports. When it is dispatched, it executes the command `CheckFirstDataDeclinedReportsCron`, which invokes the function `FirstDataReportService@processDeclineReports`. which will handle one main action which is processing the 
 delined messages by invoking the function `FirstDataImapService@processDeclinedMessages`

### Code Process

### Process declined Messages
When the function `FirstDataImapService@processDeclinedMessages` is invoded we will do the following :
1. We refresh the access token using the sufix `SECRET_TYPE_FD_COMMS` by calling `ImapOauthService@refreshToken`  which fetches the `access_token` then we save it with the field `imap_oauth_access_token_{sufix}` under `settings` table.
2. Using `Imap` we will connect to `fd_comms` account
3. We fetch the `INBOX` folder
4. Then from the `INBOX` folder we will fetch all the `messages` received.
5. for each message we will store the report by creating a `FirstDataDeclinedReport` record

| Field           | Value                                                  |
|-----------------|--------------------------------------------------------|
| status          | FirstDataDeclineReport::PROCESS_STATUS_NEW             |
| mail_from       | $fromMail                                              |
| mail_subject    | $message->getSubject()                                 |
| mail_text_body  | $message->getTextBody()                                |
| mail_html_body  | $message->getHTMLBody()                                |

7. We create a fisrt data declined case by invoking the function `VerofyToVtigerService@createFirstDataDeclinedCase` [Create first data declined case](#create-first-data-declined-case)
8. if the case did not create and returns false we will skip
9. We move the processed message to `IMAP_PROCESSED_FOLDER` which `First Data Processed`. if did succeed we will log `FIRST_DATA_REPORT_EXCEPTION` within the `LogService`

### Create first data declined case process description
1. Firt we try to fetch contact from vtiger using the `fistName`, `lastName =FD CONTACT` and `fromEmail` .if not found we will create new one and push it to `Vtiger` service, and return the `contactVtigerId`

| Field            | Value                                                              |
|------------------|--------------------------------------------------------------------|
| assigned_user_id | VtigerApiService::USER_ID_SUPPORT_TEAM                            |
| firstname        | $firstName                                                         |
| lastname         | $lastName                                                          |
| email            | $email                                                             |
| description      |                                                                    |
| cf_1147         | VtigerApiService::CONTACTS_CONTACT_TYPE_EXTERNAL_FIRST_DATA       |

2. If something goes wrong during the sending data to `vtiger` to create the user,we will log the error `SAVE FIRST DATA CONTACT` with `LogService` then return `false`
3. If We get `false` we will throw an exception.
4. Otherwize we will create **no priority** ticket with *vtiger** with the following data


| Field                | Value                                                |
|----------------------|------------------------------------------------------|
| assigned_user_id     | VtigerApiService::USER_ID_SUPPORT_TEAM              |
| ticketpriorities     | $ticketPriority                                      |
| ticketstatus         | VtigerApiService::TICKET_STATUS_AWAITING_ASSIGNMENT |
| ticketcategories     | VtigerApiService::TICKET_CATEGORY_BIG_PROBLEM       |
| ticket_title         | $title                                               |
| cf_1789              | VtigerApiService::TICKET_TYPE_FIRST_DATA            |
| description          | $title                                               |
| contact_id           | $contactVtigerId                                    |

5. Now we will invoke the function `VtigerApiService@create` which will create the ticket with **Vtiger** which will return the case id (ticket id)
6. Add the end we add a comment to the case by invoking the function `FirstDataReportService@addAutoCommentToCase` with payload:

| Field            | Description            |
|------------------|------------------------|
| commentcontent   | Message content                |
| assigned_user_id | USER_ID_SUPPORT_TEAM = '19x4'            |
| related_to       | created case id            |

7. If something goes wrong log the error `CREATE FIRST DATA DECLINED CASE` with the `LogService`
