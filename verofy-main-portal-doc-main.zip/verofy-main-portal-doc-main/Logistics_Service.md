# Customer Delivery Logistics Service [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Logistics_Service.txt)

## Table of Contents

- [Introduction](#introduction)
- [Code Flow Diagram I](#code-flow-diagram-1)
- [Code Flow Diagram II](#code-flow-diagram-2)
- [Kernel Configuration](#kernel-configuration)
- [Job: CustomerDeliveryLogisticsCronJob](#job-customerdeliverylogisticscronjob)
- [Command: CustomerDeliveryLogisticsCron](#command-customerdeliverylogisticscron)
- [Customer Product and Delivery Status](#customer-product-and-delivery-status)
  - [CustomerProductStatus](#customerproductstatus)
  - [CustomerDeliveryPackage](#customerdeliverypackage)
- [Service: CustomerDeliveryLogisticsDataService](#service-customerdeliverylogisticsdataservice)
  - [Method: incomingFilesProcess](#method-incomingfilesprocess)
  - [Method: searchFiles](#method-searchfiles)
  - [Method: parseFile](#method-parsefile)
  - [Method: parseFileDespaches](#method-parsefiledespaches)
  - [Method: getCustomerProductByTid](#method-getcustomerproductbytid)
  - [Method: onTerminalDispatched](#method-onterminaldispatched)
  - [Method: parseFilePOD](#method-parsefilepod)
  - [Method: onTerminalDelivered](#method-onterminaldelivered)
  - [Method: parseFileAllocations](#method-parsefileallocations)
  - [Method: onTerminalPackedForShipment](#method-onterminalpackedforshipment)
  - [Method: parseFileSwap](#method-parsefileswap)

![Bambora Diagram](CR-onboarding-final-stage/Customer_Logistic_Service.png)

## Introduction

This document provides an overview and detailed explanation of the components and logic involved in the Customer Delivery Logistics Cron Job implementation. The focus is on the business logic, status changes, and conditions.

## Code Flow Diagram 1

```mermaid
graph TD;
    subgraph Scheduled Job
        OrderProductsCronJob("OrderProductsCronJob<br>Every 5 min (starting min 3)")
        OrderProductsCronJob -->|Triggers| SLOrderCreation("OrderProductsCron")
    end

    subgraph Fetch Criteria
        CriteriaFetch("Fetch CustomerProduct<br>Based on Criteria")
        SLOrderCreation --> CriteriaFetch
    end

    subgraph Order Creation Process
        SLOrderProcess("Create Order in SL<br>(ServiceLogisticsService@createOrder)")
        CustomerNotif("On Terminal Ordered<br>(onTerminalOrdered)")
        PartnerNotif("On Customer Terminal Ordered<br>(onCustomerTerminalsOrdered)")

        CriteriaFetch --> SLOrderProcess
        SLOrderProcess -->|For Each Product| CustomerNotif
        SLOrderProcess -->|For Each Customer Product| PartnerNotif
        
        SLOrderProcess --> SLFileGen("Generate & Send<br>Spreadsheet File")
    end

    subgraph On Terminal Ordered
        UpdateStatus("Update CP Status to ORDERED")
        UpdateOverallStatus("Update Customer Overall Status")
        DeliveryUpdate("Update Delivery Package Status")
        LogOrder("Record CUSTOMER_PRODUCT_ORDERED Log")

        CustomerNotif --> UpdateStatus
        UpdateStatus --> UpdateOverallStatus
        UpdateOverallStatus --> DeliveryUpdate
        DeliveryUpdate --> LogOrder
    end

    subgraph On Customer Terminal Ordered
        NotifyCustomer("Notify Customer")
        NotifyPartner("Notify Partner")

        PartnerNotif --> NotifyCustomer
        PartnerNotif --> NotifyPartner
    end
```

## Logistic Service

The Logistic Service is responsible for managing the creation of `CustomerProduct` orders. This process begins after the terminals (CustomerProduct) have been created.

A scheduled job, `OrderProductsCronJob`, runs every 5 minutes starting from minute `3` within `local`, `staging`, and `production` environments. This job triggers the `OrderProductsCron` cron job, which handles the creation of `CustomerProduct` orders in the Service Logistic.

The order creation process in Service Logistic follows these steps:

1. Fetch all `CustomerProduct` that match specific criteria.
2. Start the order creation process in Service Logistic by invoking the `ServiceLogisticsService@createOrder` function.
3. Once all products are created in the service logistics, perform several actions for each product and customer-specific product.

Detailed descriptions of the processes involved in creating the order in the Service Logistic, updating the terminal order status, and notifying the customer and partner about the terminal order are provided in the following sections.

## Create the Order in the Service Logistic Process Description

This process involves creating a spreadsheet instance, adding the terminals `CustomerProduct` to the spreadsheet, generating a local file, saving the spreadsheet data to the local file, sending the spreadsheet file to the service logistic email, and returning true to indicate that the file has been sent.

## On Terminal Ordered Process Description

This process involves updating the `CustomerProduct` status and ordered_at timestamp, invoking the `UpdateCustomerOverallStatusAction` action, invoking the `CustomerDeliveryService@onProductOrdered` function, and recording a log for `CUSTOMER_PRODUCT_ORDERED` with a new `CustomerOperationLog`.

## On Customer Terminal Ordered Process Description

This process involves notifying the `Customer` that their terminal is ordered and notifying the Partner that their customer's terminal is ordered.

## Code Flow Diagram 2

```mermaid
graph TD;
    A[Schedule job] --> B[Run CustomerDeliveryLogisticsCronJob]
    B --> F[Run CustomerDeliveryLogisticsCron]
    F --> G[Process incoming files]
    G --> H[Search for files in S3/SFTP]
    H --> I[For each file]
    I --> J[Detect file type]
    J -->|Despatches| K[Parse Despatches file]
    K -->|foreach record| L[Process Despatches Record]
    L --> M[Get Customer Product]
    M --> N[Save & Update Status]
    N --> O[Log Success]
    N -- Error --> P[Handle Despatches Error]
    J -->|POD| Q[Parse POD file]
    Q -->|foreach record| R[Process POD Record]
    R --> S[Get TID & Status]
    S --> T[Save & Update POD Status]
    T --> U[Log Success]
    T -- Error --> V[Handle POD Error]
    J -->|Allocations| W[Parse Allocations file]
    W -->|foreach record| X[Process Allocation Record]
    X --> Y[Save & Update Allocation]
    Y --> Z[Log Success]
    Y -- Error --> AA[Handle Allocations Error]
    J -->|Swap| BB[Parse Swap file]
    BB -->|foreach record| CC[Process Swap Record]
    CC --> DD[Save & Update Swap]
    DD --> EE[Log Success]
    DD -- Error --> FF[Handle Swap Error]
    J -- Unknown Type --> GG[Move to OTHERS & Log Error]
    P --> HH[Final Logging & End Process]
    V --> HH
    FF --> HH
    GG --> HH
    O --> HH
    U --> HH
    Z --> HH
    AA --> HH
    EE --> HH
```

## Kernel Configuration

The Cron Job is scheduled in the `Kernel` with the following configuration:

| Property | Value |
| --- | --- |
| Scheduler Job Name | `CustomerDeliveryLogisticsCronJob` |
| Environments | `local` `production` |
| Frequency | Every 5 minutes from the 8th to the 59th minute of each hour |
| Overlapping | Prevented, with a 10-minute threshold |
| Server Execution | Runs on only one server |

## Job: CustomerDeliveryLogisticsCronJob

```php
public function handle(): void
{
    Artisan::call('importDeliveryLogisticsFiles:cron', []);
}
```

## Command: CustomerDeliveryLogisticsCron

```php
public function handle()
{
    $this->customerDeliveryLogisticsDataService->incomingFilesProcess();
}
```

## Customer Product and Delivery Status

### **CustomerProductStatus**

| Status | Changing Point | Method |
| --- | --- | --- |
| `IN_TRANSIT` | `parseFileDespaches` method when `state` is `IN_TRANSIT` and `customerProduct->status` is not `DISPATCHED` | `parseFileDespaches` |
| `DISPATCHED` | `onTerminalDispatched` method when `customerProduct->status` is not `DISPATCHED` | `onTerminalDispatched` |
| `PACKED_FOR_SHIPMENT` | `onTerminalPackedForShipment` method when `customerDeliveryPackage->status` is not `PACKED_FOR_SHIPMENT` | `onTerminalPackedForShipment` |
| `SWAP` | `parseFileSwap` method when `state` is `SWAP` and `customerProduct->status` is not `SWAP` | `parseFileSwap` |
| `DELIVERED` | `onTerminalDelivered` method when `customerProduct->delivered_at` is empty | `onTerminalDelivered` |

### **CustomerDeliveryPackage**

| Status | Changing Point | Method |
| --- | --- | --- |
| `STATUS_READY_FOR_COLLECTION` | `onTerminalDispatched` method when `customerDeliveryPackage->status` is not `STATUS_READY_FOR_COLLECTION` | `onTerminalDispatched` |
| `STATUS_IN_TRANSIT` | `onTerminalInTransit` method when `customerDeliveryPackage->status` is not `STATUS_IN_TRANSIT` | `onTerminalInTransit` |
| `STATUS_PACKED_FOR_SHIPMENT` | `onTerminalPackedForShipment` method when `customerDeliveryPackage->status` is not `STATUS_PACKED_FOR_SHIPMENT` | `onTerminalPackedForShipment` |
| `STATUS_DELIVERED` | `onTerminalDelivered` method when `customerDeliveryPackage->status` is not `STATUS_DELIVERED` | `onTerminalDelivered` |

## Service: CustomerDeliveryLogisticsDataService

### Method: incomingFilesProcess

```php
public function incomingFilesProcess(): array
{
    foreach ($this->searchFiles() as $file) {
        try {
            $this->searchedFiles++;
            $this->parseFile($file);
            $this->archiveFile($file);
        } catch (UnknownFileTypeException $e) {
            $this->addError($e->getMessage());
        } catch (\Exception $e) {
            $this->moveFileToFailedFolder($file);
            $this->addError($e->getMessage());
        }
    }

    $result = [
        'added_new_records'  =>  $this->countSucessfullyAdded,
        'searched_files'     =>  $this->searchedFiles,
        'archived_files'     =>  $this->archivedFiles,
        'error_log'          =>  $this->errors
    ];

    LogService::log(LogCode::CRON, $result);

    return $result;
}
```

### Method: searchFiles

```php
public function searchFiles(): array
{
    return Storage::disk('s3_sftp')->files($this->uploadsDisk());
}
```

### Method: parseFile

```php
public function parseFile($filePath): bool
{
    $fileName = pathinfo($filePath, PATHINFO_FILENAME);
    $parserName = substr($fileName, -29, -12);

    switch ($parserName) {
        case 'VerofyDespatches':
            return $this->parseFileDespaches($filePath);
        case 'VerofyPOD':
            return $this->parseFilePOD($filePath);
        case 'VerofyAllocations':
            return $this->parseFileAllocations($filePath);
        case 'VerofySwap':
            return $this->parseFileSwap($filePath);
        default:
            Storage::disk('s3_sftp')->move($filePath, $this->uploadsDisk() . '/Archived/others/' .  $fileName . '.' . pathinfo($filePath, PATHINFO_EXTENSION));
            throw new UnknownFileTypeException("Unknown file type: $filePath. The file not parsed and moved to OTHERS directory!");
    }
}
```

### Method: parseFileDespaches

```php
public function parseFileDespaches($file): bool
{
    $errors = 0;
    foreach ($this->csv2Array($file, true) as $row) {
        if($this->isThisTidForV1($row[1])) continue;

        $data = [
            'created_date' => Carbon::now(),
            'mid' => $row[0],
            'tid' => $row[1],
            'serial_number' => $row[2],
            'carrier_reference' => $row[3],
            'state' => self::IN_TRANSIT,
            'file' => $file
        ];

        try {
            $customerProduct = $this->getCustomerProductByTid($data['tid']);
            if($customerProduct->status === CustomerProductStatus::DISPATCHED) continue;

            $this->saveRecordFromRow($data);
            $this->customerProductsService->onTerminalDispatched(
                $customerProduct,
                $data['carrier_reference'],
                $data['serial_number'],
                $this->dispatchDateFromFileName(pathinfo($file, PATHINFO_FILENAME))
            );

        } catch (\Exception $e) {
            $this->addError('Error in file: ' . pathinfo($file, PATHINFO_FILENAME) . '.' . pathinfo($file, PATHINFO_EXTENSION) . ' - ' . $e->getMessage());
            $errors++;
        }
    }

    if($errors > 0 ) {
        throw new \Exception('Error during parse file: ' . $file . ' - some records not stored.');
    }
    return true;
}
```

### Method: getCustomerProductByTid

```php
private function getCustomerProductByTid($tid): CustomerProduct
{
    $product = CustomerProduct::where('tid', $tid)->get()->first();
    if(!empty($product)) {
        return $product;
    }
    throw new \Exception("Product with \"$tid\" not found!");
}
```

### Method: onTerminalDispatched

```php
public function onTerminalDispatched(CustomerProduct $customerProduct, string $trackingNo, string $serialNo, \Carbon\Carbon $dispatchDate)
{
    $customerProduct->status = CustomerProductStatus::DISPATCHED;
    $customerProduct->serial_number = $serialNo;
    $customerProduct->dispatched_at = $dispatchDate;
    $customerProduct->save();

    $this->updateCustomerOverallStatusAction->handle($customerProduct->customer);

    $customerDeliveryPackage = $customerProduct->customerDeliveryPackage;
    if ($customerDeliveryPackage->status !== CustomerDeliveryPackage::STATUS_READY_FOR_COLLECTION) {
        $trackingNoLink = DpdDeliveryService::getTrackingNoLink($trackingNo);
        $this->messagingEventsService->processSellerCustomerTerminalsDispatched($customerProduct->customer, $trackingNoLink);
        $this->messagingEventsService->processCustomerTerminalsDispatched($customerProduct->customer, $trackingNoLink);

        $vt = $customerProduct->customer->products()->virtualTerminal()->first();
        $pbl = $customerProduct->customer->products()->payByLink()->first();
        if (!$pbl && !$vt) {
            $this->messagingEventsService->processCustomerAccountActivatedTerminal($customerProduct->customer);

            $activateCustomerAccountAction = App::make(ActivateCustomerAccountAction::class);
            $activateCustomerAccountAction->handle($customerProduct->customer);
        }

        $customerDeliveryPackage->tracking_number = $trackingNo;
        $customerDeliveryPackage->status = CustomerDeliveryPackage::STATUS_READY_FOR_COLLECTION;
        $customerDeliveryPackage->save();
    }

    $this->customerOperationLogService->logOperation(
        $customerProduct->customer,
        CustomerOperation::CUSTOMER_PRODUCT_DISPATCHED,
        customerProduct: $customerProduct
    );
}
```

### Method: parseFilePOD

```php
public function parseFilePOD($file): bool
{
    $errors = 0;
    foreach ($this->csv2Array($file) as $row) {
        $tid = $this->getTidByTrackingNumber($row[1]);
        if(empty($tid)) continue;
        if($this->isThisTidForV1($tid)) continue;

        $status = $this->getStatusFromMessage($row[2]);
        $data = [
            'created_date' => Carbon::now(),
            'mid' => $row[0],
            'tid' => $tid,
            'carrier_reference' => $row[1],
            'state' => $status,
            'message' => $row[2],
            'file' => $file,
            'updated_date_from_pod_file' => Carbon::createFromFormat('d/m/Y H:i:s', $row[3])
        ];

        try {
            $customerProduct = $this->getCustomerProductByTid($data['tid']);
            $customerDeliveryPackage = $customerProduct->customerDeliveryPackage;
            $this->saveRecordFromRow($data);
            if ($status === self::DELIVERED) {
                if($customerDeliveryPackage->status == CustomerDeliveryPackage::STATUS_DELIVERED) continue;

                $this->customerProductsService->onTerminalDelivered(
                    $customerProduct,
                    $data['updated_date_from_pod_file']
                );
            } elseif (($status === self::FAIL) || ($status == self::FAIL_CARD)) {
                $this->customerProductsService->onTerminalNonDelivered(
                    $customerProduct,
                    $data['updated_date_from_pod_file']
                );
            } elseif (($status === self::IN_TRANSIT)) {
                if($customerDeliveryPackage->status == CustomerDeliveryPackage::STATUS_IN_TRANSIT) continue;

                $this->customerProductsService->onTerminalInTransit(
                    $customerProduct,
                    $data['carrier_reference']
                );
            }

        } catch (\Exception $e) {
            $this->addError('Error in file: ' . pathinfo($file, PATHINFO_FILENAME) . '.' . pathinfo($file, PATHINFO_EXTENSION) . ' - ' . $e->getMessage());
            $errors++;
        }
    }

    if($errors > 0 ) {
        throw new \Exception('Error during parse file: ' . $file . ' - some records not stored.');
    }
    return true;
}
```

### Method: onTerminalDelivered

```php
public function onTerminalDelivered(CustomerProduct $customerProduct, $date)
{
    if (!empty($customerProduct->delivered_at)) {
        return;
    }

    $paxSetupLink = 'https://pax-setup-link';
    $this->messagingEventsService->processCustomerOrderDelivered($customerProduct->customer, $paxSetupLink);
    $this->messagingEventsService->processSellerCustomerHardwareDelivered($customerProduct->customer);

    $customerProduct->delivered_at = $date;
    $customerProduct->save();

    $customerDeliveryPackage = $customerProduct->customerDeliveryPackage;
    $customerDeliveryPackage->status = CustomerDeliveryPackage::STATUS_DELIVERED;
    $customerDeliveryPackage->delivered_at = $date;
    $customerDeliveryPackage->save();

    $this->updateCustomerOverallStatusAction->handle($customerProduct->customer);

    $this->customerOperationLogService->logOperation(
        $customerProduct->customer,
        CustomerOperation::CUSTOMER_PRODUCT_DELIVERED,
        customerProduct: $customerProduct
    );
}
```

### Method: parseFileAllocations

```php
private function parseFileAllocations($file)
{
    $errors = 0;
    foreach ($this->csv2Array($file, true) as $row) {
        if($this->isThisTidForV1($row[1])) continue;

        $data = [
            'created_date' => Carbon::now(),
            'mid' => $row[0],
            'tid' => $row[1],
            'serial_number' => $row[2],
            'state' => self::PACKED_FOR_SHIPMENT,
            'file' => $file
        ];

        try {
            $this->saveRecordFromRow($data);
            $this->customerProductsService->onTerminalPackedForShipment(
                $this->getCustomerProductByTid($data['tid'])
            );
        } catch (\Exception $e) {
            $this->addError('Error in file: ' . pathinfo($file, PATHINFO_FILENAME) . '.' . pathinfo($file, PATHINFO_EXTENSION) . ' - ' . $e->getMessage());
            $errors++;
        }
    }

    if($errors > 0 ) {
        throw new \Exception('Error during parse file: ' . $file . ' - some records not stored.');
    }
    return true;

}
```

### Method: onTerminalPackedForShipment

```php
public function onTerminalPackedForShipment(CustomerProduct $customerProduct)
{
    $customerDeliveryPackage = $customerProduct->customerDeliveryPackage;
    $customerDeliveryPackage->status = CustomerDeliveryPackage::STATUS_PACKED_FOR_SHIPMENT;
    $customerDeliveryPackage->save();
}
```

### Method: parseFileSwap

```php
private function parseFileSwap($file)
{
    $errors = 0;
    foreach ($this->csv2Array($file, true) as $row) {
        if($this->isThisTidForV1($row[1])) continue;

        $data = [
            'created_date' => Carbon::now(),
            'mid' => $row[0],
            'tid' => $row[1],
            'serial_number' => $row[2],
            'state' => self::SWAP . ' - new SN: ' . $row[3],
            'file' => $file
        ];

        try {
            $this->saveRecordFromRow($data);
            $this->customerProductsService->onTerminalSwapOut(
                $this->getCustomerProductByTid($data['tid']),
                $row['3']
            );
        } catch (\Exception $e) {
            $this->addError('Error in file: ' . pathinfo($file, PATHINFO_FILENAME) . '.' . pathinfo($file, PATHINFO_EXTENSION) . ' - ' . $e->getMessage());
            $errors++;
        }
    }

    if($errors > 0 ) {
        throw new \Exception('Error during parse file: ' . $file . ' - some records not stored.');
    }
    return true;
}
```
