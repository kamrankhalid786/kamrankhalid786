## Manage The `CustomerProduct` Order Creation in The Service Logistic

**Author:** Anouar

### Table of Content
- [Overview](#overview)
- [Code Process](#code-process)
- [Create the Order in the Service Logistic Process Description](#create-the-order-in-the-service-logistic-process-description)
- [On Terminal Ordered Process Description](#on-terminal-ordered-process-description)
- [On Terminal Ordered Process Description](#on-customer-terminal-ordered-process-description)

### Overview

After we have created the terminals (CustomerProduct) [here](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/mange-terminals-creation-with-pax-store.md), we have a scheduled job **`OrderProductsCronJob`** that runs every 5 minutes starting from minute `3` within `local`, `staging`, and `production` environments. This job triggers the cron **`OrderProductsCron`** that will process the creation of `CustomerProduct` orders in **Service Logistic**:

### Code Process

1. First, we will fetch all the (`CustomerProduct`) that match the following criteria:
   - Terminals that are already created on **PAX Store** or other products that do not require that, such as **VT** and **PBL**
   - `CustomerProduct` status must be `APPROVED`
   - `Product` `supplier_id` must be `Supplier::PAX`
   - `CustomerProduct` contract must be completed, and the related `CustomerFinanceAgreement` approved

2. We start the order creation process in **Service Logistic** by invoking the function **`ServiceLogisticsService@createOrder`** [Create the Order in the Service Logistic Process Description](#create-the-order-in-the-service-logistic-process-description)

3. When all products are created in the service logistics, we will do the following:
   - For each product, we will invoke the function `onTerminalOrdered` [On Terminal Ordered Process Description](#on-terminal-ordered-process-description)
   - For each customer-specific product, we will invoke the function `onCustomerTerminalsOrdered` [On Customer Terminal Ordered Process Description](#on-customer-terminal-ordered-process-description)

#### Create the Order in the Service Logistic Process Description

1. We create a spreadsheet instance.
2. We add the terminals `CustomerProduct` to that spreadsheet.
3. We generate a local file for the `'service-logistics-order-form-v1-' . uniqid() . '.xlsx'`.
4. We save the spreadsheet data to the generated local file.
5. We invoke the function `MailingService->sendEmail` to send the spreadsheet file to the service logistic email `mail.service_logistics.new_order`.
6. At the end, we return true to indicate that the file is sent to the service logistic email.

#### On Terminal Ordered Process Description

1. Update the `CustomerProduct` `status` to `ORDERED` and the `ordered_at` to the current time.
2. Invoke the `UpdateCustomerOverallStatusAction` action; at this point, the `Customer` `overall_status` will be updated to `TERMINAL_ORDERED`.
3. Invoke the function `CustomerDeliveryService@onProductOrdered`, which changes the `CustomerDeliveryPackage` `status` to `STATUS_ORDER_RECEIVED` and sets an estimated arrival time.
4. Record a log for `CUSTOMER_PRODUCT_ORDERED` with a new `CustomerOperationLog`.

#### On Customer Terminal Ordered Process Description

1. Notify the `Customer` that their terminal is ordered.
2. Notify the Partner that their customer's terminal is ordered.
