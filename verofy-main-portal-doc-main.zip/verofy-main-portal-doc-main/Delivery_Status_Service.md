# Delivery Status Service [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

## Table of Contents

- [Introduction](#introduction)
- [Scheduling](#scheduling)
- [Command](#command)
- [Method](#method)
- [Detailed Description](#detailed-description)

![Customer Delivery Diagram](CR-onboarding-final-stage/Customer_Delivery.png)

## Introduction

The `handle` method in the `Delivery Status Service` is responsible for updating the status of customer products in contracts where at least one product has been delivered (status 50) and at least one product has not been delivered (status <= 40). The status of these products is updated to `NOT_YET_TRANSACTED` (status 41).

## Scheduling

| Method | Description |
| --- | --- |
| `job(CheckServiceLogisticDeliveryStatusCronJob::class, JobType::CRON_1)` | Schedules the `CheckServiceLogisticDeliveryStatusCronJob` to run as a cron job. |
| `environments(['local', 'staging', 'production'])` | Specifies that the job should run in the 'local', 'staging', and 'production' environments. |
| `dailyAt('20:00')` | Schedules the job to run daily at 20:00. |
| `timezone('Europe/London')` | Sets the timezone for the job to 'Europe/London'. |
| `withoutOverlapping(5)` | Prevents the job from running if it's already running. If the job is still running after 5 minutes, another instance of the job can start. |
| `onOneServer()` | Ensures that the job only runs on one server when using a server cluster. |

## Command

service-logistics:check-delivery-status

## Method

```php
public function handle()
{
    // All contracts with more than 1 product
    $contracts = DB::table('customer_products')
        ->select(
            'customer_contract_id',
            DB::raw('COUNT(customer_contract_id) as qty'),
        )
        ->whereNotNull('customer_contract_id')
        ->where('status', '<=', 50)
        ->groupBy('customer_contract_id')
        ->having('qty', '>', 1)
        ->get()
    ;

    // At least one product with a delivery status 50 - LIVE_TRN_THIS_MONTH
    $contractsWithDeliveredProduct = DB::table('customer_products')
        ->select(['customer_contract_id'])
        ->whereIn('customer_contract_id', $contracts->pluck('customer_contract_id'))
        ->where('status', 50)
        ->get()
    ;

    // At least one product with not delivered - status <= 40
    $contractsWithDeliveredProduct = CustomerProduct::query()
        ->whereIn('customer_contract_id', $contractsWithDeliveredProduct->pluck('customer_contract_id'))
        ->where('status', '<=', 40)
        ->get()
    ;

    // Update status to NOT_YET_TRANSACTED
    foreach($contractsWithDeliveredProduct as $customerProduct) {
        $customerProduct->status = 41; // NOT_YET_TRANSACTED
        $customerProduct->save();
    }

    return 0;
}
```

## Detailed Description

The `handle` method works by performing the following steps:

1. Fetching Contracts with More Than One Product: The method starts by fetching all contracts that have more than one product with a status of 50 or less.

2. Identifying Contracts with Delivered Products: The method then identifies contracts from the previous step that have at least one product with a status of 50.

3. Identifying Contracts with Not Delivered Products: The method further filters the contracts from the previous step to only include those that have at least one product with a status of 40 or less.

4. Updating Product Status: Finally, the method updates the status of the products in the filtered contracts to `NOT_YET_TRANSACTED` (status 41).
