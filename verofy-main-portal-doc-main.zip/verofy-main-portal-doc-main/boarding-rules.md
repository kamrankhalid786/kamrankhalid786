### Boarding rules statuses
- STATUS_AWAITING_DATA: When the boarding rule first get created
- STATUS_AWAITING_CHECK: When dependencies check is passed
- STATUS_PASS: When dependencies check and rule check passed
- STATUS_DID_NOT_PASS: When the dependencies check pass and the rule check did not
- STATUS_AWAITING_MANUAL_CHECK: Set when the rule check is passed
- STATUS_FAILED: Set when an exception occurs

### When initial boarding rules for customer get generated ?
When the customer's main applicant triggers a `POST /completion` request from the mobile app, we will generate the following initial boarding rules using `CompleteCustomerAction` that are with the `level` **LEVEL_CUSTOMER** :

### MANUAL_CHECK `ManualCheckBoardingRule`

- **label**: Manual check
- **is_manual_action_enabled**: true
- **is_auto_recheck_enabled**: true
- **is_recheck_enabled**: false
- **sort_order**: 1
- **group**: GROUP_MANUAL
- **level**: LEVEL_CUSTOMER

### V9_SCORE `V9ScoreBoardingRule`

- **label**: Verofy Score
- **is_manual_action_enabled**: true
- **is_auto_recheck_enabled**: true
- **is_recheck_enabled**: true
- **sort_order**: 1
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### MCC_RISK `MccRiskBoardingRule`

- **label**: MCC - risk
- **is_manual_action_enabled**: true
- **sort_order**: 21
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### DUPLICITY_CHECK `DuplicityCheckBoardingRule`

- **label**: Potential duplicity found in the system
- **is_manual_action_enabled**: true
- **sort_order**: 22
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### V1_MATCH `V1MatchBoardingRule`

- **label**: Potential duplicity found in V1
- **is_manual_action_enabled**: true
- **sort_order**: 22
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### COMPANY_IN_W2 `CompanyInW2BoardingRule`

- **label**: Is the company in a W2 list
- **is_manual_action_enabled**: true
- **specific_business_types**: [COMPANY, LP_LLP]
- **sort_order**: 22
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### W2_RISK_SCORE `W2RiskScoreBoardingRule`

- **label**: W2 - risk score > 40
- **is_manual_action_enabled**: true
- **specific_business_types**: [COMPANY, LP_LLP]
- **sort_order**: 20
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### BANK_VALIDATION `BankValidationBoardingRule`

- **label**: Bank account validation
- **is_manual_action_enabled**: true
- **sort_order**: 22
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### VAT_VALIDATION `VatValidationBoardingRule`

- **label**: VAT validation
- **is_manual_action_enabled**: true
- **sort_order**: 23
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### REVIEW_SCRAPER `ReviewScraperBoardingRule`

- **label**: Review scraper
- **is_manual_action_enabled**: true
- **sort_order**: 24
- **group**: GROUP_COMPANY
- **level**: LEVEL_CUSTOMER

### VERIFIED_SHAREHOLDERS `VerifiedShareholdersBoardingRule`

- **label**: Verified shareholders
- **is_manual_action_enabled**: true
- **group**: GROUP_KYC
- **level**: LEVEL_CUSTOMER
- **is_auto_recheck_enabled**: true

### APPLICANT_VALID_ID `ApplicantValidIdBoardingRule`

- **label**: ID - DL / Passport
- **is_manual_action_enabled**: true
- **sort_order**: 40
- **group**: GROUP_KYC
- **level**: LEVEL_APPLICANT
- **parent_rule_id**: VERIFIED_SHAREHOLDERS

### APPLICANT_VALID_ID_CLASSIFICATION `ApplicantValidIdClassificationBoardingRule`

- **label**: ID Classification
- **is_manual_action_enabled**: true
- **sort_order**: 41
- **group**: GROUP_KYC
- **level**: LEVEL_APPLICANT
- **parent_rule_id**: VERIFIED_SHAREHOLDERS

### APPLICANT_VALID_ID_EXPIRATION `ApplicantValidIdExpirationBoardingRule`

- **label**: ID EXPIRATION is valid (valid to = expiration date today + 1 month)
- **is_manual_action_enabled**: true
- **sort_order**: 42
- **group**: GROUP_KYC
- **level**: LEVEL_APPLICANT
- **parent_rule_id**: VERIFIED_SHAREHOLDERS

### APPLICANT_IDENTICAL_SELFIE_TO_ID_PHOTO `ApplicantIdenticalSelfieToIdPhotoBoardingRule`

- **label**: Selfie = Photo on ID
- **is_manual_action_enabled**: true
- **sort_order**: 43
- **group**: GROUP_KYC
- **level**: LEVEL_APPLICANT
- **parent_rule_id**: VERIFIED_SHAREHOLDERS

### APPLICANT_IDENTICAL_DETAILS_TO_ID `ApplicantIdenticalDetailsToIdBoardingRule`

- **label**: Is Name from ID is the same in owner
- **is_manual_action_enabled**: true
- **sort_order**: 44
- **group**: GROUP_KYC
- **level**: LEVEL_APPLICANT
- **parent_rule_id**: VERIFIED_SHAREHOLDERS

### APPLICANT_IS_IN_PEP_AND_SANCTION `ApplicantIsInPepAndSanctionBoardingRule`

- **label**: Is the applicant in a PEP (politically exposed person) and SANCTION
- **is_manual_action_enabled**: true
- **sort_order**: 30
- **group**: GROUP_KYC
- **level**: LEVEL_APPLICANT
- **parent_rule_id**: VERIFIED_SHAREHOLDERS

### APPLICANT_IDENTITY_CHECK `ApplicantIdentityCheckBoardingRule`

- **label**: Is the applicant in a W2 - Identity check
- **is_manual_action_enabled**: true
- **sort_order**: 32
- **group**: GROUP_KYC
- **level**: LEVEL_APPLICANT
- **parent_rule_id**: VERIFIED_SHAREHOLDERS

### APPLICANT_EXPERIAN `ApplicantExperianBoardingRule`

- **label**: Experian
- **is_manual_action_enabled**: true
- **specific_business_types**: [SOLE_TRADER, PARTNERSHIP]
- **group**: GROUP_KYC
- **level**: LEVEL_APPLICANT
- **parent_rule_id**: VERIFIED_SHAREHOLDERS

### SITE_VISIT `SiteVisitBoardingRule`

- **label**: Proof of address provided by the customer
- **is_manual_action_enabled**: true
- **group**: GROUP_KYC
- **level**: LEVEL_CUSTOMER

### SELLER_SITE_VISIT `SellerSiteVisitBoardingRule`

- **label**: Seller Site Visit
- **is_manual_action_enabled**: true
- **group**: GROUP_KYC
- **level**: LEVEL_CUSTOMER

### ANY_DIRECTOR_IS_IN_PEP_AND_SANCTION `AnyDirectorIsInPepAndSanctionBoardingRule`

- **label**: Is any director or owner in the W2 PEP (politically exposed person) and SANCTION
- **is_manual_action_enabled**: true
- **sort_order**: 31
- **group**: GROUP_APPLICANT
- **level**: LEVEL_CUSTOMER

### ALL_DIRECTORS_EXPERIAN `AllDirectorsExperianBoardingRule`

- **label**: Experian check for all directors
- **is_manual_action_enabled**: true
- **sort_order**: 31
- **group**: GROUP_APPLICANT
- **level**: LEVEL_CUSTOMER
- **specific_business_types**: [COMPANY, LP_LLP]
- **is_auto_recheck_enabled**: true


