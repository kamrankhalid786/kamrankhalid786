# Diagrams

```mermaid
graph TD
    subgraph v1/user-check-login
    A[App Version Validation] --> B(User Retrieval)
    B -->|No User| C[Fake Response]
    B -->|User Found| D[Portal Determination]
    end
```

```mermaid
graph TD
    subgraph /auth/user-check-app
    E[User Retrieval] -->|No User| F[Fake Response]
    E -->|User Found| G[Customer User Retrieval]
    G -->|Not Found| H['Not Found' Response]
    G --> I[App Action Determination]
    I --> J[Two-Factor Auth]
    end
```

```mermaid
graph TD
    subgraph LoginController.getAppAction
    K[Variable Initialization]
    K --> L[Additional KYC Check]
    L --> M[Main Applicant Check]
    L --> N[Shareholder/Partner Check]
    L --> O[Active Customer Check]
    M -->|Conditions Met| P['ACTION_RETURNED']
    N -->|Conditions Met| P
    O -->|Conditions Met| P
    L -->|Conditions Not Met| Q[Default Action]
    end
```

```mermaid
graph TD
    subgraph /auth/user-check
    R[User Retrieval] -->|No User| S[Fake Response]
    R -->|User Found| T[Pre-Login Actions]
    T --> U[Two-Factor Auth Decision]
    U -->|Required| V[Two-Factor Auth Initiation]
    U -->|Not Required| W[Success Response - No 2FA]
    end
```

```mermaid
graph TD
    subgraph /auth/2fa-verification-app
    X[User Retrieval] -->|No User| Y[Invalid Response]
    X -->|User w/o Customer| Z['Not Found' Response]
    X -->|User w/ Customer| AA[App Action Determination]
    AA -->|CUSTOMER_LOGIN| BB[2FA Verification]
    BB --> CC[Trusted Device Reg]
    CC --> DD[Token Generation]
    DD --> EE[KYC Doc Token Gen]
    EE --> FF[KYC Start Tracking]
    FF --> GG[Delivery Days Calc]
    GG --> HH[Success Response]
    end

    classDef validation fill:#FCE4EC,stroke-width:0.5px,color:#000;
    classDef retrieval fill:#E8F5E9,stroke-width:0.5px,color:#000;
    classDef decision fill:#FFFDE7,stroke-width:0.5px,color:#000;
    classDef action fill:#E1BEE7,stroke-width:0.5px,color:#000;
    classDef response fill:#D7CCC8,stroke-width:0.5px,color:#000;
    classDef exception fill:#FFCDD2,stroke-width:0.5px,color:#000;
    class A validation; class K validation; class B validation; class C validation; class D validation; class E validation; class F validation; class G validation; class R validation; class S validation;
    class I decision; class J decision; class U decision; class V decision; class O decision; class P decision; class Q decision;
    class D action; class H action;
    class F response; class S response; class W response; class Y response; class Z response;
    class X exception;
    class BB action; class CC action; class DD action; class EE action; class FF action; class GG action; class HH action;
```

```mermaid
graph TD
    A[App Version Check] --> B(User Retrieval)
    B --> |No User| C[Fake Response: Invalid Version/User Not Found]
    B --> |User Found| D[Portal Determination]
    D --> |Customer/Partner| E[Response: Portal Info] 
    E --> F[User Retrieval auth/user-check-app]

    F --> |No User| G[Fake Response: 2FA, ACTION]
    F --> |User Found| H[Cust. User Retrieval]
    H --> |Not Found| I[Not Found Response]
    H --> |Found| J[App Action Determination]
    J --> |ACTION_RETURNED| K[2FA?]
    K --> |Yes| L[2FA Initiation auth/user-check]
    K --> |No| M[Response: ACTION No 2FA]
    M --> |ACTION == CUSTOMER_LOGIN| Z[2FA Verification uth/2fa-verification-app]
    
    L --> |No User| P[Fake Response: 2FA]
    L --> |User Found| Q[Pre-Login Actions]
    Q --> R[2FA?]
    R --> |Yes| S[2FA Initiation auth/2fa-verification-app]
    R --> |No| U[Response: Login Success]

    S --> |No User| W[Invalid Response]
    S --> |User w/o Customer| X[Not Found Response]
    S --> |User w/ Customer| Y[App Action Check]
    Y --> |ACTION != CUSTOMER_LOGIN| Z[2FA Verification]

    Z --> AA[2FA Verification]
    AA --> |Success| AB[Trusted Device Reg]
    AB --> AC[Token Generation]
    AC --> AD[KYC Token - If Needed]
    AD --> AE[KYC Tracking - If Needed]
    AE --> AF[Delivery Calc - If Needed]
    AF --> AG[Success Response: All Details]


    classDef validation fill:#FCE4EC,stroke-width:0.5px,color:#000;
    classDef retrieval fill:#E8F5E9,stroke-width:0.5px,color:#000;
    classDef decision fill:#FFFDE7,stroke-width:0.5px,color:#000;
    classDef action fill:#E1BEE7,stroke-width:0.5px,color:#000;
    classDef response fill:#D7CCC8,stroke-width:0.5px,color:#000;
    classDef exception fill:#FFCDD2,stroke-width:0.5px,color:#000;
```

```mermaid
graph TD
    subgraph Preload Basic Data
        A[GET /enums]
        B[GET /maps.googleapis.com/maps/api/geocode]
    end
    A --> C{App Action<br> CUSTOMER_REGISTRATION_MAIN_APPLICANT}
    C --> D[Preload Customer Data]
    subgraph Preload Customer Data
        E[GET /Customer-card-rates]
        F[GET /Finance-contracts]
        G[GET /Customer-products]
        H[GET /Contracts]
        I[GET /Customer-standard-fees]
    end
    E --> D
    F --> D
    G --> D
    H --> D
    I --> D
    D --> J[POST /Operation-log: kyc-business-package-confirmed]
    J --> K[POST /amex]
    K --> L{CUSTOMER_REGISTRATION_PARTNER_SHAREHOLDER <br> CUSTOMER_REGISTRATION_MAIN_APPLICANT}
    L --> M[Identity KYC]
    subgraph Identity KYC
        N[POST /kyc-documents/documents]
        O[POST /kyc-documents/selfie]
    end
    N --> M
    O --> M
    M --> P[POST /Operation-log: kyc-identity-verified]
    P --> Q[Business Overview]
    Q --> R[POST /Operation-log: kyc-business-details-confirmed]
    R --> S{Proof of Address Provided?}
    S -- No --> T[POST /Operation-log: kyc-proof-of-address-uploaded]
    S -- Yes --> U[Bank Validation]
    T --> U
    U --> V[POST /bank-account]
    V --> W{Proof of Bank Provided?}
    W -- No --> X[POST /kyc-documents/proof-of-bank]
    W -- Yes --> X
    X --> Y[Agreements and Signature]
    Y --> Z[GET /direct-debit]
    Z --> AA[POST /Operation-log: kyc-paperwork-confirmed]
    AA --> AB{Signature Provided?}
    AB -- No --> AC[POST /Operation-log: kyc-contract-signed]
    AB -- Yes --> AC
    AC --> AD{Other Shareholders?}
    AD -- No --> AE{CUSTOMER_REGISTRATION_PARTNER_SHAREHOLDER <br> CUSTOMER_USER_ACCOUNT_ACTIVATION <br> CUSTOMER_REGISTRATION_MAIN_APPLICANT}
    AD -- Yes --> AE
    AE --> AF{User Account Activated?}
    AF -- No --> AG[Security]
    AF -- Yes --> AH[KYC Finished Confirmation]
    AG --> AI[POST /pin]
    AI --> AJ[POST /Operation-log: kyc-security-setup-completed]
    AJ --> AH
    AH --> BK[POST /confirmation]
```
