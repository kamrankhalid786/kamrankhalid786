# Customer Boarding Rules Services [![Version 1.0](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Customer_Boarding_Service.txt)

## List of Boarding Rules Services

| Rule ID | Boarding Rule Service |
| --- | --- |
| manual_check | ManualCheckBoardingRule |
| v9_score | V9ScoreBoardingRule |
| mcc_risk | MccRiskBoardingRule |
| duplicity_check | DuplicityCheckBoardingRule |
| v1_match | V1MatchBoardingRule |
| company_in_w2 | CompanyInW2BoardingRule |
| w2_risk_score | W2RiskScoreBoardingRule |
| bank_validation | BankValidationBoardingRule |
| vat_validation | VatValidationBoardingRule |
| review_scraper | ReviewScraperBoardingRule |
| verified_shareholders | VerifiedShareholdersBoardingRule |
| site_visit | SiteVisitBoardingRule |
| seller_site_visit | SellerSiteVisitBoardingRule |
| any_director_is_in_pep_and_sanction | AnyDirectorIsInPepAndSanctionBoardingRule |
| all_directors_experian | AllDirectorsExperianBoardingRule |
| applicant_valid_id | ApplicantValidIdBoardingRule |
| applicant_valid_id_classification | ApplicantValidIdClassificationBoardingRule |
| applicant_valid_id_expiration | ApplicantValidIdExpirationBoardingRule |
| applicant_identical_selfie_to_id_photo | ApplicantIdenticalSelfieToIdPhotoBoardingRule |
| applicant_identical_details_to_id | ApplicantIdenticalDetailsToIdBoardingRule |
| applicant_is_in_pep_and_sanction | ApplicantIsInPepAndSanctionBoardingRule |
| applicant_identity_check | ApplicantIdentityCheckBoardingRule |
| applicant_experian | ApplicantExperianBoardingRule |
