# Boarding Over All Status [![Version 1.0](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Customer_Boarding_Service.txt)

## Customer Boarding Rule Statuses

| Status | Changing Point |
| --- | --- |
| `STATUS_AWAITING_DATA` | When a customer boarding rule is created and waiting for data |
| `STATUS_AWAITING_CHECK` | When the data is ready and the rule is waiting to be checked |
| `STATUS_DID_NOT_PASS` | When the rule check is completed and the rule did not pass |
| `STATUS_AWAITING_MANUAL_CHECK` | When the rule check is completed and it's waiting for a manual check |
| `STATUS_PASS` | When the rule check is completed and the rule passed |
| `STATUS_FAILED` | When an exception occurs during the rule check process |
