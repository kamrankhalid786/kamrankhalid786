## Finalize Customer Boarding by Handling the `status`, `overall_status`, and `CustomerBoardingRule` `status`
**Author:** Anouar

### Overview
After the customer has completed its boarding process, we use the `BoardCustomers` cron to handle the boarding `status` and `Customer` `overall_status` and `status`.

### Code Process

1. The `BoardCustomers` cron is scheduled to run every minute.
  
2. We fetch all the customers that should be boarded (Customers with `is_boarded = false`, `has_boardable_rules = true`, `check_boarding_rules = true`, `attention_required = false`, and `status` in `[AWAITING_MAIN_COMPLETION, AWAITING_COMPLETION, AWAITING_ACTIVATION]`).
```php
        $query = Customer::query();

        if (!empty($customerId)) {
            $query->where('id', $customerId);
        }

        $customers = $query->shouldBeBoarded()
            ->take(100)
            ->get();
```
3. For each customer, we fetch their `CustomerBoardingRule`s where the `status` is `STATUS_AWAITING_DATA` and `is_processing_since` is null.

```php
     foreach ($customers as $customer)
        {
            $customerBoardingRules = $customer->boardingRules()
                ->where('status', CustomerBoardingRule::STATUS_AWAITING_DATA)
                ->whereNull('is_processing_since') // Make sure it's not being processed already.
                ->get();
            // ...
        }
```

4. Then for each `CustomerBoardingRule`, we check the rule status under the job `CheckBoardingRuleJob`.

```php
           foreach ($customers as $customer)
        {
            // ...
            foreach ($customerBoardingRules as $customerBoardingRule) {
                CheckBoardingRuleJob::dispatch($customerBoardingRule->id);
                $customerBoardingRule->is_processing_since = Carbon::now();
                $customerBoardingRule->save();
            }
            //...
        }
```
  - We check the rule by calling the function `checkRule` under the service `CustomerBoardingRulesService`.
  
  ```php
      public function handle()
      {
          $this->customerBoardingRulesService = App::make(CustomerBoardingRulesService::class);
  
          try {
              //...
              $customerBoardingRule = $this->customerBoardingRulesService->checkRule($customerBoardingRule);
          } catch (\Throwable $e) {
              // ...
          }
  
      }
  ```
  - Check if `CustomerBoardingRule` has parent; If yes assign it to its parrent boarding rule
 
  ```php
    public function checkRule(CustomerBoardingRule $customerBoardingRule): CustomerBoardingRule
    {
        $customer = $customerBoardingRule->customer;
        $customerApplicant = $customerBoardingRule->customerApplicant;

        // Update parent rule id.
        $rule = BoardingRule::findOrFail($customerBoardingRule->rule_id);
        $parentRuleId = Arr::get($rule, 'parent_rule_id');
        if (!empty($parentRuleId)) {
            $parentCustomerBoardingRule = $customer->boardingRules()->where('rule_id', $parentRuleId)->first();
            $customerBoardingRule->parentRule()->associate($parentCustomerBoardingRule);
            $customerBoardingRule->save();
        }
        // ...

    }
  ```
  - If the rule status is `STATUS_AWAITING_DATA`, we load the boarding rule service, then check the rule dependencies. If completed, we change it to `STATUS_AWAITING_CHECK`.

  ```php
    public function checkRule(CustomerBoardingRule $customerBoardingRule): CustomerBoardingRule
    {
      // ...
        try {
            // Check dependencies to be sure there is enough data for specific boarding rule.
            if ($customerBoardingRule->status === CustomerBoardingRule::STATUS_AWAITING_DATA) {
                $customerBoardingRule = $this->checkRuleDependencies($customerBoardingRule);
            }
            // ..
        } catch (\Throwable $e) {
            // ...
        }

        return $customerBoardingRule;
    }
  ```
  - If the `BoardingRule` `is_auto_recheck_enabled` is `true` and the `CustomerBoardingRule` `status` is `STATUS_DID_NOT_PASS` or `STATUS_AWAITING_MANUAL_CHECK` (for this, clear log will be disabled), we change the status to `STATUS_AWAITING_CHECK`.
  
  ```php
        $clearCheckLog = true;
        if (
            BoardingRule::isAutoRecheckEnabled($customerBoardingRule->rule_id)
            && (
                ($customerBoardingRule->status === CustomerBoardingRule::STATUS_DID_NOT_PASS)
                || ($customerBoardingRule->status === CustomerBoardingRule::STATUS_AWAITING_MANUAL_CHECK)
            )
        ) {
            if ($customerBoardingRule->status === CustomerBoardingRule::STATUS_AWAITING_MANUAL_CHECK) {
                $clearCheckLog = false;
            }
            $customerBoardingRule = $this->updateRuleStatus($customerBoardingRule, CustomerBoardingRule::STATUS_AWAITING_CHECK);
        }
  ```
  
  - At this point, if the customer boarding rule status is not equal to `STATUS_AWAITING_CHECK`, we return the boarding rule.
  
  ```php
      if ($customerBoardingRule->status !== CustomerBoardingRule::STATUS_AWAITING_CHECK) {
          return $customerBoardingRule;
      }
  ```
  
  - If `CustomerBoardingRule` `status` equals to `STATUS_AWAITING_CHECK`, then we check if `clearCheckLog` is enabled.
    - We call the `clearCheckLog` function under the `CustomerBoardingRule` which log the append the current `check_log` to the `check_log_history` and clear `check_log`.
  
  ```php
      // ...
      if ($clearCheckLog) {
          $customerBoardingRule->clearCheckLog();
      }

      //...
  ```
  
  - We load the boarding rule service using the given `CustomerBoardingRule`, then call the `checkRule` function on it.
  
  - If the check returns `true` (passed):
    - We update the customer boarding rule status to `STATUS_AWAITING_MANUAL_CHECK`.
  
  - If the check returns `false` (check failed):
    - We update the customer boarding rule status to `STATUS_AWAITING_MANUAL_CHECK` if manual check is enabled for that rule. If not, we set it to `STATUS_DID_NOT_PASS`.
  
  - If `BoardingRule` `is_auto_recheck_enabled` is not enabled for the given `CustomerBoardingRule`, we track the operation log under `CustomerOperationLog`.
  
  - If the `CustomerApplicant` is set for this `CustomerBoardingRule`, we set the applicant as boarded if ready.
  
  - At the end, we set the customer as boarded if all their boarding rules are passed.
    - Update the following customer fields:
      - `is_boarded` to `true`
      - `boarded_at` to `now()`
      - `status` to `ACTIVE`
      - `overall_status` to `AWAITING_MID`
        
  ```php
      // checkRule()
      // ...
      $pass = $this->loadBoardingRuleService($customerBoardingRule)->checkRule($customerBoardingRule);

      $manualCheck = BoardingRule::isManualActionEnabled($customerBoardingRule->rule_id);
      $autoPassEnabled = BoardingRule::isAutoPassEnabled($customerBoardingRule->rule_id);

      $customerBoardingRule = $this->updateRuleStatus($customerBoardingRule, ($pass === true)
          ? ($autoPassEnabled
              ? CustomerBoardingRule::STATUS_PASS
              : CustomerBoardingRule::STATUS_AWAITING_MANUAL_CHECK)
          : ($manualCheck
              ? CustomerBoardingRule::STATUS_AWAITING_MANUAL_CHECK
              : CustomerBoardingRule::STATUS_DID_NOT_PASS));

      if (!BoardingRule::isAutoRecheckEnabled($customerBoardingRule->rule_id)) {
          // Track the operation.
          $this->customerOperationLogService->logOperation(
              $customerBoardingRule->customer,
              CustomerOperation::BOARDING_RULE_CHECKED,
              BoardingRule::getRuleName($customerBoardingRule->rule_id),
              customerBoardingRule: $customerBoardingRule
          );
      }

      // Check boarding done.
      if ($customerApplicant) {
          $this->setApplicantBoardedIfReady($customerApplicant);
      }
      $this->setBoardedIfReady($customer);
  ```
  
  ```php
      public function setBoardedIfReady(Customer $customer)
      {
          // Check already boarded customer.
          if ($customer->is_boarded === true) {
              throw new Exception('Customer has been already boarded');
          }
  
          // Check any not pass rules.
          $notPass = $customer->boardingRules()
              ->where('status', '!=', CustomerBoardingRule::STATUS_PASS)
              ->count();
          if ($notPass > 0) {
              return;
          }
  
          // Track the operation.
          $this->customerOperationLogService->logOperation(
              $customer,
              CustomerOperation::BOARDING_DONE
          );
  
          // Set is_boarded flag.
          $customer->boarded_at = Carbon::now();
          $customer->is_boarded = true;
          $customer->save();
  
          // Mark customer as active.
          $this->customerService->onActivated($customer);
  
          // Update customer user groups.
          $this->customerUsersService->updateUserGroupsAfterCustomerActivation($customer);
      }
  ```

  - We update user groups after activation:
    - Assign the admins group to the customer.
    - Re-assign the main user to the admins group.
    - Assign the customer's users with KYC required to the admin group.
    - Assign the standard users group to the customer.
    - Assign the rest of the customer's users with KYC not required to the standard group.
    - Detach the awaiting mid activation group from the customer.
