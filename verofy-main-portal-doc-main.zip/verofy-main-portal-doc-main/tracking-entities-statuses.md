## Tracking The Entities Status During The Customer Onboarding Process
**Author**: Anouar

### Overview

During customer onboarding, different entities update their statuses to show progress and completion. Here's how these statuses change throughout the process.


### Customer Statuses During Onboarding Process

| Status                   | Description                                         |
|--------------------------|-----------------------------------------------------|
| AWAITING_MAIN_COMPLETION | Set when the partner portal registration part completed|
| AWAITING_COMPLETION      | Set when the customer main applicant complete KYC  |
| AWAITING_ACTIVATION      | Set when the customer completes the application from the web portal and shareholders completed KYC and and site visit completed |
| ACTIVE                   | Set when the cron `BoardCustomers` runs and all the customer boarding rules are passed |

### Customer Overall Statuses During Onboarding Process

| Overall Status           | Description                        |
|--------------------------|------------------------------------|
| AWAITING_MERCHANT_COMPLETION | Set when the partner portal registration part completed |
| ONBOARDING_COMPLETE      | Set when the customer completes the application from the web portal and (no app referred, no KYC boarding referred) |
| KYC_REFER                | Set when the customer completes the application from the web portal and KYC boarding rule referred 30 min after onboarding completion |
| REFERRED_APPLICATION     | Set when the customer completes the application from the web portal and has referred application |
| AWAITING_MID             | Set when the cron `BoardCustomers` runs and all the customer boarding rules are passed |
| MID_APPROVED             | Set when the cron `BamboraEnrollmentsCron` runs and the results from Bambora related to all customer `CustomerMid` s is approved |
| APPLICATION_APPROVED    | Set when the cron `CheckFirstDataApprovalReportsCron` runs  and the received report from **First Data** is approved |
| TERMINAL_ORDERED    |Set when the cron `OrderProductsCron` runs and all the customer products are sent to **Service Logistic** |
| TERMINAL_DELIVERED    |Set when the cron `CustomerDeliveryLogisticsCron` runs and we fetch the delivery logistics file from `s3` if the file is for ordered products and the status is delivred |
| TERMINAL_DISPATCHED    |Set when the cron `CustomerDeliveryLogisticsCron` runs and we fetch the delivery logistics file from `s3` if the file is for dispatched products |
| MERCHANT_NOT_TRANSACTED    |Set when the cron `CheckNoPaymentTakenCustomersCronJob` runs and the customer did not transact within `24 hours` after delivery |

### CustomerBoardingRule Statuses During Onboarding Process

| Status                      | Description                              |
|-----------------------------|------------------------------------------|
| STATUS_AWAITING_DATA        | Set when the customer completes the application from the web portal and his boarding rules get initialized |
| STATUS_AWAITING_CHECK       | Set when the cron `BoardCustomers` runs and the customer boarding rule dependencies are passed |
| STATUS_AWAITING_MANUAL_CHECK| Set when the cron `BoardCustomers` runs  and the customer boarding rule check is passed and **is_auto_pass_enabled** is not set; or if the rule check did not pass but the rule has **is_manual_action_enabled** is set |
| STATUS_DID_NOT_PASS         | Set when the cron `BoardCustomers`  and the customer boarding rule check is did not pass and the rule has **is_manual_action_enabled** is not set |
| STATUS_PASS                 | Set when the cron `BoardCustomers` runs and the customer boarding rule check is passed and **is_auto_pass_enabled** is set|
| STATUS_FAILED               | Set when the cron `BoardCustomers` runs and durring the customer boarding rule check an exception thrown |

### BamboraSubmerchant Statuses During Onboarding Process

| Status                      | Description                              |
|-----------------------------|------------------------------------------|
| SUBMERCHANT_STATUS_NEW      | Set when the cron `BoardMidsCron` runs and the `BamboraSubmerchant` created |
| SUBMERCHANT_STATUS_PROCESSED| Set when the cron `BamboraEnrollmentsCron` runs and the submerchant added to the XML file and sent to Bambora |

### CustomerUser Statuses During Onboarding Process

| Status                      | Description                              |
|-----------------------------|------------------------------------------|
| STATUS_AWAITING_ACTIVATION | Set when the partner portal registration part completed|
| STATUS_ACTIVE              | Set when the customer change his pin |

### CustomerProduct Statuses During Onboarding Process

| Status                      | Description                              |
|-----------------------------|------------------------------------------|
| ADDED then APPROVED        | Set when the seller completes the application |
| DISPATCHED                 | Set when the cron `BamboraEnrollmentsCron` runs and approving `CustomerMid` sub-merchant if he has VT/PBL products exists with status `APPROVED`; or when the cron `CustomerDeliveryLogisticsCron` runs and we fetch the delivery logistics file from `s3` if the file is for dispatched products |
| ORDERED                 | Set when the cron `OrderProductsCron` runs and all the customer products sent to service logistic |
| LIVE_TRN_THIS_MONTH     | Set when the cron `SetProductsLiveCron` runs and the customer has transacted more than `15` pounds |

### CustomerProduct Pax Statuses During Onboarding Process

| pax_status                      | Description                              |
|-----------------------------|------------------------------------------|
| PAX_STATUS_NEW        | Set when the cron `PaxStoreCreateTerminalsCron` runs and the terminal first created in **Pax Store** |
| PAX_STATUS_VARIABLES_CREATED  | Set when the cron `PaxStoreCreateTerminalsCron` runs and the terminal variables created in **Pax Store** |
| PAX_STATUS_POSITIVE_PLUS_MANAGER_APP_PUSHED | Set when the cron `PaxStoreCreateTerminalsCron` runs, and we push the positive plus manager app to **Pax Store** |
| PAX_STATUS_POSITIVE_PLUS_APP_PUSHED | Set when the cron `PaxStoreCreateTerminalsCron` runs, and we push the positive plus app to **Pax Store** |

### CustomerDeliveryPackage Statuses During Onboarding Process

| status                      | Description                              |
|-----------------------------|------------------------------------------|
| STATUS_ORDER_RECEIVED       | Set when the cron `OrderProductsCron` runs and all the customer products sent to service logistic |
| STATUS_DELIVERED       | Set when the cron `CustomerDeliveryLogisticsCron` runs and we fetch the delivery logistics file from `s3` if the file is for ordered products and the status is `delivred`|
| STATUS_IN_TRANSIT       | Set when the cron `CustomerDeliveryLogisticsCron` runs and we fetch the delivery logistics file from `s3` if the file is for ordered products and the status is `in_transit`|
| STATUS_READY_FOR_COLLECTION  | Set when the cron `CustomerDeliveryLogisticsCron` runs and we fetch the delivery logistics file from `s3` if the file is for dispatched products|
| STATUS_PACKED_FOR_SHIPMENT  | Set when the cron `CustomerDeliveryLogisticsCron` runs and we fetch the delivery logistics file from `s3` if the file is for allocation products|

### CustomerMid Statuses During Onboarding Process

| Status                      | Description                              |
|-----------------------------|------------------------------------------|
| AWAITING_BOARDING          | Set when the seller completes the application |
| AWAITING_MID_ACTIVATION    | Set when the cron `BoardMidsCron` runs and the `BamboraSubmerchant` are created |
| MID_APPROVED               | Set when the cron `BamboraEnrollmentsCron` runs and the results from Bambora related to that `CustomerMid` submerchant is approved |

### CustomerContract Statuses During Onboarding Process

| Status                      | Description                              |
|-----------------------------|------------------------------------------|
| AWAITING_COMPLETION        | Set when the seller completes the application |
| CONTRACT_COMPLETED         | Set when the cron `CheckFirstDataApprovalReportsCron` runs  and we fetch the **first data** reports received by email and it is approved and `CustomerContract` status is `SIGNED` and all the contract finance agreement are approved|

### CustomerFinanceAgreement Statuses During Onboarding Process

| Status                      | Description                              |
|-----------------------------|------------------------------------------|
| NEW                        | Set when the seller completes the application |
| READY_FOR_AUDIT_TRAIL      | Set when the cron `SendFinanceAgreementsCron` runs and all the documents generate(finance agreement, additional data, google address) |
| READY_TO_SEND_DATA      |Set when the cron `SignCustomerDocumentsCron` runs and generate the Evevlop with audit trail and sign it |
| PENDING      |Set when the cron `SendFinanceAgreementsCron` runs and `CustomerFinanceAgreement` status is `READY_TO_SEND_DATA` and the `first_data_status` is  `FIRST_DATA_STATUS_API_SENT` and all the documents sent by email succesfully to **first data**  |
| APPROVED| Set when the cron `CheckFirstDataApprovalReportsCron` runs  and we fetch the **first data** reports received by email and it is approved|

### CustomerFinanceAgreement Fisrt Data Statuses During Onboarding Process

| first_data_status                      | Description                              |
|-----------------------------|------------------------------------------|
| FIRST_DATA_STATUS_NEW       | Set when the seller completes the application |
| FIRST_DATA_STATUS_API_SENT  | Set when the cron `SendFinanceAgreementsCron` runs and `CustomerFinanceAgreement` status is `READY_TO_SEND_DATA` and the `first_data_status` is  `FIRST_DATA_STATUS_NEW` and all `DATA` is prepared to be sent |
| FIRST_DATA_STATUS_EMAIL_SENT  | Set when the cron `SendFinanceAgreementsCron` runs and `CustomerFinanceAgreement` status is `READY_TO_SEND_DATA` and the `first_data_status` is  `FIRST_DATA_STATUS_API_SENT` and all the documents sent by email succesfully to **first data** |

### SignPack Statuses During Onboarding Process

| Status                      | Description                              |
|-----------------------------|------------------------------------------|
| STATUS_NEW                 | Set when the seller completes the application |
| STATUS_READY_FOR_AUDIT_TRAIL| Set when the cron `SendFinanceAgreementsCron` runs and all the documents generate(finance agreement, additional data, google address|
| STATUS_COMPLETED| Set when the cron `SignCustomerDocumentsCron` runs and generate the Evevlop with audit trail and sign it|

### FirstDataApprovalReportRow Statuses During Onboarding Process

| status                      | Description                              |
|-----------------------------|------------------------------------------|
| REPORT_PROCESS_STATUS_NEW| Set when the cron `CheckFirstDataApprovalReportsCron` runs and we fetch all the reports received from **First Data** by email. Then, we create `FirstDataApprovalReportRow`|

### FirstDataApprovalReportRow Process Statuses During Onboarding Process

| process_status                      | Description                              |
|-----------------------------|------------------------------------------|
| REPORT_PROCESS_STATUS_FAILED| Set when the cron `CheckFirstDataApprovalReportsCron` runs  and we fetch the **First Data** reports received by email and the following is true:Customer within the report not found; Customer finance agreement with customer and contract from report not found; Report status not approved|

### FirstDataDeclinedReport Statuses During Onboarding Process

| status                      | Description                              |
|-----------------------------|------------------------------------------|
| PROCESS_STATUS_NEW| Set when the cron `CheckFirstDataDeclinedReportsCron` runs  and we have some declined report from **First Data** |
