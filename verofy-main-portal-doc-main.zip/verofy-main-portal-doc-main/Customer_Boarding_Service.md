# Customer Onboarding Process [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Customer_Boarding_Service.txt)

## Table of Contents

- [Introduction](#introduction)
- [Code Flow Diagram](#code-flow-diagram)
- [Kernel Configuration](#kernel-configuration)
- [Job: BoardCustomersJob](#job-boardcustomersjob)
- [Command: customers:process-boarding](#command-customersprocess-boarding)
- [Business Logic: checkBoardingRules](#business-logic-checkboardingrules)
- [Job: CheckBoardingRuleJob](#job-checkboardingrulejob)
- [Service: CustomerBoardingRulesService](#service-customerboardingrulesservice)
- [List of Boarding Rules Services](CR-Boarding-Rules/Boarding_Rules_Services.md)
- [Boarding Over All Status](CR-Boarding-Rules/Boarding_Over_All_Status.md)
- [Boarding Rules and Their Statuses](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/boarding-rules.md)
- [Finalize Customer Boarding: Detailed Process Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/finalize-customer-boarding.md)

![Customer Boarding Service](CR-Boarding-Rules/cr-boarding-rules.png)

## Introduction

This document outlines the process of customer onboarding, detailing the code flow, configuration, and logic involved in verifying customers and their applicants based on predefined boarding rules.

## Code Flow Diagram

```mermaid
graph TD
    A[Kernel: Schedule Job] --> B(BoardCustomersJob)
    B --> C{Command: customers:process-boarding}
    C --> D(BoardCustomers)
    D --> E(checkBoardingRules)
    E --> F{Job: CheckBoardingRuleJob}
    F --> G(CustomerBoardingRulesService)
    G --> H{BoardingRuleService}
    G --> I{ApplicantBoardedIfReady}
    G --> J{BoardedIfReady}
```

## Kernel Configuration

The onboarding process is initiated by a scheduled job defined in the kernel.

| Property | Value |
| --- | --- |
| Scheduler Job Name | `BoardCustomersJob` |
| Environments | `local` `development` `staging` `production` |
| Frequency | Every minute |
| Overlapping | Prevented, with a 5-minute threshold |
| Server Execution | Runs on only one server |

This configuration ensures that the `BoardCustomersJob` runs every minute on one server, preventing overlapping executions.

## Job: BoardCustomersJob

The `BoardCustomersJob` is responsible for triggering the `customers:process-boarding` command.

```php
class BoardCustomersJob
{
    public function handle(): void
    {
        Artisan::call('customers:process-boarding', []);
    }
}
```

## Command: `customers:process-boarding`

The `customers:process-boarding` command. It retrieves an optional customer ID argument and initiates the boarding rule checks.

```php
class BoardCustomers extends Command
{
    protected function getArguments()
    {
        return [
            ['customerId', InputArgument::OPTIONAL, 'The ID of the customer (optional)'],
        ];
    }

    public function handle()
    {
        // Retrieve arguments.
        $customerId = $this->argument('customerId');

        $this->checkBoardingRules($customerId);

        $this->info('Boarding has been finished.');
        return 0;
    }
}
```

## Business Logic: `checkBoardingRules`

The `checkBoardingRules` function retrieves customers who require boarding checks, iterates through their pending boarding rules, and dispatches the `CheckBoardingRuleJob` for each rule.

```php
public function checkBoardingRules(int|null $customerId =  null): void
{
    // ... (Customer retrieval logic) ...

    foreach ($customers as $customer) {
        // ... (Boarding rule processing logic) ...

        foreach ($customerBoardingRules as $customerBoardingRule) {
            CheckBoardingRuleJob::dispatch($customerBoardingRule->id);
            // ...
        }

        // ...
    }
}
```

## Job: CheckBoardingRuleJob

The `CheckBoardingRuleJob` is responsible for executing the boarding rule check for a specific `CustomerBoardingRule`. It utilizes the `CustomerBoardingRulesService` to perform the checks.

```php
class CheckBoardingRuleJob extends Job
{
    // ...

    public function handle()
    {
        // ...

        try {
            // ... (Rule retrieval and validation) ...

            $customerBoardingRule = $this->customerBoardingRulesService->checkRule($customerBoardingRule);
        } catch (\Throwable $e) {
            // ... (Exception handling) ...
        }

        // ...
    }
}
```

## Service: CustomerBoardingRulesService

The `CustomerBoardingRulesService` is the core component for managing boarding rule checks. It loads the appropriate boarding rule service based on the rule ID and executes the `checkRule` method of that service.

### Methods

- `checkRule(CustomerBoardingRule $customerBoardingRule): CustomerBoardingRule`: Orchestrates the rule checking process, including dependency checks, auto-rechecks, status updates, and logging.
- `loadBoardingRuleService(CustomerBoardingRule $customerBoardingRule): BaseBoardingRule`:  
    Read complete list of boarding rules services [here](CR-Boarding-Rules/Boarding_Rules_Services.md).

Each specific boarding rule service implements the `BaseBoardingRule` interface and provides the `checkRule` method for its specific rule logic.

## Useful Links

### [List of Boarding Rules Services](CR-Boarding-Rules/Boarding_Rules_Services.md)

### [Boarding Over All Status](CR-Boarding-Rules/Boarding_Over_All_Status.md)
