## Managing Bambora Submerchants enrollements.

**Author:** Anouar
### Table of Contents
- [Overview](#overview)
- [Code Process](#code-process)
    - [Submerchant enrollment](#generate-the-xml-file-for-submerchant-enrollment-and-send-it-to-bambora)
    - [Process enrollment results](#processing-enrollment-results-fetched-from-bambora)
    - [Code Base](#code-base)
      - [generateEnrollmentXml()](#generateenrollmentxml)
      - [processEnrollmentResults()](#processenrollmentresults)

### Overview
After we have created Bambora merchants (`BamboraSubmerchant`) and updated the `CustomerMid` status to `AWAITING_MID_ACTIVATION` when we run the `BoardMidsCron` cron job, we will now proceed with generating an XML file for submerchant enrollment, and processing the enrollment results from the Bambora service. The enrollment process will be managed by the `BamboraEnrollmentsCron`, which will handle two main actions:
1. Generating an XML file for submerchant enrollment and sending it to **Bambora**.
2. Processing enrollment results fetched from **Bambora**.

### Code Process

We will initiate the `BamboraEnrollmentsCronJob`, scheduled to run every two minutes, which will trigger the execution of the `BamboraEnrollmentsCron` cron in `local` and `production` envirements:

#### Generate the `XML` file for submerchant enrollment and send it to Bambora
1. we will invoke the function `BamboraSubmerchantService@generateEnrollmentXml`.
```php
$this->bamboraSubmerchantService->generateEnrollmentXml();
```
3. We fetch all the `BamboraSubmerchant` which they are not enrolled before `bambora_enrollment_id=null` and  `status` is `SUBMERCHANT_STATUS_NEW`.
4. if no result we will return early.
5. We create `BamboraEnrollment` record like so
    ```
    $enrollment = new BamboraEnrollment();
    $enrollment->file_date = new Carbon('now');
    $enrollment->file_time = new Carbon('now');
    $enrollment->save();
    ```
6. Then we build the XML file structure for the merchants (`BamboraMerchant`) we have fetched previously by looping through all of them.
      - First we create enrollment tag `<enrollment xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="submerchant_enrollment_request.xsd">`
      - Then we create the `<merchants>` tag and within it, we will nest all the submerchants.
          - Associate the `BamboraSubmerchant` within the created enrollment `BamboraEnrollment`.
          - Fetch the `Customer` using the `customer_id` from the merchant: `Customer::find($submerchant->customer_id)`.
          - Get the `registration_number` from the customer to use it as a `legalId`.
          - If the customer `registration_number` is not set, we will check if that customer has `primary_contact_dob`. If not, we will throw an exception. If so, we will set the `legalId` by concatenating `primary_contact_dob` and the `BamboraSubmerchant` Id.
          - Fetch the customer business address. If not found, we will throw an exception.
          - Add the `<submerchant>` XML tag and nest the following tags:
        
            | XML Tag                | Description                                                                                                  |
            |------------------------|--------------------------------------------------------------------------------------------------------------|
            | pf_account_id          | We set its value from `BamboraSubmerchant` `pf_account_id`.                                                  |
            | legal_id               | The legal id will be either set from customer `registration_number` or we will define it by concatenating the customer `primary_contact_dob` and the `BamboraSubmerchant` ID. |
            | legal_name             | We set its value from `Customer` `legal_name`.                                                                |
            | legal_address          | We set its value from the fetched business address `CustomerAddress` by using the full street address.       |
            | legal_city             | We set its value from `CustomerAddress` business address `city`.                                              |
            | legal_postcode         | We set its value from `CustomerAddress` business address `postcode`.                                          |
            | legal_country          | We set its value from `CustomerAddress` business address `country->code`.                                     |
            | dba_name               | We set its value from `Customer` `trading_name`.                                                              |
            | dba_address            | We set its value from the fetched business address `CustomerAddress` by using the full street address.       |
            | dba_city               | We set its value from `CustomerAddress` business address `city`.                                              |
            | dba_postcode           | We set its value from `CustomerAddress` business address `postcode`.                                          |
            | contact_email          | We set its value from `Customer` `primary_contact_email`.                                                     |
            | contact_phone          | We set its value from `Customer` `primary_contact_phone`.                                                     |
            | contact_name           | We set its value from `Customer` `primary_contact_fullname`.                                                  |
            | proxy_mid              | We set its value from `BamboraSubmerchant` `proxy_mid`.                                                       |
            | country_of_origin      | We set its value from `CustomerAddress` business address `country->code`.                                     |
            | customer_service_phone | We set its value from `Customer` `primary_contact_phone`.                                                     |
        - At the end, we close the `<submerchant>` tag `</submerchant>`.
        - Then we change the `BamboraSubmerchant` status to `SUBMERCHANT_STATUS_PROCESSED`.
        - If an exception is thrown, we change the `BamboraSubmerchant` status to `SUBMERCHANT_STATUS_ERROR`.

7. We will close the submerchants tag `</submerchants>`.
8. We create the summary tag `<summary>`.
9. We create the fileid tag `<fileid>`: its value will be set using the `BamboraEnrollment` `id`.
10. We create the filedate tag `<filedate>`: its value will be set using the `BamboraEnrollment` `file_date`.
11. We create the filetime tag `<filetime>`: its value will be set using the `BamboraEnrollment` `file_time`.
12. We create the submerchant_count tag `<submerchant_count>`: its value will be set by the count of `BamboraSubmerchant` we have fetched.
13. Then we close `</summary>` and `</enrollment>`.
14. If any exception is thrown, we will update the current `BamboraEnrollment` `status` to `SUBMERCHANT_STATUS_NEW` and set `bambora_enrollment_id` to `null`, then we invoke the recursive call to the function `generateEnrollmentXml`, and then we return.
15. If the XML file is built for all the fetched `BamboraSubmerchant`s.
16. We count all the `BamboraEnrollments` that are created today.
17. We set the `increment` variable by padding the count by `3`: `str_pad($count= 10, 3, '0', STR_PAD_LEFT) // 010`.
18. We define the file path as `'V9ENROLL_' . $increment . '.' . $todayFormat. '.pgp'`.
19. Then we set the created `BamboraEnrollment` `file_name` to the built path: `$enrollment->file_name = $filePath;`.
20. Now we will encrypt the generated `xml` file using the `BamboraCryptService` by invoking the function `encrypt`
      - First we will create new instance of `gnupg` service to encrypt our xml file
      - We will invoke the `import` function of `gnupg` and pass to it our bambora public key 
      - then we invoke `addencryptkey` and pass to it the `fingerprint` we get from the response of the previous call to `import`
      - Then we invoke the `encrypt` to encrypt the xml file and return it

21. We store the encrypted xml file content localy under the previously generated file path
22. Then we call the `uploadEnrollmentFile` to upload the file into bambora
      - We get the file name including it extension
      - Then we transfer the content of the encrypted xml file (previously stored in local path) into the `'toBAMBORA/' . $fileName` which exists under bambora, using the `bambora_sft` disk  which uses the SFTP protocol.
      - if something goes wrong we throw an exception and record the exception message under `LogService`
23. Then we call the `moveEnrollmentToS3` to upload the file to `S3`
      - We get the file name including it extension
      - Then we transfer the content of the encrypted xml file (previously stored in local path) into the `'bambora/enrollments/' . $fileName`  , using the `S3_DISK` disk  .
      - We delete the local file after the uplad succeed
      - then we returnt the upload result
      - if something goes wrong we throw an exception and record the exception message under `LogService`

24. then we will build the xml file path from the original copy `$xmlFilePath = 'V9ENROLL_' . $increment . '.' . $todayFormat. '.xml`
25. We upload this original copy (non encrypted) to `S3`


#### Processing enrollment results fetched from bambora
1. Invoke the function `BamboraSubmerchantService@processEnrollmentResults`.
2. Fetch all the file from **bambora** under the `fromBAMBORA` folder using the  `bambora_sft` disk  which uses the SFTP protocol to transfer the files.
3. For each file received from Bambora, the following actions take place:
    - Gett the extention of the file
    - IF the extension is not `pgp` we will skip the process of that file
    - Store the file content local under the same file name 
    - Invoke the functions `processResultXML()` then `moveEnrollmentResultToS3`
   
##### Process bambora result with `processResultXML`
1. Fetch the file data
2. Decrypt the file data using the `BamboraCryptService` by invoking the function `decrypt`
      - First we will create new instance of `gnupg` service
      - We will invoke the `import` function of `gnupg` and pass to it our bambora decrypt private key 
      - then we invoke `adddecryptkey` and pass to it the `fingerprint` we get from the response of the previous call to `import`
      - Invoke the `decrypt` function to decrypt the file data and return it

3. Store the decrypted file localy with the same name prefixed with `decoded_`
4. Convert the decrypted file we have stored local to an xml object
5. Encoding the xml object to `JSON` fomat then convert it to an associative array
6. We fetch the `summary` , `rejections` and `approvals` value from the associative array 
7. Fecth the `BamboraEnrollment` using the `fileid` from the `sammary` array
8. If not found we will log the error with `LogService` and throw the exception
9. We fetch the `approved_count` and `rejected_count` from the `summary` array
10. Fetches the enrollment submerchants using the fetch `BamboraEnrollment` `$submerchants = $enrollment->submerchants`
11. If the count of `approved_count + rejected_count` not equals to number of submmerchants `BamboraSybmerchant` within that `BamboraEnrollment` we will log an error with `LogService` and throw the exception.
12. Update the `BamboraEnrollment` fields `approved_count`, `rejected_count` and `rejections` with value we previously fetched.
13. If the approvals property exists within the `xmlObject` format of our results, the following actions will be taken for each item with the `xmlObject->approvals->approval`:
    - Fetch the merchant using the `pf_account_id` from the `approval` item
    - If submecthant does not exists, an exception will be thrown
    - Update the following for submechant fields:
        - virtual_account_id: `virtual_account_id` from the `approval` item
        - approved: set to `true`

14. If the rejections property exists within the xmlObject format of our results, the following actions will be taken for each item with the `xmlObject->rejections->rejection`:
    - Fetch the merchant using the `pf_account_id` from the `rejection` item
    - If submecthant does not exists, an exception will be thrown
    - Update the following for submechant fields:
        - rejection_code: `reason_code` from the `rejection` item
        - approved: set to `0` (`false`)
15. Will Loop through all `BamboraEnrollment` submerchants `BamboraSubmerchant` then the following actions will be taken for each submerchant `BamoboraSubmerchat`
   - If the submerchant is not approved (approved field value is 0) then we will skip this merchant
   - Update the submerchant `approved` field to `true` 
   - Fetch the `CustomerMid` from the submerchant `$submerchant->customerMid`
   - If `CustomerMid` `status` equals to `AWAITING_MID_ACTIVATION` we will take the following actions:
     - Update the `CustomerMid` `mid` field to be the combined values of submerchant `pf_account_id` and `proxy_mid` `$submerchant->pf_account_id . $submerchant->proxy_mid`
     - Dispatching the event `CustomerMidApproved` will trigger the listener `OnCustomerMidApproved`, which will invoke the function `midApproved` within the `CustomerMidService` service.
   - By invoking the `midApproved` function the following actions will be taken
     - Fetch the VT product from the customer within the `CustomerMid` `$mid->customer->getVirtualTerminal($mid)`
        - IF the VT exists and its status `APPROVED` we will change it to `DISPATCHED`
     - Fetch the PBL product from the customer within the `CustomerMid` `$mid->customer->getPayByLink($mid)`
        - IF the PBL exists and its status `APPROVED` we will change it to `DISPATCHED`

     - Update the `CustomerMid` `status` to `CustomerMidStatus::MID_APPROVED`  and `approved_at` to the current time
     - Invoke the `UpdateCustomerOverallStatusAction` action to update the customer `overall_status` at this point will be `CustomerOverallStatus::MID_APPROVED`
     - We will do one more check to ensure that all the customer mids are approved
     ```
     $notApprovedMids = $mid->customer->mids()
            ->where('status', '!=', CustomerMidStatus::MID_APPROVED)
            ->count()
     ```
     - IF all of the customer mids are approved then we take the following actions:
       - Notify the seller that his customer has thier MID approved. If something goes wrong we will log the error with `LogService`
       - We fetch the customer pax terminal, VT and PBL using the `products` relation and filter down by `CustomerProduct` code.
       - IF customer does not have pax terminal
         - We notify customer that his account is **activated** by sending him `sms` , `email` , `push-notification`, `cloud-message`
         - Notify Seller that the customer is **apporved** 
         - Invoke the `ActivateCustomerAccountAction` which will invite customer SDI shareholder to complete their KYC by doanloading the app.
           - We fetch all the customer applicants `CustomerApplicant` and for each of them we will sent an invitation to download the mobile app, then we update the `CustomerApplicant` `kyc_requested_at` to the current time
           - Then we record `SDI_SHAREHOLDER_INVITED` action  within the `CustomerOperationLog`
       - IF customer has VT or PBL
         - We send notification to seller that his customer now can transact using VT or PBL
     - Dispatch the `SendFinanceAgreementsCronJob` job which will execute the `SendFinanceAgreementsCron` check [Handle Finance agreement](finance-company-first-data.md)
     - At the end we return the `CustomerMid`

16. If `BamboraEnrollment` `rejected_count` value is greater than `0` we will notify admin user about unapproved MID

### Code Base

### `generateEnrollmentXml()`
```php
    public function generateEnrollmentXml()
    {
        $submerchants = $this->getSubmerchantsForEnrollment();
        if($submerchants->count() < 1) {
            return;
        }
        $enrollment = new BamboraEnrollment();
        $enrollment->file_date = new Carbon('now');
        $enrollment->file_time = new Carbon('now');
        $enrollment->save();
        try {
            $xml = '<?xml version="1.0" encoding="UTF-8"?>';
            $xml .= '<enrollment xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:noNamespaceSchemaLocation="submerchant_enrollment_request.xsd">';
            $xml .= '<submerchants>';
            foreach ($submerchants as $submerchant) {
                try {
                    $enrollment->submerchants()->save($submerchant);
                    $customer = Customer::find($submerchant->customer_id);
                    $legalId = $customer->registration_number;
                    if(!$legalId) {
                        if(!$customer->primary_contact_dob) {
                            throw new \Exception('Missing customer dob.');
                        }
                        $legalId = (new Carbon($customer->primary_contact_dob))->format('Ymd') . $submerchant->id;
                    }
                    $businessAddress = $customer?->getBussinesAddress();
                    if (!$businessAddress) {
                        throw new \Exception('Missing customer business address.');
                    }
                    $xml .= '<submerchant>';
                    $xml .= '<pf_account_id>' . $submerchant->pf_account_id . '</pf_account_id>';
                    $xml .= '<legal_id>' .  $legalId . '</legal_id>';
                    $xml .= '<legal_name>' . Str::limit(str_replace('&', 'and',$customer->legal_name), 30, '') . '</legal_name>';
                    $xml .= '<legal_address>' . Str::limit(str_replace('&', 'and', $businessAddress->getFullStreetAddress()), 50, '') . '</legal_address>';
                    $xml .= '<legal_city>' . Str::limit($businessAddress->city, 20, '') . '</legal_city>';
                    $xml .= '<legal_postcode>' . Str::limit($businessAddress->postcode, 10, '') . '</legal_postcode>';
                    $xml .= '<legal_country>' . Str::limit($businessAddress->country->code,2, '') . '</legal_country>';
                    $xml .= '<dba_name>' . Str::limit(str_replace('&', 'and',$customer->trading_name), 17, '') . '</dba_name>';
                    $xml .= '<dba_address>' . Str::limit(str_replace('&', 'and', $businessAddress->getFullStreetAddress()), 45, '') . '</dba_address>';
                    $xml .= '<dba_city>' . Str::limit($businessAddress->city, 13, '') . '</dba_city>';
                    $xml .= '<dba_postcode>' . Str::limit($businessAddress->postcode, 10, '') . '</dba_postcode>';
                    $xml .= '<contact_email>' . Str::limit($customer->primary_contact_email, 40, '') . '</contact_email>';
                    $xml .= '<contact_phone>' . Str::limit($customer->primary_contact_phone, 30, '') . '</contact_phone>';
                    $xml .= '<contact_name>' . Str::limit($customer->primary_contact_fullname, 40, '') . '</contact_name>';
                    $xml .= '<proxy_mid>' . $submerchant->proxy_mid . '</proxy_mid>';
                    $xml .= '<country_of_origin>' . Str::limit($businessAddress->country->code,2, '') . '</country_of_origin>';
                    $xml .= '<customer_service_phone>' . Str::limit(str_replace('+', '', $customer->primary_contact_phone), 30, '') . '</customer_service_phone>';
                    $xml .= '</submerchant>';
                    $submerchant->status = self::SUBMERCHANT_STATUS_PROCESSED;
                    $submerchant->save();
                } catch (\Exception $e) {
                    $submerchant->status = self::SUBMERCHANT_STATUS_ERROR;
                    $submerchant->save();
                    throw new \Exception('Submerchant status error' . $e->getMessage());
                }
            }
            $xml .= '</submerchants>';
            $xml .= '<summary>';
            $xml .= '<fileid>' . $enrollment->id . '</fileid>';
            $xml .= '<filedate>' . (new Carbon($enrollment->file_date))->format('Ymd') . '</filedate>';
            $xml .= '<filetime>' . (new Carbon($enrollment->file_time))->format('His') . '</filetime>';
            $xml .= '<submerchant_count>' . $submerchants->count() . '</submerchant_count>';
            $xml .= '</summary>';
            $xml .= '</enrollment>';
        } catch (\Exception $e) {
            BamboraSubmerchant::where('bambora_enrollment_id', '=', $enrollment->id)
            ->where('status', '=', self::SUBMERCHANT_STATUS_PROCESSED)
            ->update(['bambora_enrollment_id' => null, 'status' => self::SUBMERCHANT_STATUS_NEW]);
            $this->generateEnrollmentXml();
            return;
        }

        $today = new Carbon('now');
        $todayFormat = $today->format('Ymd');
        $count = BamboraEnrollment::where('file_date', '=', $todayFormat)->count();
        $increment = str_pad($count, 3, '0', STR_PAD_LEFT);
        $filePath = 'V9ENROLL_' . $increment . '.' . $todayFormat. '.pgp';
        $enrollment->file_name = $filePath;
        $enrollment->save();
        $xmlCopy = $xml;
        $xml = $this->cryptService->encrypt($xml);
        Storage::disk(self::LOCAL_DISK)->put($filePath, $xml);
        if(!$this->uploadEnrollmentFile($filePath)) {
            throw new \Exception('Error uploading bambora enrollment file to sftp');
        }
        if(!$this->moveEnrollmentToS3($filePath)) {
            throw new \Exception('Error uploading bambora enrollment file to s3');
        }
        $xmlFilePath = 'V9ENROLL_' . $increment . '.' . $todayFormat. '.xml';
        Storage::disk(self::LOCAL_DISK)->put($xmlFilePath, $xmlCopy);
        if(!$this->moveEnrollmentToS3($xmlFilePath)) {
            throw new \Exception('Error uploading bambora enrollment file to s3');
        }
    }
```
### `processEnrollmentResults()`
```php
    public function processEnrollmentResults()
    {
        try {
            $files = Storage::disk(self::SFTP_DISK)->files('fromBAMBORA');
            foreach ($files as $file) {
                $extension = File::extension($file);
                if($extension == 'pgp') {
                    Storage::disk(self::LOCAL_DISK)->put($file, Storage::disk(self::SFTP_DISK)->get($file));
                    $this->processResultXML($file);
                    $this->moveEnrollmentResultToS3($file);
                }
            }
        } catch (\Exception $e) {
            LogService::log(1, [], $e->getMessage());
            throw new \Exception($e->getMessage());
        }
    }
```
#### Meeting QA:

##### what data we send to bambora and how we send it ?
The data we collect and format: When enrolling the submerchant to Bambora, we gather submerchant information such as `pf_account_id`, `legal_name`, `legal_address`, `legal_city`, `legal_country`, and more. Subsequently, we construct an XML file containing all the necessary data required for enrollment.then we encrypt this xml file with our public key then upload it to bambora using the `SFTP` protocol

##### How we respond to bambora response result?
First, we will fetch all the files under the `fromBAMBORA` directory. For each file, we will decrypt its content using our Bambora private key and convert it to an object. After that, we will store the decrypted version locally. If the result contains **approvals**, we will update the submerchant's `cirtual_account_id` to `virtual_account_id` from the `approval` item and set `approved` to `true`. If it contains **rejections**, we will update the submerchant's `rejection_code` to `reason_code` from the `rejection` item and set `approved` to `false`.

##### What happens when bambora fails?
If the response has any `rejected_count` greater than `0` we will notify admin users about

##### How admins get notified when failed?
we send notification to admin users about unapproved MID for the given `BamboraEnrollment`

##### If passed what happend and how we much mid with customer?
For each submerchant that is approved, if its `CustomerMid` `status` equals `AWAITING_MID_ACTIVATION`, we will set the `CustomerMid` `mid` field to be the combined values of the submerchant's `pf_account_id` and `proxy_mid` (`$submerchant->pf_account_id . $submerchant->proxy_mid`). Then, we dispatch the event `CustomerMidApproved`, which triggers the listener `OnCustomerMidApproved`. This listener will invoke the function `midApproved` within the `CustomerMidService` service.
