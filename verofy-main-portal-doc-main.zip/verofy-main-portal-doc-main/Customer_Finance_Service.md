# Customer Finance Service [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Customer_Finance_Service.txt)

## Table of Contents

- [Introduction](#introduction)
- [Business Logic](#business-logic)
- [Code Flow Diagram](#code-flow-diagram)
- [SendFinanceAgreementsCronJob](#sendfinanceagreementscronjob)
- [SendFinanceAgreementsCron](#sendfinanceagreementscron)
- [prepareAgreementToBeSent Method](#prepareagreementtobesent-method)
- [sendToFinanceCompany Method](#sendtofinancecompany-method)
- [sendMerchantData Method](First_Data/Send_Merchant_JSON_Data.md)
- [sendToFirstData Method](First_Data/First_Data_Api.md)
- [sendEmailToFirstData Method](First_Data/Send_Email.md)
- [Approved Customer Finance](First_Data/Approved.md)
- [Declined Customer Finance](First_Data/Declined.md)
- [Send Finance Agreement: Detailed Process Description](finance-company-first-data.md)

![Customer Finace Diagram](First_Data/customer-finance.png)

## Introduction

This document describes the business logic, flow, and code structure of a system that sends finance agreements to a finance company using First Data. The process involves multiple steps and classes, including the midApproved method of CustomerMidService, the SendFinanceAgreementsCronJob and SendFinanceAgreementsCron classes, and the CustomerFinanceService class with its prepareAgreementToBeSent and sendToFinanceCompany methods.

## Business Logic

1. Trigger the `midApproved` method of `CustomerMidService`.
2. Call the `SendFinanceAgreementsCronJob` class to process finance agreements in the background.
3. Execute the `SendFinanceAgreementsCron` console command to send agreements to the finance company.
4. Use the `CustomerFinanceService` class to prepare the agreement to be sent and send it to the finance company.
5. Call the `prepareAgreementToBeSent` method to generate necessary documents.
6. Call the `sendToFinanceCompany` method to send merchant data and an email to First Data.

## Code Flow Diagram

        +--------------------+     +---------------------------------------+
        | midApproved Method | --> | CustomerMidService                     |
        +--------------------+     +---------------------------------------+
                                                    |
                                                    | Dispatch
                                                    v
        +--------------------------------------------+     +------------------------------------------------------------------------------+
        | SendFinanceAgreementsCronJob::dispatch     | --> | SendFinanceAgreementsCronJob (Unique based on customer ID)                   |
        +--------------------------------------------+     +------------------------------------------------------------------------------+
                                                    |
                                                    | Execute Command
                                                    v
        +--------------------------------------------+     +------------------------------------------------------------------------------+
        | SendFinanceAgreementsCron::handle          | --> | SendFinanceAgreementsCron (Command: finance-agreements:send-to-finance-company) |
        +--------------------------------------------+     +------------------------------------------------------------------------------+
                                                    |
                                                    | Prepare or Send Agreement
                                                    v
        +--------------------------------------------+     +------------------------------------------------------------------------------+
        | CustomerFinanceService                     |     | prepareAgreementToBeSent or sendToFinanceCompany                             |
        +--------------------------------------------+     +------------------------------------------------------------------------------+
                                                    |
                                                    | Generate Documents or Send Data
                                                    v
        +--------------------------------------------+     +------------------------------------------------------------------------------+
        | FirstDataService                           |     | generateDocuments or sendData                                                |
        +--------------------------------------------+     +------------------------------------------------------------------------------+
                                                    |
                                                    | Send to First Data API
                                                    v
        +--------------------------------------------+     +------------------------------------------------------------------------------+
        | FirstDataApiService                        | --> | sendToFirstDataApi                                                           |
        +--------------------------------------------+     +------------------------------------------------------------------------------+
                                                    |
                                                    | Send Email to First Data
                                                    v
        +--------------------------------------------+     +------------------------------------------------------------------------------+
        | FirstDataService                           | --> | sendEmailToFirstData                                                         |
        +--------------------------------------------+     +------------------------------------------------------------------------------+

## SendFinanceAgreementsCronJob

The `SendFinanceAgreementsCronJob` is a Laravel job class that is designed to be queued for background processing. It is unique based on a customer ID.

### Constructor

The job accepts an optional `customerId` in its constructor. This ID is used to uniquely identify the job, ensuring that only one job for each customer ID is in the queue at any given time.

### Handle Method

The `handle()` method is where the job's logic is executed. It calls an Artisan command named `finance-agreements:send-to-finance-company`, optionally appending the customer ID if it is provided.

### Unique ID

The `uniqueId()` method returns the customer ID, which is used by Laravel to ensure the uniqueness of the job. If two jobs have the same unique ID, Laravel will not dispatch the second job to the queue until the first one has been processed.

## SendFinanceAgreementsCron

The `SendFinanceAgreementsCron` is a Laravel console command that sends finance agreements to a finance company.

### Command Name and Description

The command is named `finance-agreements:send-to-finance-company`. The description of the command is 'Sends agreements to the finance company.'

### Arguments

The command accepts an optional argument `customerId`. This argument can be used to specify a particular customer for whom the agreements should be sent.

### Constructor

The constructor of the command accepts an instance of `CustomerFinanceService`. This service class contains the business logic related to customer finance agreements.

### Handle Method

The `handle()` method is the main execution point of the `finance-agreements:send-to-finance-company` command.

#### Arguments

The method retrieves the `customerId` argument, which is optional and can be used to specify a particular customer for whom the agreements should be sent.

#### Query Preparation

The method prepares a query to fetch finance agreements that need attention and are either new or ready to be sent. If a `customerId` is provided, the query is further filtered to only include agreements for that customer.

The query also includes several other conditions.

- It checks that the customer is active
- All shareholders have finished KYC (Know Your Customer)
- The products have approved MID (Merchant Identification Number).

#### Processing Agreements

After preparing and executing the query, the method retrieves the agreements and iterates over each one. For each agreement:

- If its status is new, it prepares the agreement to be sent using the `prepareAgreementToBeSent()` method of the `CustomerFinanceService`.
- If its status is ready to send data, it sends the agreement to the finance company using the `sendToFinanceCompany()` method of the `CustomerFinanceService`.

#### Completion

After processing all agreements, the method outputs a message indicating that the script has finished and returns 0, indicating that the command has successfully completed.

## prepareAgreementToBeSent Method

The `prepareAgreementToBeSent()` method is part of the `CustomerFinanceService` class and is responsible for preparing a finance agreement to be sent.

### Arguments

The method accepts an instance of `CustomerFinanceAgreement` as an argument. This object represents the finance agreement that needs to be prepared.

### PDF Generation

The method generates several PDF files for the finance agreement:

- A finance agreement PDF is generated using the `generateFirstFinanceAgreementFile()` method of the `firstDataService`.
- An additional info PDF is generated using the `generateAdditionalInfo()` method of the `firstDataService`.
- If a site visit is required, a site visit confirmation PDF is generated using the `generateSiteVisitConfirmation()` method of the `firstDataService`.

If any of the PDF generation steps fail, the method sets the finance agreement's status to require attention and returns `false`. If the PDF generation is successful, the generated document is associated with the finance agreement and saved.

### Google Address Validation

The method checks if the customer has a valid Google address. If the customer has a valid Google address, it creates a file containing the Google address validation result and saves it.

### Audit Trail

Finally, the method calls the `onFinanceReadyForAuditTrail()` method, presumably to log the event of the finance agreement being ready.

### Return Value

The method returns `true` if the preparation of the finance agreement was successful, and `false` otherwise.

## sendToFinanceCompany Method

The `sendToFinanceCompany()` method is part of the `CustomerFinanceService` class and is responsible for sending a finance agreement to a finance company.

### Arguments

The method accepts an instance of `CustomerFinanceAgreement` as an argument. This object represents the finance agreement that needs to be sent.

### Sending Merchant Data

The method first checks if the `first_data_status` of the finance agreement is `FIRST_DATA_STATUS_NEW`. If it is, it sends the merchant data to the finance company using the `sendMerchantData()` method of the `firstDataService`. It then updates the `first_data_id` and `first_data_status` of the finance agreement and saves the changes.

If an exception occurs during this process, it releases the assigned TIDs (Transaction Identifiers), logs the exception, sets the finance agreement's status to require attention, and returns `false`.

### Sending Email

Next, the method checks if the `first_data_status` of the finance agreement is `FIRST_DATA_STATUS_API_SENT`. If it is, it sends an email to the finance company using the `sendEmailToFirstData()` method of the `firstDataService`. It then updates the `first_data_status` of the finance agreement, saves the changes, and calls the `onFinanceSent()` method, presumably to log the event of the finance agreement being sent.

If an exception occurs during this process, it logs the exception, sets the finance agreement's status to require attention, and returns `false`.

### Return Value

The method returns `true` if the sending of the finance agreement was successful, and `false` otherwise.

## Useful Links

### [sendMerchantData Method](First_Data/Send_Merchant_JSON_Data.md)

### [sendToFirstData Method](First_Data/First_Data_Api.md)

### [sendEmailToFirstData Method](First_Data/Send_Email.md)

### [Approved Customer Finance](First_Data/Approved.md)

### [Declined Customer Finance](First_Data/Declined.md)
