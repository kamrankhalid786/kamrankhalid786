# First Transaction Service [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](First_Transaction_Service.txt)

## Table of Contents

- [Introduction](#introduction)
- [Kernel](#kernel)
- [Job](#job)
- [Command](#command)
- [Code Flow Diagram](#code-flow-diagram)
- [Service](#service)
  - [Conditions](#conditions)

![First Transaction Diagram](CR-onboarding-final-stage/first_transaction.png)

## Introduction

This document provides an overview of the `FirstTransactionService`, which is responsible for setting live products for customers. The service checks if a product has been dispatched and if the total amount of transactions for the product is greater than or equal to 15. If these conditions are met, the product is set to live and the first transaction is recorded.

## Kernel

| Property | Value |
| --- | --- |
| Scheduler Job Name | `SetProductsLiveCronJob` |
| Environments | `local` `staging` `production` |
| Frequency | Every minute |
| Overlapping | Prevented, with a 5-minute threshold |
| Server Execution | Runs on only one server |

## Job

The `SetProductsLiveCronJob` handles the execution of the `customer-products:set-live` artisan command.

```php
public function handle(): void
{
    Artisan::call('customer-products:set-live',[]);
}
```

## Command

The `SetProductsLiveCron` command retrieves the customer ID as an optional argument and calls the `checkLiveProductsToBeSet` method of the `CustomerProductsService`.

```php
protected function getArguments()
{
    return [
        ['customerId', InputArgument::OPTIONAL, 'The ID of the customer (optional)'],
    ];
}

public function handle()
{
    // Retrieve arguments.
    $customerId = $this->argument('customerId');

    $this->customerProductsService->checkLiveProductsToBeSet($customerId);
}
```

## Code Flow Diagram

```mermaid
graph TD;
    A[Start] --> B{Is customer_id null?}
    B -->|Yes| C[Get all dispatched products]
    B -->|No| D[Get dispatched products for customer_id]
    C --> E{Are there any products?}
    D --> E
    E -->|No| F[End]
    E -->|Yes| G[Iterate through products]
    G --> H{Is product status dispatched?}
    H -->|No| G
    H -->|Yes| I{Total amount >= 15?}
    I -->|No| G
    I -->|Yes| J[Set product live]
    J --> K[Find first transaction for the product]
    K --> L[Notify seller about first transaction if not already notified]
    L --> M[If product is PAX terminal, set VT and PBL live if they are not already live]
    M --> N[If product is VT or PBL, set the other one live if it is not already live]
    N --> O[If product is PAX terminal, set all charging cradles live]
    O --> G
    G --> P[End]
```

## Service

The `CustomerProductsService` checks if there are any products that need to be set live. It queries the `CustomerProduct` model based on the customer ID and product status. If the product status is 'DISPATCHED' and the product code matches any of the specified product codes, the service checks if the total amount of transactions for the product is greater than or equal to 15. If so, the product is set to live and the first transaction is recorded.

```php
public function checkLiveProductsToBeSet(int|null $customerId) {
    // ... code omitted for brevity ...
}
```

### Conditions

| Condition | Value |
| --- | --- |
| Customer ID is not null | `if ($customerId !== null)` |
| Customer product status is dispatched | `where('status', CustomerProductStatus::DISPATCHED)` |
| Product code is one of the specified values | `where('code', ProductCode::PAX_A920_PORTABLE)`, `orWhere('code', ProductCode::PAX_A920_MOBILE)`, `orWhere('code', ProductCode::VIRTUAL_TERMINAL)`, `orWhere('code', ProductCode::PAY_BY_LINK)` |
| Customer is active | `hasActiveCustomer()` |
| Customer product status is not dispatched | `if ($customerProduct->status !== CustomerProductStatus::DISPATCHED)` |
| Total amount of transactions is greater than or equal to 15 | `if(Arr::get($resultTotalAmount, 'total_amount') >= 15)` |
| Messaging event for first transaction has not been sent | `if (!$sentEvent)` |
| Product is a PAX terminal | `if ($customerProduct->isPaxTerminal())` |
| Virtual Terminal product is not live | `if ($virtualTerminal)` |
| Pay By Link product is not live | `if ($payByLink)` |
| Product is a Virtual Terminal | `if ($customerProduct->isVirtualTerminal())` |
| Product is a Pay By Link | `if ($customerProduct->isPayByLink())` |
