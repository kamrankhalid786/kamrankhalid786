
## Manage Customer Product Live state with `SetProductsLiveCronJob`

**Author:** Anouar

### Table of Content
- [Overview](#overview)
- [Code Process](#code-process)

### Overview

After we have imported the logistic data [here](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-delivery-logistics-import.md), we have a scheduled job **`SetProductsLiveCronJob`** that runs every minute within `local`, `staging`, and `production` environments. This job triggers the cron **`SetProductsLiveCron`** that will check if the products need to be set to live by invoking the function `CustomerProductsService@checkLiveProductsToBeSet`:

### Code Process

1. Fetch all the `CustomerProduct` for active customers with the status `DISPATCHED` and product code equal to the following: `PAX_A920_PORTABLE`, `PAX_A920_MOBILE`, `VIRTUAL_TERMINAL`, and `PAY_BY_LINK`.
2. We invoke the function `TransactionsServiceApiService@listCustomerTransactions` to list all the transactions from **Transaction Service** for the given `Customer` and `CustomerProduct`.
3. If the `total_amount` within our response is greater than or equal to `15`, we will do the following:
   - We first try to fetch the first transaction of the product by invoking the function `transactionsServiceApiService->listCustomerTransactions` and add the following filter to only return the first transaction:

     | Key                        | Value                          |
     |----------------------------|--------------------------------|
     | `filter[customer_product_id]` | `$customerProduct->id`      |
     | `order_by`                 | `created_at`                   |
     | `order_by_direction`       | `asc`                          |
     | `per_page`                 | `1`                            |

4. We fetch the transaction creation date.
5. We invoke the function `CustomerProductsService@onProductLive` which will trigger the following actions:
   - Update the `CustomerProduct` `status` of type charging cradle to `LIVE_TRN_THIS_MONTH`.
   - Set `live_at` to the date the transaction was created.
6. Invoke the function `UpdateCustomerOverallStatusAction@handle` which will update the `Customer` `overall_status` to `MERCHANT_ACTIVE_AND_TRANSACTING`.
7. Notify the seller that their finance commission is approved and available for payment.
8. Record a log for `CUSTOMER_PRODUCT_LIVE` with a new `CustomerOperationLog`.
