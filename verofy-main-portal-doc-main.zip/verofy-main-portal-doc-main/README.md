### Hi there 👋

**kamran-khalid-v9/kamran-khalid-v9** is a ✨ Verofy Partner Portal ✨ documentation.

## 🔗 **Services Documentation**

- [13 May MOM](13-May-2024-MOM.md)
- [Flowchart For Tracking The Statuses When Going Through The Customer Onboarding Process](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/track-statuses-on-each-stage.md)
- [Customer Overall Status and Assignment Criteria](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/track-customer-overall-status.md)
- [Entities Statuses Changes During Customer Onboarding Process](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/tracking-entities-statuses.md)
- [List of Status](StatusList.md)
  - [Customer Overall Status](Status/Customer_Over_All_Status.md)
    - [Pre Registration](Status/PRE_REGISTRATION.md)
    - [Awaiting Merchant Completion](Status/AWAITING_MERCHANT_COMPLETION.md)
    - [Awaiting Shareholder Completion](Status/AWAITING_SHAREHOLDER_COMPLETION.md)
- [Customer Site Visit](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/Documentation.md)
- [Customer Boarding Rules](Customer_Boarding_Service.md)
  - [Code Flow Diagram](Customer_Boarding_Service.md#code-flow-diagram)
  - [List of Boarding Rules Services](CR-Boarding-Rules/Boarding_Rules_Services.md)
  - [Boarding Over All Status](CR-Boarding-Rules/Boarding_Over_All_Status.md)
  - [Boarding Rules](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/boarding-rules.md)
  - [Finalize Customer Boarding](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/finalize-customer-boarding.md)
- [Customer Mids Documentation](Customer_MID_Service.md)
  - [Code Flow Diagram](Customer_MID_Service.md#code-flow-diagram)
  - [Manage Customer Mids Awaiting Boarding](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-customer-mid-awaiting-boarding.md)
- [Bambora Documentation](Bambora_Service.md)
  - [Code Flow Diagram](Bambora/Bambora_Code_Flow_Diagram.md)
  - [Bambora Submerchants enrollements detailed process description](manage-bambora-merchants-enrollments.md)
- [Finance Documentation](Customer_Finance_Service.md)
  - [Code Flow Diagram](Customer_Finance_Service.md#code-flow-diagram)
  - [First Data: Json](First_Data/Send_Merchant_JSON_Data.md)
  - [First Data: Email](First_Data/Send_Email.md)
  - [First Data: Api](First_Data/First_Data_Api.md)
  - [Send Finance Agreement: Detailed Process Description](finance-company-first-data.md)
  - [Finance: Approved](First_Data/Approved.md)
    - [Code Flow Diagram](First_Data/Approved.md#code-flow-diagram)
    - [First Data Approval Reports: Detailed Code Execution Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-first-data-approval-report.md)
  - [Finance: Declined](First_Data/Declined.md)
    - [Code Flow Diagram](First_Data/Declined.md#code-flow-diagram)
    - [First Data Declined Reports: Detailed Code Execution Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-first-data-declined-report.md)
- [Pax Documentation](Pax_Store_Service.md)
  - [Code Flow Diagram](Pax_Store_Service.md#code-flow-diagram)
  - [Create Resellers](Pax_Store/Create_PaxStore_Resellers.md)
  - [Create Merchants](Pax_Store/Create_PaxStore_Merchants.md)
  - [Manage Customers Registration In Pax Store: Detailed Process Description](manage-registering-merchants-to-pax-store.md)
  - [Create Terminals](Pax_Store/Create_PaxStore_Terminals.md)
  - [Terminals Creation In The Pax Store: Detailed Process Description](mange-terminals-creation-with-pax-store.md#creating-terminal-variables)
- [Logistics Documentation](Logistics_Service.md)
  - [Code Flow Diagram I](Logistics_Service.md#code-flow-diagram-1)
  - [Code Flow Diagram II](Logistics_Service.md#code-flow-diagram-2)
  - [Manage Order Creation: Detailed Process Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-order-creation.md)
  - [Manage The Import of The Logistic Data: Detailed Process Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-delivery-logistics-import.md)
- [Delivery Status Documentation](Delivery_Status_Service.md)
  - [Manage The Delivery Status: Detailed Process Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-delivery-status.md)
- [First Transaction Documentation](First_Transaction_Service.md)
  - [Code Flow Diagram](First_Transaction_Service.md#code-flow-diagram)
  - [Manage Terminal First Transaction: Detailed Process Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-product-live-state.md)
- [Manage No Transaction Has Been Done After 24 Hours of Delivery](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-no-transaction-after-24h-of-delivery.md)
  
![OnBoarding Final Stage](CR-onboarding-final-stage/CR-onboarding-final-stage.jpg)

A few things about me:

- 🔭 I’m currently working on V9 FinTech products
- 🌱 I’m currently learning Go lang
- 👯 I’m looking to collaborate on opensource AI modals
- 🤔 I’m looking for help with ?? 🐬
- 📫 How to reach me: <kamrankhalid06@gmail.com>
- ⚡ Fun fact: I love to play cricket and watch movies
