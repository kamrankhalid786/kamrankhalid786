## Manage Customer Mids Awaiting Boarding
**Author:** Anouar

### Overview
After we have activated the customer (`status= ACTIVE`, `overall_status=AWAITING_MID`, `is_boarded=true`), now we will use the `BoardMidsCron` to process the customers mids.

### Code Process

- The `BoardMidsCron` cron is scheduled to run every 5 minutes from minute `1 to 59`:
  - We fetch all `CustomerMid` (that has been created when we completed the application from the seller side) that belongs to active customers and with status `AWAITING_BOARDING`.
 ```php
    $query = CustomerMid::query()
        ->hasActiveCustomer()
        ->where('status', CustomerMidStatus::AWAITING_BOARDING);

    // Filter specific customer if needed.
    if ($customerId !== null) {
        $query->where('customer_id', $customerId);
    }

    $customerMids = $query->get();
 ```
  - For each `CustomerMid` we will do the following:
    - First, we will fetch the proxy mid and create the `BamboraSubmerchant`:
      - We fetch the Bambora proxy mid `BamboraProxyMid` using the customer **MCC code** and the business address **country code**.
        ```php
        $proxyMidRow = BamboraProxyMid::where('country', '=', $businessAddress->country->code)->where('mcc', '=', $mccCode)->first();
        ```
      - We fetch the first `CustomerProduct` where it has `CustomerMid`s within the given `CustomerMid` id.
      ```php
        $customerProduct = CustomerProduct::whereHas('customerMids', function(Builder $query) use ($customerMid) {
            $query->where('id', $customerMid->id);
        })->first();
        ```
      - IF the fetched `CustomerProduct` `product_id` is in the list of `EccomProductIds` `[23,24]`.
      - IF yes, the `proxyMid` will be set from `BamboraProxyMid` `ecom_proxy_mid` property. Else, it will be set from `proxy_mid` property.

      ```php
      if (in_array($customerProduct->product_id, $this->getEccomProductIds())) {
          $proxyMid = $proxyMidRow->ecom_proxy_mid;
      } else {
          $proxyMid = $proxyMidRow->proxy_mid;
      }
      ```
      
      - At the end, we create the `BamboraSubmerchant` like so:
      ```php
        $bamboraSubmerchant = new BamboraSubmerchant();
        $bamboraSubmerchant->customer_id = $customer->id;
        $bamboraSubmerchant->customer_mid_id = $customerMid->id;
        $bamboraSubmerchant->proxy_mid = $proxyMid;
        $bamboraSubmerchant->approved = null;
        $bamboraSubmerchant->status = self::SUBMERCHANT_STATUS_NEW;
        $bamboraSubmerchant->save();
        $bamboraSubmerchant->pf_account_id = 10000000 + $bamboraSubmerchant->id;
        $bamboraSubmerchant->save();
      ```
      - Then, we return the `proxyMid`.
    - At the end, we update the `CustomerMid` status to `AWAITING_MID_ACTIVATION`.
