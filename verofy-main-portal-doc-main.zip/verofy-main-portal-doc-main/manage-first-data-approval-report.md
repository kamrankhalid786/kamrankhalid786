## Check First Data Approval Reports

**Author:** Anouar

### Table of Contents
- [Oveview](#overview)
- [Code Process](#code-process)
  - [Save the report recievd by email to S3](#save-the-report-recievd-by-email-to-s3)
  - [Fetch all reports from S3 and store them in the DB](#fetch-all-reports-from-s3-and-store-them-in-the-db)
  - [Process the report from the DB](#process-the-report-from-the-db)

### Ovevriew

After sending the JSON data and the email with all the attachments, we have a scheduled job `CheckFirstDataApprovalReportsCronJob` that runs every five minutes in both `local` and `production` environments to check the First Data approval report. When it is dispatched, it executes the command `CheckFirstDataApprovalReportsCron`, which invokes the function `FirstDataReportService@process`. which will handle three main actions

1. [Save the report received by email to S3](#save-the-report-recievd-by-email-to-s3)
2. [Fetch all reports from S3 and store them within the DB](#fetch-all-reports-from-s3-and-store-them-within-the-db)
3. [Process the report from the DB](#process-the-report-from-the-db)
   
## Code Process

### Save the report recievd by email to S3
1. we will invoke the function `FirstDataImapService@saveReportsToS3` which will do the following:
   - We refresh the access token by calling `ImapOauthService@refreshToken`  which fetches the `access_token` then we save it with the field `imap_oauth_access_token` under `settings` table
   - Using `Imap` we will connect to `incoming_reports` account
   - We fetch the `INBOX` folder
   - Then from the `INBOX` folder we will fetch all the `messages` received from `fdgladmin@fiserv.com` and the `subject` is `FUNDING REPORT FOR`
   - Then for each message we will fetch the attachments and upload them to `s3` uner this path `incoming_reports/first_data/approval_report`
   - We move the processed message to `IMAP_PROCESSED_FOLDER` which `First Data Processed`. if did succeed we will log `FIRST_DATA_REPORT_EXCEPTION` within the `LogService`
2. If something goes wrong we will log `FIRST_DATA_REPORT_EXCEPTION` with the `LogService

### Fetch all reports from S3 and store them in the DB
1. we will invoke the function `FirstDataStorageService@getReportsToProcess` which will fetch all files with the `REPORT_UPLOAD_DIR` 
2. For each report received we will trigger the following actions:
    - if the report extension is not `xlsx` we will skipp that report
    - Saving the report file locally under `firstDataReportTemp` folder
    - Storing the report in our DB by invoking the function `FisrtDataReportService@storeReportToDb`
    - Reading all the data from the `xlsx` a populate an array with all data needed to record `FirstDataApprovalReportRow`
  
      
   | Field              | Value                                                                 |
   |--------------------|-----------------------------------------------------------------------|
   | process_status     | `FirstDataApprovalReportRow::REPORT_PROCESS_STATUS_NEW`               |
   | from_file          | `$fileName` (The name of the file from which the data was extracted)  |
   | vendor             | `$data[$reportMap['vendor']]` (The vendor ID)                        |
   | vendor_name        | `$data[$reportMap['vendor_name']]` (The name of the vendor)          |
   | contract           | `$data[$reportMap['contract']]` (The contract ID)                    |
   | status             | `$data[$reportMap['status']]` (The status of the contract)           |
   | payment_type       | `$data[$reportMap['payment_type']]` (The type of payment)            |
   | payment_type_desc  | `$data[$reportMap['payment_type_desc']]` (The description of the payment type) |
   | amount             | `$data[$reportMap['amount']]` (The amount of the payment)            |
   | customer_id        | `$data[$reportMap['customer_id']]` (The ID of the customer)          |
   | data               | `$data` (The entire row of data from the report)                     |
   | api_invoice_no     | `$data[$reportMap['api_invoice_no']]` (The API invoice number)       |

    - Remove the local version after storing it in the DB
    - At the end we will move the procceed file to `incoming_reports/first_data/approval_report_archive` within `s3`
3. If something goes wrong we will log `FIRST_DATA_REPORT_EXCEPTION` with the `LogService

### Process the report from the DB
1. Fetching all the new repors `FisrDataApprovalReportRow` where the `process_status` is `REPORT_PROCESS_STATUS_NEW`
2. For each report we will process it like so
   - We fetch the `Customer` based on their `CustomerMid`, where the `BamboraSubmerchant` `pf_account_id` matches the `customer_id` within the current report.
   - If the `Customer` not found we update the `FirstDataApprovalReportRow` `process_status` to `REPORT_PROCESS_STATUS_FAILED` and `process_message` to `MESSAGE_CUSTOMER_NOT_FOUND`, then we skip the process of the current report.
   - We fetch the `CustomerFinanceAgreement` based on their `CustomerContract` where `customer_id` matches the `customer_id` within the current report.
   - If the `CustomerFinanceAgreement` not found we update the `FirstDataApprovalReportRow` `process_status` to `REPORT_PROCESS_STATUS_FAILED` and `process_message` to `MESSAGE_AGREEMENT_NOT_FOUND`, then we skip the process of the current report.
   - Then we check the current report `status` :
     - If approved, which means status equal to `S` or `A` ,  then we invoke the `CustomerFinanceService@onFinanceApproved` [On finance approved process description](#on-finance-approved-process-description) 
     - If unapproved, which means the status equals to `U`, then we invoke the `CustomerFinanceService@onFinanceDeclined` (This wont be triggered when we are running the `CheckFirstDataApprovalReportsCron`)
     - If the status none of the above, we update the `FirstDataApprovalReportRow` `process_status` to `REPORT_PROCESS_STATUS_FAILED` and `process_messsage` to `MESSAGE_UNKNOWN_STATUS` then we skip the process.
     - If the process of the report completed we will change the `FirstDataApprovalReportRow` `process_status` to `REPORT_PROCESS_STATUS_PROCESSED` and `process_messsage` to `MESSAGE_PROCESSED`
     - If any exception throw durring processing the report , we will log `FIRST_DATA_REPORT_EXCEPTION` within the `LogService`

#### On finance approved process description
1. Update `CustomerFinanceAgreement` status to `APPROVED` and `approved_at` to current time
2. Invoke the action `UpdateCustomerOverallStatusAction` to update customer `overall_status`
   -  IF `Customer` has any `CustomerContract`  with `APPROVED` `CustomerFinanceAgreement` the `overall_status` will be set to `TERMINAL_DISPATCHED` (because after approving mids the VT and PBL status will be set to `DISPATCHED`)
   -  IF `Customer` has any `CustomerContract`  with `APPROVED` `CustomerFinanceAgreement` the `overall_status` will be set to `APPLICATION_APPROVED`
   
3. We notify customer and seller that the finance agreement is approved
4. Invoke the function `CompleteCustomerContractAction@handle` which will check if all the contract finance agreement is approved by:
   - Fist if the `CustomerContract` `status` is not `SIGNED` we just return the contract and do nothing
   - Then we check if that contract has any `CustomerFinanceAgreement` that are not yet approved. If yes we just return the contract and do nothing
   - Otherwize we will invoke the `CustomerContractService@onAllFinanceAgreementsApproved` which will update the `CustomerContract` `status` to `CONTRACT_COMPLETED` and record `CONTRACT_COMPLETED` within the `CustomerOperation`
   - then we return fresh intance of the `CustomerContract`
5. Fetching customer products, such as `pax terminal`, `VT`, and `PBL`. If the `pax terminal` exists and either `VR` or `PBL` exist, we will notify the customer to inform them that their account has been activated for Pax + VT/PBL, we will also  invoke `activateCustomerAccountAction@handle` which will notify `Customer` sdi shareholder that the merchant has been approved by **first-data** for payment services.
6. At the end we record `FINANCE_APPROVED` operation within the  `CustomerOperation`
