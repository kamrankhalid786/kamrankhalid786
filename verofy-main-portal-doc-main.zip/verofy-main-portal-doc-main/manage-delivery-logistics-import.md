## Manage The Import of the Delivery Logistics Data with CustomerDeliveryLogisticsCronJob

**Author:** Anouar

### Table of Content
- [Overview](#overview)
- [Code Process](#code-process)
- [Parsing the File: Process Description](#parsing-the-file-process-description)
  - [VerofyPOD Parser](#verofypod-parser)
  - [VerofyDespatches Parser](#verofydespatches-parser)
  - [VerofyAllocations Parser](#verofyallocations-parser)
  - [VerofySwap Parser](#verofyswap-parser)

### Overview

After we have created the order for our terminals with the service logistics [here](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-order-creation.md), we have a scheduled job **`CustomerDeliveryLogisticsCronJob`** that runs every 5 minutes starting from minute `8` within `local` and `production` environments. This job triggers the cron **`CustomerDeliveryLogisticsCron`** that will process the import of the delivery data from **Service Logistic** by invoking the function `CustomerDeliveryLogisticsDataService@incomingFilesProcess`:

### Code Process

1. We fetch all the delivery logistics files from `s3`.
2. For each file, we will trigger two actions:
   - Parsing the file.
   - Archiving the file by pushing it to the archived files list.

### Parsing the File: Process Description

1. First, we use the file name to get the parser type.
2. Depending on the parser type, we will trigger the relevant parsing.

#### VerofyPOD Parser
When the parser is `VerofyDespatches`, we invoke the function `parseFilePOD` which does the following:
1. We convert the CSV file to an array.
2. Fetch `tid` using the tracking number by invoking the function `getTidByTrackingNumber` which will fetch the latest `tid` from `DeliveryServiceLogistics` table.
3. Check the `tid` version. If it starts with `210`, we will skip old version tids.
4. Fetch the status using the message data in the file.

| Condition                                                   | Return Value        |
|-------------------------------------------------------------|---------------------|
| `$message contains 'OUT FOR DELIVERY'`                      | `self::IN_TRANSIT`  |
| `$message contains 'UNABLE TO DELIVER CALLING CARD LEFT'`   | `self::FAIL_CARD`   |
| `$message contains 'UNABLE TO DELIVER'`                     | `self::FAIL`        |
| `$message contains 'REDELIVERY REQUEST'`                    | `self::RE_ARRANGE`  |
| `$message contains 'DELIVERED'`                             | `self::DELIVERED`   |

5. For each row, we build an array of data using the following fields:
    - `created_date`: `Carbon::now()`
    - `mid`: `$row[0]`
    - `tid`: `$tid`
    - `carrier_reference`: `$row[1]`
    - `state`: `$status`
    - `message`: `$row[2]`
    - `file`: `$file`
    - `updated_date_from_pod_file`: `Carbon::createFromFormat('d/m/Y H:i:s', $row[3])`
6. Fetch the `CustomerProduct` using the `tid`.
7. Fetch the `CustomerDeliveryPackage` from the fetched `CustomerProduct`.
8. We create a new `DeliveryServiceLogistics` using the data we have prepared.
9. If the status from the file is `DELIVERED`, we will trigger the following:
   - We invoke the function `CustomerProductsService@onTerminalDelivered` which will do the following:
     - Update `CustomerProduct` `delivered_at` to the delivery time from the file data.
     - Update the `CustomerDeliveryPackage` `status` to `STATUS_DELIVERED` and set the `delivered_at` to the delivery date.
     - Invoke the `UpdateCustomerOverallStatusAction` action; at this point, the `Customer` `overall_status` will be updated to `TERMINAL_DELIVERED`.
     - Notify `Customer` and `Seller` that the terminal is delivered.
     - Record a log for `CUSTOMER_PRODUCT_DELIVERED` with a new `CustomerOperationLog`.

10. If the status from the file is `FAIL` or `FAIL_CARD`, we will trigger the following:
    - We invoke the function `CustomerProductsService@onTerminalNonDelivered` which will do the following:
      - Notify the customer that the terminal is not delivered.
      - Record a log for `CUSTOMER_PRODUCT_NON_DELIVERED` with a new `CustomerOperationLog`.

11. If the status from the file is `IN_TRANSIT`, we will trigger the following:
    - We invoke the function `CustomerProductsService@onTerminalInTransit` which will do the following:
      - Notify the customer that the terminal is in transit.
      - Update the `CustomerDeliveryPackage` `status` to `STATUS_IN_TRANSIT`.
      - Record a log for `CUSTOMER_PRODUCT_IN_TRANSIT` with a new `CustomerOperationLog`.

#### VerofyDespatches Parser
When the parser is `VerofyDespatches`, we invoke the function `parseFileDespatches` which does the following:
1. We convert the CSV file to an array.
2. For each row, we build an array of data using the following fields:
    - `created_date`: `Carbon::now()`
    - `mid`: `$row[0]`
    - `tid`: `$row[1]`
    - `serial_number`: `$row[2]`
    - `carrier_reference`: `$row[3]`
    - `state`: `self::IN_TRANSIT`
    - `file`: `$file`
3. Fetch the `CustomerProduct` using the `tid`.
4. We create a new `DeliveryServiceLogistics` using the data we have prepared.
5. Invoke the function `CustomerProductsService@onTerminalDispatched` which will do the following:
    - Update `CustomerProduct` `status` to `DISPATCHED` and `serial_number` to the value we have within the data received in the file.
    - Invoke the `UpdateCustomerOverallStatusAction` action; at this point, the `Customer` `overall_status` will be updated to `TERMINAL_DISPATCHED`.
    - Notify `Customer` and `Seller` that the terminal is dispatched.
    - Update the `CustomerDeliveryPackage` `status` to `STATUS_READY_FOR_COLLECTION` and set the `tracking_number` from the data we have received in the file.
    - Record a log for `CUSTOMER_PRODUCT_DISPATCHED` with a new `CustomerOperationLog`.

#### VerofyAllocations Parser
When the parser is `VerofyAllocations`, we invoke the function `parseFileAllocations` which does the following:
1. We convert the CSV file to an array.
2. For each row, we build an array of data using the following fields:
    - `created_date`: `Carbon::now()`
    - `mid`: `$row[0]`
    - `tid`: `$row[1]`
    - `serial_number`: `$row[2]`
    - `state`: `self::PACKED_FOR_SHIPMENT`
    - `file`: `$file`
3. We create a new `DeliveryServiceLogistics` using the data we have prepared.
4. Invoke the function `CustomerProductsService@onTerminalPackedForShipment` which will do the following:
    - Update the `CustomerDeliveryPackage` `status` to `STATUS_PACKED_FOR_SHIPMENT`.
5. If something goes wrong, we record the error under the `errors` list, then increment the `errors` counter.

#### VerofySwap Parser
When the parser is `VerofySwap`, we invoke the function `parseFileSwap` which does the following:
1. We convert the CSV file to an array.
2. Check the `tid` version. If it starts with `210`, we will skip old version tids.
3. For each row, we build an array of data using the following fields:
    - `created_date`: `Carbon::now()`
    - `mid`: `$row[0]`
    - `tid`: `$row[1]`
    - `serial_number`: `$row[2]`
    - `state`: `self::SWAP . ' - new SN: ' . $row[3]`
    - `file`: `$file`
4. We create a new `DeliveryServiceLogistics` using the data we have prepared.
5. Invoke the function `CustomerProductsService@onTerminalSwapOut` which will do the following:
    - Logic is not implemented in the given function.
6. If something goes wrong, we record the error under the `errors` list, then increment the `errors` counter.
