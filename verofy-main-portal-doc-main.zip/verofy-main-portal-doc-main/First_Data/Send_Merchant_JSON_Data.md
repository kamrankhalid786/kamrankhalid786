# Send Merchant JSON Data [![Version](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

## Table of Contents

- [sendMerchantData Method](#sendmerchantdata-method)
- [Return Value](#return-value)
- [$dataOutlet Array](#dataoutlet-array)
- [$data Array](#data-array)
- [sendToFirstData Method](First_Data_Api.md)

## sendMerchantData Method

The `sendMerchantData` method is a part of the `CustomerFinanceService` class. It is responsible for sending merchant data to a finance company.

## Arguments

This method accepts an instance of `CustomerFinanceAgreement` as an argument. This object represents the finance agreement that needs to be sent.

## Process

1. The method retrieves the customer associated with the finance agreement.
2. It checks if the business establishment month and year are present for the customer. If either of these is missing, it throws an exception.
3. It retrieves the business and legal addresses of the customer, the full name of the primary contact, the business type, and the business start date.
4. It generates a unique ID and retrieves the merchant ID from the customer's ID.
5. It finds the first MID (Merchant Identification Number) for the contract.
6. It retrieves the MCC (Merchant Category Code) and SIC (Standard Industrial Classification) code. If the SIC code is not available, it defaults to '0000'.
7. It formats the primary contact phone number to the national format.
8. It retrieves the customer's bank account and all the customer's locations that have products.
9. It loops through these outlets and checks if they have any products associated with the customer contract. If they do, it prepares an array of data for the outlet.
10. It prepares the principal info by looping through the shareholders of the customer and preparing their details.
11. It prepares the data to be sent to the finance company. This data includes application info such as the unique ID, merchant ID, business address, contact name, SIC code, bank number, account number, business type, business start date, and principal info. It also includes outlet info if available.
12. It sends this data to the finance company using the `sendToFirstData` method of the `firstDataApiService` and returns the unique ID.

## Return Value

The method returns the unique ID if the sending of the merchant data was successful, and throws an exception otherwise.

## $dataOutlet Array

| Key      | Description |
| ----------- | ----------- |
| Ext_Merchant_ID | The external merchant ID. |
| Chain_Chn | Chain channel. |
| DBA_Name | The trading name of the customer. |
| Legal_Name | The legal name of the customer. |
| Buss_Address1 | The house name/number of the business address. |
| Buss_Address2 | The street name of the business address. |
| Buss_Address3 | The address line 1 of the business address. |
| Buss_City | The city of the business address. |
| Buss_State | The state of the business address. |
| Buss_Zip | The postcode of the business address. |
| Buss_Country | The country code of the business address. |
| Buss_Phone | The phone number of the business. |
| Buss_Emailaddress | The email address of the business. |
| Contact_Name | The contact name. |
| Contact_Phone | The contact phone number. |
| Contact_Fax | The contact fax number. |
| AR_Name | The AR name. |
| AR_Address1 | The house name/number of the AR address. |
| AR_Address2 | The street name of the AR address. |
| AR_Address3 | The address line 1 of the AR address. |
| AR_City | The city of the AR address. |
| AR_State | The state of the AR address. |
| AR_Zip | The postcode of the AR address. |
| Bank_Nbr | The bank number. |
| Account_Nbr | The account number. |
| BIC | The BIC number. |
| IBAN | The IBAN number. |
| SIC_Code | The SIC code. |
| Prior_Lease_Nbr | The prior lease number. |
| Prior_Lease_Ind | The prior lease indicator. |
| Request_Nbr | The request number. |
| Billing_Type_Info | The billing type information. |

## $data Array

| Key      | Description |
| ----------- | ----------- |
| ApplicationInfo | The application information. |

### ApplicationInfo Array

| Key      | Description |
| ----------- | ----------- |
| XMLSeqid | The XML sequence ID. |
| Ext_Merchant_ID | The external merchant ID. |
| Operating_Type | The operating type (NEW or UPGRADE). |
| Source_System | The source system (External). |
| Platform | The platform (UK). |
| UID | The user ID (External). |
| Bank_Code | The bank code. |
| DBA_Name | The trading name of the customer. |
| Legal_Name | The legal name of the customer. |
| Credit_Score | The credit score. |
| Number_Of_Outlets | The number of outlets. |
| Buss_Address1 | The house name/number of the business address. |
| Buss_Address2 | The street name of the business address. |
| Buss_Address3 | The address line 1 of the business address. |
| Buss_City | The city of the business address. |
| Buss_State | The state of the business address. |
| Buss_Zip | The postcode of the business address. |
| Buss_Country | The country code of the business address. |
| Buss_Phone | The phone number of the business. |
| Contact_Name | The contact name. |
| Contact_Phone | The contact phone number. |
| Contact_Fax | The contact fax number. |
| SIC_Code | The SIC code. |
| FED_TAX_ID | The federal tax ID (Company Registration Number). |
| VAT_Reg_No | The VAT registration number. |
| Bank_Nbr | The bank number. |
| Account_Nbr | The account number. |
| BIC | The BIC number. |
| IBAN | The IBAN number. |
| Buss_Type | The business type (CORPORATION, PARTNERSHIP, PROPRIETORSHIP, NON_PROFIT). |
| Buss_Start_Date | The business start date (MM/YYYY). |
| AR_Name | The AR name. |
| AR_Address1 | The house name/number of the AR address. |
| AR_Address2 | The street name of the AR address. |
| AR_Address3 | The address line 1 of the AR address. |
| AR_City | The city of the AR address. |
| AR_State | The state of the AR address. |
| AR_Zip | The postcode of the AR address. |
| AR_Attention | The AR attention. |
| Rep_ID | The representative ID. |
| Signer_Name | The signer name. |
| Signer_Phone | The signer phone. |
| Buss_Emailaddress | The business email address. |
| Sysprin | The Sysprin. |
| Multi_App | The multi application indicator (N). |
| Principal_Info | The principal information. |
| Outlet_Info | The outlet information. |

### Principal_Info Array

| Key      | Description |
| ----------- | ----------- |
| Principal | The principal information. |

### Outlet_Info Array

| Key      | Description |
| ----------- | ----------- |
| Outlet | The outlet information. |

## [sendToFirstData Method](First_Data_Api.md)
