
# First Data Email Service [![Version](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

## Table of Contents

- [sendEmailToFirstData Method](#sendemailtofirstdata-method)
- [Process](#process)
  - [Customer Details Retrieval](#customer-details-retrieval)
  - [Applicant Documents Retrieval](#applicant-documents-retrieval)
  - [Attachment Assembly](#attachment-assembly)
  - [Email Sending](#email-sending)
- [Detailed Explanation](#detailed-explanation)
- [Code Explanation](#code-explanation)
  - [Fetching Customer and Site Visit Requirement](#fetching-customer-and-site-visit-requirement)
  - [Handling Customer Applicants](#handling-customer-applicants)
  - [Fetching ID Documents](#fetching-id-documents)
  - [Fetching Essential Documents](#fetching-essential-documents)
  - [Including Proof of Address](#including-proof-of-address)
  - [Fetching Google Address Validation Results](#fetching-google-address-validation-results)
  - [Sending Email with Attachments](#sending-email-with-attachments)

## sendEmailToFirstData Method

The `sendEmailToFirstData` function manages the process of sending an email to First Data containing various documents related to a customer's finance agreement. The function ensures that all necessary documents are included and handles exceptions if any required document is missing or if the email fails to send.

## Process

### Customer Details Retrieval

The function begins by retrieving the customer associated with the finance agreement. It also determines whether a site visit is required for the customer.

### Applicant Documents Retrieval

It retrieves ID documents for the main applicant and, if applicable (in the case of a partnership), for all partners.

### Attachment Assembly

- The function gathers and assembles attachments including:
  - ID documents (front and back) for the applicant(s).
  - Envelope document.
  - Finance agreement document.
  - Additional information document required by First Data.
- Depending on certain conditions, additional documents are included:
  - Proof of address documents if the customer has proof of trading address.
  - Site visit confirmation and related photos if a site visit is required.
  - Google address validation result.
  - Google screenshot of proof of address.

### Email Sending

Once all necessary attachments are assembled, the function sends an email to First Data using the `mailingService`. The email contains all the gathered attachments. If the email fails to send, an exception is thrown and logged.

## Detailed Explanation

- The function systematically retrieves various documents required for the finance agreement process.
- It dynamically determines the type of documents to include based on customer characteristics and requirements.
- Documents are fetched using the `customerDocumentsService` and appended to the `$attachments` array.
- Additional documents, such as proof of address and site visit confirmation, are included based on specific conditions.
- After assembling all attachments, the function sends an email to First Data containing the documents using the `mailingService`.
- If the email fails to send, the function logs the failure and throws an exception to alert the system of the issue.

## Code Explanation

The `sendEmailToFirstData` function is responsible for sending an email to First Data containing various documents related to a customer's finance agreement. Here's a breakdown of its logic:

### Fetching Customer and Site Visit Requirement

The function starts by retrieving the customer associated with the finance agreement and determining whether a site visit is required for the customer.

### Handling Customer Applicants

If the customer is part of a partnership, documents for all partners are fetched; otherwise, only documents for the main applicant are retrieved.

### Fetching ID Documents

For each customer applicant, the function fetches their ID documents (front and back). If any document is missing, an exception is thrown.

### Fetching Essential Documents

It retrieves other essential documents such as the envelope, finance agreement, and additional information related to the finance agreement. If any document is missing, it throws an exception.

### Including Proof of Address

Depending on whether the customer has proof of trading address or if a site visit is required, additional documents such as proof of address or site visit confirmation are retrieved.

### Fetching Google Address Validation Results

If the customer has a valid Google address, the function retrieves Google address validation results.

### Sending Email with Attachments

Finally, the function sends an email containing all the assembled attachments to First Data. If the email fails to send, it logs the failure and throws an exception.

This function ensures that all required documents are included in the email sent to First Data, providing a comprehensive overview of the customer's finance agreement.
