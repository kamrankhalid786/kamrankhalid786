# Approval Finance Reports [![Version 1.0](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Approved.txt)

## Table of Contents

- [Introduction](#introduction)
- [Business Logic](#business-logic)
- [Code Flow Diagram](#code-flow-diagram)
- [System Components](#system-components)
  - [1. Scheduler](#1-scheduler)
  - [2. Job: CheckFirstDataApprovalReportsCronJob](#2-job-checkfirstdataapprovalreportscronjob)
  - [3. Command: CheckFirstDataApprovalReportsCron](#3-command-checkfirstdataapprovalreportscron)
  - [4. Services](#4-services)
    - [FirstDataReportService](#firstdatareportservice)
    - [FirstDataImapService](#firstdataimapservice)
    - [FirstDataStorageService](#firstdatastorageservice)
- [Detailed Method Descriptions](#detailed-method-descriptions)
  - [saveReportsFromEmailsToS3](#savereportsfromemailstos3-method)
  - [storeAllReportsFromS3ToDB](#storeallreportsfroms3todb-method)
  - [processReports](#processreports-method)
    - [Status Grid](#update-finance-agreement-status)
  - [onFinanceApproved](#onfinanceapproved-method)
- [Code Execution Flow](#code-execution-flow)
- [First data approval reports: Detailed Code Execution Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-first-data-approval-report.md)

## Introduction

This document outlines the implementation of an automated system designed to process approval reports received via email. The system includes a scheduler, job, command, and services that work together to retrieve email attachments, store them in AWS S3, and then process these reports by storing them in a database and handling their approval statuses.

## Business Logic

The system automates the extraction and processing of approval reports from emails, stores these reports in S3, transfers them into a database, and processes them based on specific business rules. This automation ensures data consistency, minimizes manual effort, and enhances efficiency.

## Code Flow Diagram

```mermaid
graph TD;
    Scheduler[Scheduler] -->|Triggers| Job[CheckFirstDataApprovalReportsCronJob]
    Job -->|Executes| Command[CheckFirstDataApprovalReportsCron]
    Command -->|Calls| FirstDataReportService[FirstDataReportService]
    FirstDataReportService -->|Saves Emails to S3| SaveReports[saveReportsFromEmailsToS3]
    FirstDataReportService -->|Stores Reports in DB| StoreReports[storeAllReportsFromS3ToDB]
    FirstDataReportService -->|Processes Reports| ProcessReports[processReports]

    SaveReports -->|Uses| FirstDataImapService[FirstDataImapService]
    FirstDataImapService -->|Saves Attachments to S3| FirstDataStorageService[FirstDataStorageService]

    StoreReports -->|Gets Reports from S3| GetReports[getReportsToProcess]
    GetReports --> FirstDataStorageService
    StoreReports -->|Stores Reports Data| StoreDataInDB[storeReportToDb]
    StoreDataInDB -->|Commits Transaction| DBCommit[DB Transaction Commit]
    StoreDataInDB -->|Rollback Transaction on Error| DBRollback[DB Transaction Rollback]

    ProcessReports -->|Finds New Report Rows| FindReports[findNewReportRows]
    ProcessReports -->|Updates Report Status| UpdateStatus[update report status based on business logic]
    ProcessReports -->|Logs Exceptions| LogExceptions[Log Exceptions]

    style Scheduler fill:#811781,stroke:#333,stroke-width:2px
    style FirstDataReportService fill:##1d1d6d,stroke:#333,stroke-width:2px
    style FirstDataImapService fill:#206320,stroke:#333,stroke-width:2px
    style FirstDataStorageService fill:#134d4d,stroke:#333,stroke-width:2px
    style DBCommit fill:#390e39,stroke:#333,stroke-width:2px
    style DBRollback fill:#371010,stroke:#333,stroke-width:2px
```

## System Components

### 1. Scheduler

- **Purpose**: Triggers the job at specific intervals.
- **Configuration**: Executes every 5 minutes from the 12th to the 59th minute of each hour, without overlapping, ensuring execution only on one server.

### 2. Job: CheckFirstDataApprovalReportsCronJob

- **Function**: Executes the Laravel command `first-data:check-approval-reports`.

### 3. Command: CheckFirstDataApprovalReportsCron

- **Responsibility**: Calls the `FirstDataReportService` to process the reports.
- **End result**: Outputs a completion message once the script finishes.

### 4. Services

#### FirstDataReportService

- **Processes**:
  - Retrieves email attachments and saves them to S3 (`saveReportsFromEmailsToS3`).
  - Stores all reports from S3 into the database (`storeAllReportsFromS3ToDB`).
  - Processes the reports based on specific criteria (`processReports`).

#### FirstDataImapService

- **Functionality**: Connects to the IMAP server to fetch emails and saves attachments directly to S3.

#### FirstDataStorageService

- **Tasks**:
  - Uploads email attachments to S3.
  - Retrieves reports for processing.
  - Moves processed files to a designated folder in S3 after processing.

## Detailed Method Descriptions

### `saveReportsFromEmailsToS3` Method

- **Description**: Fetches emails using IMAP, extracts attachments, and uploads them to an S3 bucket.
- **Error Handling**: Logs exceptions if the process fails.

### `saveReportsToS3` Method

The `saveReportsToS3` method is part of the `FirstDataImapService` class. This method is responsible for fetching emails from an IMAP server, extracting attachments from these emails, and uploading them to an S3 bucket.

#### Process Flow `saveReportsToS3()`

1. **Refresh Access Token**: The method starts by refreshing the access token using the `refreshToken` method of the `imapOauthService`.

2. **Override Password Configuration**: It then overrides the password configuration with the fresh access token.

3. **Connect to the IMAP Server**: It creates a new IMAP client for a specific account and connects to the IMAP server.

4. **Get INBOX Folder**: It retrieves the INBOX folder from the IMAP server.

5. **Fetch Messages**: It fetches all the messages from the INBOX folder that are from a specific sender and have a specific subject.

    ````php
    $messages = $this->imapClient->getMessages($this->imapConfig['inbox_folder'], $this->imapConfig['search_criteria']);
    ````

6. **Process Each Message**: For each message, it does the following:
   - **Get Attachments**: It retrieves all the attachments of the message.
   - **Upload Attachments to S3**: For each attachment, it uploads the attachment to an S3 bucket using the `uploadAttachmentIntoS3` method of the `firstDataStorageService`.

      ```php
      $this->firstDataStorageService->uploadAttachmentIntoS3($attachment);
      ```

      ```php
      $name = $attachment->getMessage()->uid . '-' . $attachment->getName();
          Storage::disk(self::S3_STORAGE_DISK)->put(self::REPORTS_UPLOAD_DIR . '/' . $name, $attachment->getContent());
      ```

   - **Move Message to Processed Folder**: It then tries to move the message to a processed folder. If it fails to move the message, it logs an exception using the `log` method of the `LogService`.

### `storeAllReportsFromS3ToDB` Method

The `storeAllReportsFromS3ToDB` method is part of the `FirstDataReportService` class. This method is responsible for processing reports stored in an S3 bucket and storing the report data into a database.

#### Process Flow `storeAllReportsFromS3ToDB()`

1. **Get Reports to Process**: The method starts by retrieving all the reports to process from the S3 bucket using the `getReportsToProcess` method of the `firstDataStorageService`.

    ```php
    return Storage::disk(self::S3_STORAGE_DISK)->files(self::REPORTS_UPLOAD_DIR);
    ```

2. **Process Each Report**: For each report, it does the following:
   - **Check File Extension**: It checks if the file extension of the report is in the list of processable file extensions. If not, it skips the report.
   - **Copy Report to Local Storage**: It copies the report from the S3 bucket to local storage.
   - **Store Report Data to Database**: It then stores the report data into the database using the `storeReportToDb` method. This method reads the report file, which is a tab-delimited CSV file, and for each row in the file, it creates a new `FirstDataApprovalReportRow` record in the database with the report data.

      | Field              | Value                                                                 |
      |--------------------|-----------------------------------------------------------------------|
      | process_status     | `FirstDataApprovalReportRow::REPORT_PROCESS_STATUS_NEW`               |
      | from_file          | `$fileName` (The name of the file from which the data was extracted)  |
      | vendor             | `$data[$reportMap['vendor']]` (The vendor ID)                         |
      | vendor_name        | `$data[$reportMap['vendor_name']]` (The name of the vendor)           |
      | contract           | `$data[$reportMap['contract']]` (The contract ID)                     |
      | status             | `$data[$reportMap['status']]` (The status of the contract)            |
      | payment_type       | `$data[$reportMap['payment_type']]` (The type of payment)             |
      | payment_type_desc  | `$data[$reportMap['payment_type_desc']]` (The description of the payment type) |
      | amount             | `$data[$reportMap['amount']]` (The amount of the payment)             |
      | customer_id        | `$data[$reportMap['customer_id']]` (The ID of the customer)           |
      | data               | `$data` (The entire row of data from the report)                      |
      | api_invoice_no     | `$data[$reportMap['api_invoice_no']]` (The API invoice number)        |

   - **Delete Local Copy of Report**: It deletes the local copy of the report.
   - **Move Report to Processed Folder**: It moves the report to a processed folder in the S3 bucket using the `moveFileToProcessedFolder` method of the `firstDataStorageService`.

      ```php
      $fileName = File::name($filePath) . '.' . File::extension($filePath);
            Storage::disk(self::S3_STORAGE_DISK)->move($filePath, self::REPORTS_ARCHIVE_DIR . '/' . $fileName);
      ```

3. **Handle Exceptions**: If an exception occurs during the process, it logs the exception using the `log` method of the `LogService`.

    ```php
    LogService::log(
        LogCode::FIRST_DATA_REPORT_EXCEPTION,
        ['process_message' => $e->getMessage()],
        'Store All Reports From S3 To DB exception.'
    );
    ```

### `processReports` Method

The `processReports` method is part of the `FirstDataReportService` class. This method is responsible for processing new report rows and updating the status of customer finance agreements based on the report data.

#### Process Flow `processReports()`

1. **Find New Report Rows**: The method starts by retrieving all new report rows using the `findNewReportRows` method of the `FirstDataApprovalReportRow` model.

2. **Process Each Report Row**: For each report row, it does the following:
   - **Find Customer**: It attempts to find a customer associated with the report row based on the `customer_id` field in the report row. If no customer is found, it updates the report row status to `REPORT_PROCESS_STATUS_FAILED` and continues to the next report row.

        ```php
        $customer = Customer::whereHas('mids', function ($query) use ($row) {
            $query->whereHas('bamboraSubmerchants', function($query) use ($row) {
                $query->where('pf_account_id', $row->customer_id);
            });
        })->first();
        ```

   - **Find Finance Agreement**: It attempts to find a finance agreement associated with the found customer. If no finance agreement is found, it updates the report row status to `REPORT_PROCESS_STATUS_FAILED` and continues to the next report row.
   - **Update Finance Agreement Status**: Depending on the `status` field in the report row, it updates the status of the finance agreement using the [onFinanceApproved](#onfinanceapproved-method) or `onFinanceDeclined` method of the `customerFinanceService`. It also increments the count of approved or unapproved agreements.

      | Status Code | Description | Action Taken |
      |-------------|-------------|--------------|
      | `S` `A` | Approved    | The [onFinanceApproved](#onfinanceapproved-method) method of the `customerFinanceService` is called, and the count of approved agreements is incremented. |
      | `U`         | Unapproved  | The `onFinanceDeclined` method of the `customerFinanceService` is called, and the count of unapproved agreements is incremented. |
      | Other       | Unknown     | The report row status is updated to `REPORT_PROCESS_STATUS_FAILED` and the process message is set to `MESSAGE_UNKNOWN_STATUS`. The processing of the current report row is then skipped. |

   - **Update Report Row Status**: It updates the report row status to `REPORT_PROCESS_STATUS_PROCESSED`.

3. **Handle Exceptions**: If an exception occurs during the process, it logs the exception using the `log` method of the `LogService`.

- **Outcome**:
  - Modifies report status in the database.
  - Logs and handles exceptions effectively.

### `onFinanceApproved` Method

The `onFinanceApproved` method is part of the `CustomerFinanceService` class. This method is responsible for handling the approval of a customer's finance agreement.

#### Process Flow `onFinanceApproved()`

1. **Update Agreement Status**: The method starts by setting the `approved_at` field of the finance agreement to the current date and time, and the `status` field to `APPROVED`. It then saves the changes to the database.

2. **Update Customer Overall Status**: It updates the overall status of the customer associated with the finance agreement using the `handle` method of the `updateCustomerOverallStatusAction`.

3. **Load Customer Contract**: It loads the customer contract associated with the finance agreement if it hasn't been loaded already.

4. **Process Messaging Events**: It processes messaging events related to the approval of the finance agreement using the `processCustomerFinanceApproved` and `processSellerCustomerFinanceApproved` methods of the `messagingEventsService`.

5. **Complete Customer Contract**: It attempts to mark the customer contract as completed using the `handle` method of the `completeCustomerContractAction`.

6. **Decide Product Combination and Activate Customer Account**: If the customer has a PAX terminal and either a virtual terminal or a pay by link product, it processes a customer account activation messaging event and activates the customer account using the `handle` method of the `ActivateCustomerAccountAction`.

7. **Log Customer Operation**: It logs the approval of the finance agreement as a customer operation using the `logOperation` method of the `customerOperationLogService`.

## Code Execution Flow

1. **Scheduler initiates the job** based on the specified cron schedule.
2. **Job executes the command**, which in turn calls the `FirstDataReportService`.
3. **FirstDataReportService** sequentially executes its three main functions:
   - **saveReportsFromEmailsToS3**
   - **storeAllReportsFromS3ToDB**
   - **processReports**
4. Each function handles its part of the workflow, ensuring the reports are fetched, stored, and processed correctly.
5. **Logging** is integral at each step for error handling and audit trails.
