# First Data API [![Version](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

## Table of Contents

- [sendToFirstData Method](#sendtofirstdata-method)
- [Arguments](#arguments)
- [Process](#process)
- [Return Value](#return-value)

## sendToFirstData Method

The `sendToFirstData` method is a part of the `CustomerFinanceService` class. This method is responsible for sending JSON data to the First Data API and handling the response.

## Arguments

This method accepts a single argument:

- `$jsonData`: This is the data that will be sent to the First Data API. It should be in JSON format.

## Process

1. The method sets the `$uri` variable to `$this->apiUrl`, which is the URL of the API endpoint.
2. It makes a POST request to the API using the `post` method of the `$this->restClient` object. The request includes default options (`$this->defaultOptions`) and the JSON data.
3. The response from the API is stored in the `$response` variable.
4. The method gets the calling method for logging purposes using the `debug_backtrace` function.
5. It logs the response using the `logGuzzleHttpResponse` method of the `LogService` class.
6. The method decodes the JSON response from the API and extracts the message from the response.
7. It checks the status code of the response. If it's not '200', it throws a `FirstDataException` with a message indicating an invalid response from the API.
8. The method also checks the reason phrase of the response. If it's not 'OK', it throws a `FirstDataException` with a message indicating an invalid response from the API.
9. It gets the status from the response data. If the status is not 'ACCEPTED', it throws a `FirstDataException` (this line is currently commented out).
10. The method gets the 'fdRefId' from the response data and checks if it exists. If it doesn't, it throws a `FirstDataException` (this line is also currently commented out). If the 'fdRefId' exists, the function returns it.

## Return Value

The method returns the 'fdRefId' from the response data if it exists. If the 'fdRefId' does not exist, it throws a `FirstDataException`.
