# Declined Finance Reports [![Version 1.0](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Decline.txt)

## Table of Contents

- [Table of Contents](#table-of-contents)
- [Introduction](#introduction)
- [Business Logic](#business-logic)
- [Code Flow Diagram](#code-flow-diagram)
- [Code Structure](#code-structure)
- [Methods](#methods)
  - [processDeclinedMessages()](#processdeclinedmessages)
  - [verofyToVtigerService::createFirstDataDeclinedCase()](#verofytovtigerservicecreatefirstdatadeclinedcase)
- [First Data Declined Reports: Detailed Code Execution Description](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-first-data-declined-report.md)

## Introduction

The provided code is a part of a larger system that processes declined reports found in a specific email account. It uses a scheduled job to periodically check for new emails, processes them, and stores the relevant information in a database. It also creates a case in a Vtiger for each processed email.

## Business Logic

The business logic of the code revolves around processing declined reports from an email account. Each email is parsed, and the relevant information is stored in a database. Additionally, a case is created in a Vtiger for each email, allowing for further action to be taken based on the information in the email.

## Code Flow Diagram

``` plaintext
+--------------------+     +-------------------+     +-----------------------+
| Cron Job Triggered | --> | Artisan Command   | --> | FirstDataReportService|
| (Kernel)           |     | Executed          |     | processDeclineReports |
+--------------------+     +-------------------+     +-----------------------+
                                                            |
      ------------------------------------------------------
     |
     v
+----------------------+     +--------------------+     +-------------------+
| FirstDataImapService | --> | Parse and Store    | --> | Create Case in    |
| Connects to IMAP     |     | Reports in DB      |     | Vtiger            |
+----------------------+     +--------------------+     +-------------------+
                                                           |
                                                           |
                                                           v
+-------------------+     +-----------------------+     +-------------------+
| Move Email to     | <-- | verofyToVtigerService | <-- | Case Created      |
| Processed Folder  |     | Adds Comment to Case  |     | in Vtiger         |
+-------------------+     +-----------------------+     +-------------------+
```

## Code Structure

The code is structured into several classes, each with a specific responsibility:

- `CheckFirstDataDeclinedReportsCronJob`: This is the scheduled job that triggers the process.
- `CheckFirstDataDeclinedReportsCron`: This is the artisan command that is called by the cron job.
- `FirstDataReportService`: This service class contains the `processDeclineReports` method that starts the email processing.
- `FirstDataImapService`: This service class contains the `processDeclinedMessages` method that connects to the email account and processes each message.
- `verofyToVtigerService`: This service class contains the `createFirstDataDeclinedCase` method that creates a case in the Vtiger.

## Methods

- `CheckFirstDataDeclinedReportsCronJob::handle()`: This method triggers the artisan command `first-data:check-declined-reports`.
- `CheckFirstDataDeclinedReportsCron::handle()`: This method calls the `processDeclineReports` method of the `FirstDataReportService`.
- `FirstDataReportService::processDeclineReports()`: This method calls the `processDeclinedMessages` method of the `FirstDataImapService`.
- `FirstDataImapService::processDeclinedMessages()`: This method connects to the email account, retrieves all messages, processes each message, stores the relevant information in the database, and creates a case in the VTiger.

### `processDeclinedMessages()`

1. **Refresh access token**: The function first refreshes the access token for the IMAP server using the `refreshToken` method of the `ImapOauthService` class.

2. **Override password configuration**: It then overrides the password configuration with the fresh access token.

3. **Connect to the IMAP Server**: It creates a client for the IMAP server and connects to it.

4. **Get INBOX folder**: It retrieves the INBOX folder from the IMAP server.

5. **Get all Messages**: It retrieves all messages from the INBOX folder.

6. **Process each message**: For each message, it does the following:
   - **Parse from attribute**: It parses the 'from' attribute of the message to get the email and name of the sender.
   - **Store report into the DB**: It creates a new `FirstDataDeclineReport` record in the database with the status set to 'new', and the 'from' email, subject, text body, and HTML body of the message.

        | Column          | Value                 |
        |-----------------|-----------------------|
        | status          | PROCESS_STATUS_NEW    |
        | mail_from       | $fromMail             |
        | mail_subject    | $message->getSubject()|
        | mail_text_body  | $message->getTextBody()|
        | mail_html_body  | $message->getHTMLBody()|

   - **Create a case**: It creates a case in the Vtiger using the [`createFirstDataDeclinedCase`](verofyToVtigerService::createFirstDataDeclinedCase()) method of the `verofyToVtigerService` class. If the case creation fails, it skips the rest of the loop and processes the next message.

   - **Move the message**: It moves the message to the 'processed' folder. If the move operation fails, it logs an error message.

### `verofyToVtigerService::createFirstDataDeclinedCase()`

This method creates a case in the Vtiger.

| Column               | Value                                         |
|----------------------|-----------------------------------------------|
| assigned_user_id     | VtigerApiService::USER_ID_SUPPORT_TEAM        |
| ticketpriorities     | $ticketPriority                               |
| ticketstatus         | VtigerApiService::TICKET_STATUS_AWAITING_ASSIGNMENT |
| ticketcategories     | VtigerApiService::TICKET_CATEGORY_BIG_PROBLEM |
| ticket_title         | $title                                        |
| cf_1789              | VtigerApiService::TICKET_TYPE_FIRST_DATA      |
| description          | $title                                        |
| contact_id           | $contactVtigerId                              |
