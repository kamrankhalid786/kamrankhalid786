# Bambora Service [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Flow Diagram](Bambora/Bambora_Code_Flow_Diagram.md)

## Table of Contents

- [Introduction](#introduction)
- [Business Logic](#business-logic)
- [Flow](#flow)
- [Code Structure](#code-structure)
- [Method: generateEnrollmentXml()](#method-generateenrollmentxml)
- [Method: processEnrollmentResults()](#method-processenrollmentresults)
- [Method: processResultXML()](#method-processresultxml)
- [Code Flow](#code-flow)
- [Bambora Submerchants enrollements detailed process description](manage-bambora-merchants-enrollments.md)
- [MOM Action Answers](#mom-action-answers)

![Bambora Diagram](CR-onboarding-final-stage/Bambora_Flow.png)

## Introduction

The service schedules a job in Laravel using the task scheduling feature. Here's a breakdown of what each line does:

| Property | Value |
| --- | --- |
| Scheduler Job Name | `BamboraEnrollmentsCronJob` |
| Environments | `local` `production` |
| Frequency | Every two minutes |
| Overlapping | Prevented, with a 10-minute threshold |
| Server Execution | Runs on only one server |

## Business Logic

The business logic here revolves around managing enrollments with Bambora, a payment processing service. The `BamboraSubmerchantService` likely interacts with the Bambora API or handles operations related to Bambora. The `generateEnrollmentXml()` method generates an XML file representing enrollments to be processed by Bambora. The `processEnrollmentResults()` method handles the results returned by Bambora after the enrollments have been processed.

## Flow

The process flow is outlined as follows:

1. **Dispatch BamboraEnrollmentsCronJob**: This job is dispatched, scheduled using Laravel's task scheduling.
2. **Run `bamboraEnrollments` Artisan Command**: The job triggers the execution of the `bamboraEnrollments` Artisan command.
3. **Call `handle()` Method of `BamboraEnrollmentsCron`**: The `handle()` method of the `BamboraEnrollmentsCron` class is invoked to start the process.
4. **Invoke `generateEnrollmentXml()` and `processEnrollmentResults()` on `BamboraSubmerchantService`**: Within the `handle()` method, these methods are called on the `BamboraSubmerchantService` instance to perform the actual business logic.

## Code Structure

The code structure follows Laravel's conventions for jobs and commands:

- **BamboraEnrollmentsCronJob Class**: This job class is dispatched to run the `bamboraEnrollments` command.
- **BamboraEnrollmentsCron Class**: Defines the `bamboraEnrollments` command and contains the `handle()` method to execute the business logic.
- **BamboraSubmerchantService**: This service class encapsulates the actual business logic for interacting with Bambora.

<table>
<tr>
<td>

### Generate Enrollment Xml

```mermaid
graph TD;
    A[Dispatch Bambora > EnrollmentsCron > Job] --> B[Run `bamboraEnrollments` Artisan Command]
    B --> C[Call `handle` method of `BamboraEnrollments Cron`]
    C --> D[Call `generateEnrollmentXml` method and `processEnrollmentResults` method on `BamboraSubmerchantService`]
    D --> E[Fetch submerchants ready for enrollment]
    E --> F[Fetch customer and business address data]
    F --> G[Generate XML string for each submerchant]
    G --> H[Add summary to XML]
    H --> I[Encrypt and store XML locally]
    I --> J[Upload encrypted file to SFTP server and S3 bucket]
    J --> K[Store unencrypted XML locally and upload to S3 bucket]
```

</td>
<td>

### Process Enrollment Results

```mermaid
graph TD;
    A1[Fetch files from 'fromBAMBORA' directory on SFTP server] --> B1[Check file extension]
    B1 --> C1[Copy file from SFTP server to local disk]
    C1 --> D1[Process Result XML]
    D1 --> E1[Fetch content of file from SFTP server]
    E1 --> F1[Decrypt content of file]
    F1 --> G1[Store decrypted content locally]
    G1 --> H1[Load XML content into SimpleXML object]
    H1 --> I1[Convert SimpleXML object to associative array]
    I1 --> J1[Fetch summary, rejections, and approvals from array]
```

</td>
</tr>
</table>

This structure enables the background processing of potentially time-consuming tasks without affecting the user interface or other operations.

## Method: generateEnrollmentXml()

### Description

This method is part of the `BamboraSubmerchantService` class. It is responsible for generating an XML file for submerchant enrollment. The XML file is then encrypted and stored locally before being uploaded to an SFTP server and an S3 bucket.

### Process

1. Fetches all submerchants that are ready for enrollment.
2. If there are no submerchants, the method returns without doing anything.
3. For each submerchant, it fetches the associated customer and business address data.
4. It then generates an XML string for each submerchant, including various details such as legal ID, legal name, legal address, and contact information.

    | XML Tag                | Value                                 |
    |------------------------|---------------------------------------|
    | pf_account_id          | $submerchant->pf_account_id           |
    | legal_id               | $legalId                              |
    | legal_name             | $customer->legal_name                 |
    | legal_address          | $businessAddress->getFullStreetAddress() |
    | legal_city             | $businessAddress->city                |
    | legal_postcode         | $businessAddress->postcode            |
    | legal_country          | $businessAddress->country->code       |
    | dba_name               | $customer->trading_name               |
    | dba_address            | $businessAddress->getFullStreetAddress() |
    | dba_city               | $businessAddress->city                |
    | dba_postcode           | $businessAddress->postcode            |
    | contact_email          | $customer->primary_contact_email      |
    | contact_phone          | $customer->primary_contact_phone      |
    | contact_name           | $customer->primary_contact_fullname   |
    | proxy_mid              | $submerchant->proxy_mid               |
    | country_of_origin      | $businessAddress->country->code       |
    | customer_service_phone | $customer->primary_contact_phone      |

5. If any required data is missing (e.g., business address), an exception is thrown and the submerchant's status is set to `SUBMERCHANT_STATUS_ERROR`.
6. After all submerchants have been processed, a summary is added to the XML.
7. If an exception is thrown during the XML generation, all processed submerchants are reset to `SUBMERCHANT_STATUS_NEW` and the method is called recursively.
8. The XML string is then encrypted and stored locally with a unique filename.
9. The encrypted file is uploaded to an SFTP server and an S3 bucket. If either upload fails, an exception is thrown.
10. A copy of the XML (not encrypted) is also stored locally and uploaded to the S3 bucket.

### Exceptions

This method can throw exceptions for the following reasons:

- Missing customer date of birth
- Missing customer business address
- Error uploading the enrollment file to the SFTP server
- Error uploading the enrollment file to the S3 bucket

### Returns

This method does not return any value.

## Method: processEnrollmentResults()

### Description

This method is part of the `BamboraSubmerchantService` class. It is responsible for processing the enrollment results received from Bambora. The results are fetched from an SFTP server, processed, and then stored in an S3 bucket.

### Process

1. Fetches all files from the 'fromBAMBORA' directory on the SFTP server.
2. For each file, it checks the file extension. If the file extension is 'pgp', it proceeds with the processing. Otherwise, it skips the file.
3. Copies the file from the SFTP server to the local disk.
4. Calls the `processResultXML` method, passing the filename as an argument. This method decrypts the PGP file and processes the XML content, updating the status of each submerchant based on the result in the XML file.
5. After processing the XML, it calls the `moveEnrollmentResultToS3` method, passing the filename as an argument. This method moves the processed file to an S3 bucket for storage.
6. If any exception occurs during this process, it logs the exception message and then rethrows the exception.

### Exceptions

This method can throw exceptions for the following reasons:

- Error fetching files from the SFTP server
- Error copying files from the SFTP server to the local disk
- Error processing the XML content of the file
- Error moving the processed file to the S3 bucket

### Returns

This method does not return any value. It's designed to be called as a task, processing all enrollment results and then exiting.

## Method: processResultXML()

### Description

This method is part of the `BamboraSubmerchantService` class. It is responsible for processing the XML content of a file that contains the results of submerchant enrollments.

### Process

1. Fetches the content of the file from the SFTP server.
2. Decrypts the content of the file.
3. Stores the decrypted content locally.
4. Loads the XML content into a SimpleXML object.
5. Converts the SimpleXML object to an associative array.
6. Fetches the summary, rejections, and approvals from the associative array.
7. Fetches the BamboraEnrollment object associated with the file ID from the database. If the enrollment object is not found, it logs an error and throws an exception.
8. Checks if the total count of approved and rejected submerchants matches the count of submerchants in the enrollment. If the counts do not match, it logs an error and throws an exception.
9. Updates the approved count, rejected count, and rejections in the enrollment and saves the changes to the database.
10. Processes each approval and rejection in the XML content. For each approval and rejection, it fetches the associated submerchant from the database and updates the submerchant's status and other details.
11. If a submerchant is not found in the database, it throws an exception.
12. After processing all approvals and rejections, it updates the status of all submerchants in the enrollment.
13. If a submerchant is approved and the associated customer MID is awaiting activation, it updates the MID and dispatches a `CustomerMidApproved` event.
14. If there are any rejections in the enrollment, it calls the `messagingEventsService->processUnapprovedMid($enrollment->id)` method to process the unapproved MID.
15. If any exception occurs during this process, it logs the exception message.

### Exceptions

This method can throw exceptions for the following reasons:

- Error fetching the content of the file from the SFTP server
- Error decrypting the content of the file
- Error loading the XML content into a SimpleXML object
- Enrollment object not found in the database
- Total count of approved and rejected submerchants does not match the count of submerchants in the enrollment
- Submerchant not found in the database

### Returns

This method does not return any value. It's designed to process the XML content of a file and update the status of submerchants based on the results in the file.

## Code Flow

``` plaintext
Dispatch BamboraEnrollmentsCronJob
    |
    V
Run `bamboraEnrollments` Artisan command
    |
    V
Call `handle()` method of `BamboraEnrollmentsCron`
    |
    V
Call `generateEnrollmentXml()` and `processEnrollmentResults()` on `BamboraSubmerchantService`
```

## MOM Action Answers

1. **What data are we sending and how are we sending it?**
   - Data Sent: Enrollment information for submerchants, including details such as legal ID, legal name, legal address, contact information, etc., is compiled into an XML file.
   - How it's Sent: The `generateEnrollmentXml()` method formats this data into XML. The XML file is then encrypted and uploaded to both an SFTP server and an S3 bucket for further processing by Bambora.

2. **How are we getting Bambora results?**
   - Bambora results are obtained through the `processEnrollmentResults()` method.
   - Process: This method fetches result files from an SFTP server. It decrypts and processes the XML content of these files to update the status of submerchants based on Bambora's response. The processed results are then stored in an S3 bucket.

3. **Tell the data being sent to Bambora and the protocol used for sending requests?**
   - Data Sent to Bambora: Enrollment information for submerchants, formatted as XML, is sent to Bambora.
   - Protocol: The data is transmitted using the XML format, likely over a secure connection such as SFTP (Secure File Transfer Protocol).
