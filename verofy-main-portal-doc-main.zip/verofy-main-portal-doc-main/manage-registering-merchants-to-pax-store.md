## Manage The Merchants Registration in The Pax Store

**Author:** Anouar

### Table of Content
- [Overview](#overview)
- [Code Process](#code-process)
- [Create a Merchant `createMerchant()`](#create-a-merchant-process-details-for-createmerchant)

### Overview
After we have activated the customer (`status=ACTIVE`), we have a scheduled job **`PaxStoreRegisterMerchantsJob`** that runs every 5 minutes within `local` and `production` environments. 
This job triggers the cron **`PaxStoreRegisterMerchants`** that will process the merchants (customers) registration process:

### Code Process
1. First, we will fetch all the **ACTIVATED** `Customer` records whose partners have `pax_reseller_id` and `pax_reseller_name`, and whose `pax_merchant_id` is not set yet.
2. For each `Customer`, we will invoke the function `PaxService@registerCustomer` to start processing the registration of customers as follows:
   - First, we check if the `Customer` already has the `pax_merchant_id` set. If yes, that means we have already registered the customer with **Pax Store** and no further action is required; we just return the `Customer` instance.
   - Preparing the customer details will fulfill the data we need to send to **Pax Store**. All the data we will send are noted below:
  
   
    | field             | Value                                                                                 |
    |-------------------|---------------------------------------------------------------------------------------|
    | `address`         | Street name from the customer business address                          |
    | `city`            | City within the business address`$customerAddress->city`                                                              |
    | `contact`         | Customer primary_contact_fullname                                     |
    | `country`         | 3 alpha code from the country of the business address                                           |
    | `email`           | Customer primary_contact_email                                                    |
    | `createUserFlag`  | `false` (Indicate whether to create user when activating the merchant, default is false) |
    | `description`     |  None                                                                                  |
    | `name`            | Customer Trading name combined with `trading_name-V9 [customer_id]`                                                                 |
    | `phone`           | Customer primary_contact_phone                                                    |
    | `postcode`        | Business address postcode                                                      |
    | `province`        | None                                                                                 |
    | `resellerName`    | the name defined with the field `pax_reseller_name` of the customer partner           |
    | `status`          | `STATUS_ACTIVE`                                                   |

   - Now we will send the data we have prepared to **Pax Store** by invoking the function `PaxStoreApiService@createMerchant`. For more details on the process of creating a merchant, refer to [Create a merchant process details for `createMerchant()`](#create-a-merchant-process-details-for-createmerchant).
   - Update the following `Customer` fields:
     - pax_merchant_id: Set to the merchant id returned after creating the merchant(customer) with  **Pax Store**.
     - pax_merchant_name: Set to the customer trading name combined with `v9` prefix and `customer_id` `trading_name-V9 [customer_id]` 
   - At the end we return the `Customer` instance
3. If an exception throw durring the registration we will catch it and log the exception `PAX_STORE_CRON_EXCEPTION` within `LogService`

### Create a merchant process details for `createMerchant()`
When this function is invoked it will trigger the following actions:
1. Fisrt we generate the query params will appended to request when calling the **Pax Store** api

   | Key        | Value                               |
   |------------|-------------------------------------|
   | sysKey     | Pax Store api system key                       |
   | timestamp  | round(microtime(true) * 1000) :  convert unix timestamp to milliseconds       |

2. Now we send the customer data alognside with the generated query params above to **Pax Store** api
3. Parsing the response and check if status equals to `201` (created); IF not we throw `PaxStoreException`
4. We try to fetch the `id` from the response data. if not found we throw `PaxStoreException`
5. At the end we return the `id` of the created customer with the **Pax Store** service


