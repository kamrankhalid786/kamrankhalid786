## Sign Customer Documents with `SignCustomerDocumentsCronJob`
### How is the job dispatched?
When `CustomerFinanceService@prepareAgreementToBeSent` is invoked, we generate all the documents needed for the finance agreement. At the end, we invoke the function `CustomerFinanceService@onFinanceReadyForAuditTrail`, which updates the `CustomerFinanceAgreement` status to `READY_FOR_AUDIT_TRAIL` and the agreement `SignPack` status to `STATUS_READY_FOR_AUDIT_TRAIL`. Then, we dispatch the job `SignCustomerDocumentsCronJob`.

 Dispatch the job `SignCustomerDocumentsCronJob` will executen the `SignCustomerDocumentsCron` command:
 
 - Fetching all the `SignPack` within the status `STATUS_READY_FOR_AUDIT_TRAIL` and has completed `Customer` (status in [`AWAITING_COMPLETION`, `AWAITING_ACTIVATION`, `ACTIVE`])
 - For each `SignPack` we will generate an audit trail by invoking the function `DocumentSignService@generateAuditTrail` [Generate audit trail process description](#generate-audit-trail-process-description).
 - Fetching all the customer contract `CustomerContract` within the current `SignPack`
 - For each `CustomerContract` we fetch all its related `CustomerFinanceAgreement`
 - For each `CustomerFinanceAgreement` we will invoke the function `CustomerFinanceService@onFinanceReadyToBeSent` [Finance ready to be sent process description](#finance-ready-to-be-sent-process-description)
 - IF something goes wrong we will log `DOCUMENT_SIGN_EXCEPTION` with the `LogService`

#### Generate audit trail process description
1. Fetching the `ENVELOPE` doc type details (static array)
2. Generate the data which will be used to fill details with `TEMPLATE_SIGN_ENVELOPE` file that we will fetch from `s3`

| Field           | Value                                     |
|-----------------|-------------------------------------------|
| customer_name   | Str::title($customer->legal_name)        |
| device_id       | $pack->signed_on_device_id               |
| signer_name     | $pack->customerUser->name                |
| signature_date  | $pack->signed_at?->format('d/m/Y')       |
| history         | $pack->getHistoryforPdf()                |

3. Fetch the template from `s3` and make a localy copy of it
4. Filling the template details by invoking the function `DocumentTemplateService@fillTemplate` and pass to it three params:
   - localTemplatePath: the path for the local copy of the template
   - filledDocumentPath: The path where the generate pdf file from the template will be saved
   - fileData: the data will be used to fill details with the template file
  
5. We fetch the customer applicant the current `SignPack` belong to.
6. We fetch the signature document from `s3` and store a local temporary copy for use in signing the audit trail.
7. We sign the generated document (`Envelope`)  by invoking the `DocumentSignService@signAuditTrail` using the `Fpdi` service
8. We encrypt the generated document (`Envelope`)  by invoking the function `DocumentSignService@encryptAuditTrail` using `Mpdf`
9. We upload the created file to `s3` and create the `CustomerDocument` to record the dcoument type `ENVELOPE` and the file details.
10. We associate the created `CustomerDocument` with the `SignPack`
11. Then we invoke the function `SignPackService@completePack` which update the `SignPack` status to `STATUS_COMPLETED` and report with the pack history that the `Agreement completed`
12. At the end we return true to indicate that the generation of audit trail is succeed

#### Finance ready to be sent process description
1. First we ensure if the `CustomerFinanceAgreement` is ready for audit trail. If the the staus if the agreement not equal to `READY_FOR_AUDIT_TRAIL` we return and do nothing.
2. We update the `CustomerFinanceAgreement` `status` to `READY_TO_SEND_DATA`
3. We log `FINANCE_READY` within the `CustomerOperation`
4. Dispatch the `SendFinanceAgreementsCronJob` job which will execute the `SendFinanceAgreementsCron` check [Handle Finance agreement](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/finance-company-first-data.md)
