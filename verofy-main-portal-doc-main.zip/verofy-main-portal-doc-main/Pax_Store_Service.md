# Pax Store Service [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Pax_Store/Pax.txt)

## Table of Contents

- [Introduction](#introduction)
- [Jobs & Scheduling](#jobs--scheduling)
- [Business Logic](#business-logic)
- [Code Flow Diagram](#code-flow-diagram)
- [Create Resellers](Pax_Store/Create_PaxStore_Resellers.md)
- [Create Merchants](Pax_Store/Create_PaxStore_Merchants.md)
- [Create Terminals](Pax_Store/Create_PaxStore_Terminals.md)
- [Manage Customer Registration with Pax Store](manage-registering-merchants-to-pax-store.md)

![Pax Store Diagram](Pax_Store/pax-store.png)

## Introduction

The Pax Store integration involves several jobs that are scheduled to run at different intervals. These jobs are responsible for creating and updating resellers, merchants, and terminals in the Pax Store.

## Jobs & Scheduling

The following jobs are part of the Pax Store integration:

| Job Name | Description | Schedule |
| --- | --- | --- |
| `PaxStoreUpdateTerminalsCronJob` | This job is responsible for updating the terminals in the Pax Store. | Runs every 5 minutes starting from the `4th` minute of the hour. |
| `PaxStoreCreateTerminalsCronJob` | This job is responsible for creating terminals in the Pax Store. | Runs every 5 minutes starting from the `5th` minute of the hour. |
| `PaxStoreRegisterMerchantsJob` | This job is responsible for creating merchants in the Pax Store. | Runs every 5 minutes starting from the `6th` minute of the hour. |
| `PaxStoreRegisterResellersJob` | This job is responsible for creating resellers in the Pax Store. | Runs every 5 minutes starting from the `7th` minute of the hour. |
| `PaxStoreForceUpdateTerminalsCronJob` | This job is responsible for forcing an update on the terminals in the Pax Store. | Runs every 5 minutes starting from the `14th` minute of the hour. |

## Business Logic

The jobs should be run in a specific order according to the business logic:

1. **Create PaxStore Resellers**: Before creating merchants or terminals, the resellers should be created first. Resellers are entities that sell your product to merchants.
2. **Create PaxStore Merchants**: After the resellers are created, the merchants can be created. Merchants are entities that will use your terminals.
3. **Create PaxStore Terminals**: After the merchants are created, the terminals can be created. Terminals are assigned to merchants.
4. **Update PaxStore Terminals**: After all the terminals are created, they can be updated. This job is responsible for updating the status and information of the terminals.
5. **Force Update PaxStore Terminals**: This job is responsible for forcing an update on the terminals. This should be done after all the creation and regular updates are done.

## Code Flow Diagram

```mermaid
graph TD;
    Create_PaxStore_Resellers --> Create_PaxStore_Merchants
    Create_PaxStore_Merchants --> Create_PaxStore_Terminals
    Create_PaxStore_Terminals --> Update_PaxStore_Terminals
    Update_PaxStore_Terminals --> Force_Update_PaxStore_Terminals
```

## [Create Resellers](Pax_Store/Create_PaxStore_Resellers.md)

## [Create Merchants](Pax_Store/Create_PaxStore_Merchants.md)

## [Create Terminals](Pax_Store/Create_PaxStore_Terminals.md)
