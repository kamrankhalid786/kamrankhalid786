### Customer Site Visit: 

#### When is a site visit required?
A site visit will be required under the following criteria:
 - If the customer business type is `SOLO TRADER` or `PARTNERSHIP` and proof of trading address is not provided.
 - If the customer is a company and their trading address is not the same as their legal address and proof of trading address is not provided.

#### How is a customer site visit `CustomerSiteVisit` record created?
Customer site visits `CustomerSiteVisit` are created by sellers for their customers under `App\Http\Controllers\Api\PartnerPortalApi\CustomerSiteVisitsController@createSiteVisitV1`.

The requirement for a customer site visit is determined by the `isSiteVisitRequired()` function within the `Customer` model when the following occurs:

- When `CompleteCustomerAction` is triggered in the following contexts:

  - Within the controller `App\Http\Controllers\Api\CustomerRegistrationApi\CRCompletionController@registrationCompletionV1`, the function `CustomerAdditionalKycService@completeKyc` is invoked. This triggers the action `CompleteCustomerAction`, which checks if a site visit is required. If it is, the customer is notified that their application will be reviewed once the site visit is completed.

  - In the controller `App\Http\Controllers\Api\CustomerRegistrationApi\CRCompletionController@registrationCompletionV1`, the method `CustomerService@onMainApplicantKycCompleted` is called. This invokes `CustomerRegistrationService@completeRegistrationMainApplicantKyc`, subsequently triggering the action `CompleteCustomerAction`. This action then checks if a site visit is required. If so, the customer is notified that their application will be reviewed once the site visit is completed.

  - In the controller `App\Http\Controllers\Api\CustomerRegistrationApi\CRCompletionController@registrationCompletionV1`, the method `CustomerRegistrationService@completeRegistrationShareholderKyc` is called. This invokes `CustomerService@onShareholderKycCompleted`, subsequently triggering the action `CompleteCustomerAction`. This action then checks if a site visit is required. If so, the customer is notified that their application will be reviewed once the site visit is completed.

  - In the controller `App\Http\Controllers\Api\CustomerRegistrationApi\CRConfirmationController@registrationConfirmationV1`, the function `CustomerAdditionalKycService@completeKyc` is called. This invokes `CompleteCustomerAction`, which checks if a site visit is required. If so, the customer is notified that their application will be reviewed once the site visit is completed.

  - In the controller `App\Http\Controllers\Api\PartnerPortalApi\CustomerSiteVisitsController@completeSiteVisitV1`, the function `CustomerSiteVisitService@completeSiteVisit` is called. This invokes `CompleteCustomerAction`, which checks if a site visit is required. If so, the customer is notified that their application will be reviewed once the site visit is completed.

  - In the controller `App\Http\Controllers\Api\AdminPortalApi\CustomersController@deleteCustomerApplicantV1`, the function `CustomerApplicantsService@deleteApplicant` is called. This invokes `CompleteCustomerAction`, which checks if a site visit is required. If so, the customer is notified that their application will be reviewed once the site visit is completed.

- When the controller function `App\Http\Controllers\Api\AdminPortalApi\CustomersController@initiateSiteVisitV1` is invoked. It triggers the action `InitiateSiteVisitForRejectedPoaAction`. Subsequently, this action updates the customer's `is_site_visit_required` based on the current value returned by `$customer->isSiteVisitRequired()`.

- When one of the controller functions `App\Http\Controllers\Api\AdminPortalApi\CustomerBoardingRulesController@{getBoardingRuleV1, updateBoardingRuleStatusV1, doBoardingRuleCheckV1, processBoardingRuleRelevantActionV1, updateBoardingRuleMetaDataV1}` is invoked, the function `CustomerBoardingRulesService@addRelevantDataToCustomerBoardingRule` is called, which also invokes `CustomerBoardingRulesService@getBoardingRuleRelevantInfo`. This triggers `SellerSiteVisitBoardingRule@getRelevantInfo`, which will render a view with the site visit details if a site visit is required.

- When one of the controller functions `App\Http\Controllers\Api\AdminPortalApi\CustomerBoardingRulesController@{getBoardingRuleV1, updateBoardingRuleStatusV1, doBoardingRuleCheckV1, processBoardingRuleRelevantActionV1, updateBoardingRuleMetaDataV1}` is invoked, the function `CustomerBoardingRulesService@addRelevantDataToCustomerBoardingRule` is called, which also invokes `CustomerBoardingRulesService@getBoardingRuleRelevantImages`. This triggers `SellerSiteVisitBoardingRule@getRelevantImages`, which will fetch all the `CustomerSiteVisit` documents, then for each one, will fetch its file from S3 and set it under the `images[]` array.

- When the controller function `App\Http\Controllers\Api\AdminPortalApi\CustomerDocumentsController@uploadDocumentFromStreamV1` is invoked, it will update the customer's `is_site_visit_required` if the uploaded document type using stream is of type `PROOF_ADDRESS_DOCUMENT`.

- When the controller function `App\Http\Controllers\Api\CustomerRegistrationApi\UpdateCustomerRegistrationApplicationController@updateRegistrationById` is invoked. It triggers the function `UpdateCustomerRegistrationApplicationTrait@completeWebPortalRegistration`. Subsequently, this function updates the customer's `is_site_visit_required` when completing customer web portal registration. If a site visit is required, we will notify the seller to complete the site visit from his mobile app.

- When the controller function `App\Http\Controllers\Api\AdminPortalApi\CustomerOperationsController@generateFinanceAgreement` or `SendFinanceAgreementsCron` is invoked, it triggers the function `CustomerFinanceService@prepareAgreementToBeSent`. Subsequently, within this function, if a site visit is required, we generate a site visit confirmation document and sign it using the customer's and seller's signature documents.

- When the controller function `App\Http\Controllers\Api\AdminPortalApi\CustomerOperationsController@generateFinanceAgreement` or `SendFinanceAgreementsCron` is invoked, it triggers the function `CustomerFinanceService@sendToFinanceCompany`. Subsequently, within this function, if a site visit is required, we generate a site visit confirmation document and sign it using the customer's and seller's signature documents.

- When the controller function `App\Http\Controllers\Api\AdminPortalApi\CustomerOperationsController@generateFinanceAgreement` or `SendFinanceAgreementsCron` is invoked, it triggers the function `CustomerFinanceService@sendToFinanceCompany`, which invokes `FirstDataService@sendEmailToFirstData`. Subsequently, within this function, if a site visit is required, we fetch the site visit photos: `SITE_VISIT_[OVERVIEW, INSIDE, FRONT, STOCK]_PHOTO`.
