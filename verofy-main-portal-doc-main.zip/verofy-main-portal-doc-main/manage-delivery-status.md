
## Manage The Delivery Status: `CheckNoPaymentTakenCustomersCronJob`

**Author:** Anouar

### Overview
After we have set the products live when we run the cron `SetProductsLiveCronJob`, we have a scheduled job **`CheckServiceLogisticDeliveryStatusCronJob`** that runs daily at `20:00 pm` within `local`, `staging` and `production` environments. This job triggers the cron **`CheckServiceLogisticDeliveryStatusCron`** which update the `CustomerProduct` `status` to `NOT_YET_TRANSACTED` when we have a contract one more than one terminals, and one is transacting and the other is not yet.

### Code Process

1. Fetch contracts from `CustomerProduct` with more that one `CustomerProduct`
2. Fetch contract with delivered products , `status` `LIVE_TRN_THIS_MONTH` where the `CustomerProduct`  `customer_contract_id` in the list of the contracts within more than one product
3. Fetch all `customerProduct`  where `customer_contract_id` in the the contract with delivered products
4. For each selected `CustomerProduct` update the `status` to `NOT_YET_TRANSACTED`
