# Create PaxStore Resellers [![Version](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Create_PaxStore_Resellers.txt)

## Table of Contents

- [Introduction](#introduction-create-paxstore-resellers)
- [Kernel](#kernel)
- [Job](#job)
- [Command](#command)
- [Service](#service)
- [createReseller Data](#createreseller-data)
  
## Introduction: Create PaxStore Resellers

This process involves several components including a Kernel, a Job, a Command, and two Services.

## Kernel

The Kernel schedules the `PaxStoreRegisterResellersJob` to run every 5 minutes starting from the 7th minute of the hour. This is done without overlapping and on one server.

| Property | Value |
| --- | --- |
| Scheduler Job Name | `PaxStoreRegisterResellersJob` |
| Environments | `local` `production` |
| Frequency | Every 5 minutes from the 7th to the 59th minute of each hour |
| Overlapping | Prevented, with a 10-minute threshold |
| Server Execution | Runs on only one server |

## Job

The `PaxStoreRegisterResellersJob` handles the job by calling the `pax-store:register-resellers` artisan command.

```php
public function handle(): void
{
    Artisan::call('pax-store:register-resellers');
}
```

## Command

The `PaxStoreRegisterResellers` command retrieves the partner ID argument, queries the Partner model for partners with complete status and no `pax_reseller_id`, and registers each partner using the `PaxService`.

```php
protected function getArguments()
{
    return [
        ['partnerId', InputArgument::OPTIONAL, 'The ID of the partner (optional)'],
    ];
}
```

## Service

The `PaxService` registers a partner by checking if the partner is already registered, creating a reseller in the Pax Store if not, and storing the registered data into the partner.

```php
public function registerPartner(Partner $partner): Partner
{
    // Check already registered within PaxStore.
    if (!empty($partner->pax_reseller_id)) {
        return $partner;
    }

    // ... (code omitted for brevity)

    $resellerId = $this->paxStoreApiService->createReseller($resellerData);

    // Store registered data into partner.
    $partner->pax_reseller_id = $resellerId;
    $partner->pax_reseller_name = $resellerName;
    $partner->save();

    // Send notification
    $this->messagingEventsService->processSystemPaxResellerCreated($partner);

    return $partner;
}
```
  
The `PaxStoreApiService` creates a reseller by making a POST request to the Pax Store API and returns the reseller ID.

```php
public function createReseller($data)
{
    $query = $this->generateQuery();
    $uri = 'resellers';
    $response = $this->restClient->request('POST', $uri, [
        'headers' => ['signature' => $this->generateToken($query)],
        'json' => $data,
        'query' => $query
        ]);

    // ... (code omitted for brevity)

    return $id;
}
```

### createReseller Data

| Key | Description |
| --- | --- |
| `address` | The full street address of the partner location. |
| `company` | The company name of the partner. |
| `contact` | The full name of the contact person at the partner. |
| `country` | The 3-letter ISO code of the country where the partner is located. |
| `email` | The email address to use for the reseller, in this case, it's set to <tech-account@verofy.com>. |
| `name` | The name of the reseller, which is the partner's name with special characters replaced and ' - V2' appended. |
| `parentResellerName` | The name of the parent reseller, set in the PAX STORE configuration. |
| `phone` | The phone number of the contact person at the partner. |
| `postcode` | The postal code of the partner location. |
| `status` | The status of the reseller, set to 'Active'. |
