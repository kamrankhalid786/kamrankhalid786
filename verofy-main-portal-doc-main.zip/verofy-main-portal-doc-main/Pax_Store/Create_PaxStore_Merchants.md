# Create PaxStore Merchants [![Version](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Create_PaxStore_Merchants.txt)

## Table of Contents

- [Introduction](#introduction-create-paxstore-merchants)
- [Kernel](#kernel)
- [Job](#job)
- [Command](#command)
- [Service](#service)
- [createMerchant Data](#createmerchant-data)
- [Merchants Registration on The Pax Store: Detailed process description](../manage-registering-merchants-to-pax-store.md)

## Introduction: Create PaxStore Merchants

This process involves several components including a Kernel, a Job, a Command, and two Services.

## Kernel

The Kernel schedules the `PaxStoreRegisterMerchantsJob` to run every 5 minutes starting from the 6th minute of the hour. This is done without overlapping and on one server.

| Property | Value |
| --- | --- |
| Scheduler Job Name | `PaxStoreRegisterMerchantsJob` |
| Environments | `local` `production` |
| Frequency | Every 5 minutes from the 6th to the 59th minute of each hour |
| Overlapping | Prevented, with a 10-minute threshold |
| Server Execution | Runs on only one server |

## Job

The `PaxStoreRegisterMerchantsJob` handles the job by calling the `pax-store:register-merchants` artisan command.

```php
public function handle(): void
{
    Artisan::call('pax-store:register-merchants');
}
```

## Command

The `PaxStoreRegisterMerchants` command retrieves the customer ID argument, queries the Customer model for customers with active status and no `pax_merchant_id`, and registers each customer using the `PaxService`.

```php
protected function getArguments()
{
    return [
        ['customerId', InputArgument::OPTIONAL, 'The ID of the customer (optional)'],
    ];
}
```

## Service

The `PaxService` registers a customer by checking if the customer is already registered, creating a merchant in the Pax Store if not, and storing the registered data into the customer.

```php
public function registerCustomer(Customer $customer): Customer
{
    // Check already registered within PaxStore.
    if (!empty($customer->pax_merchant_id)) {
        return $customer;
    }

    // ... (code omitted for brevity)

    $merchantId = $this->paxStoreApiService->createMerchant($customerData);

    // Store registered data into customer.
    $customer->pax_merchant_id = $merchantId;
    $customer->pax_merchant_name = $merchantName;
    $customer->save();

    return $customer;
}
```

The `PaxStoreApiService` creates a merchant by making a POST request to the Pax Store API and returns the merchant ID.

```php
public function createMerchant($jsonData)
{
    $query = $this->generateQuery();
    $uri = 'resellers';
    $response = $this->restClient->request('POST', $uri, [
        'headers' => ['signature' => $this->generateToken($query)],
        'json' => $data,
        'query' => $query
        ]);

    // ... (code omitted for brevity)

    return $id;
}
```

### createMerchant Data

| Key | Description |
| --- | --- |
| `address` | The full street address of the customer's business location. |
| `city` | The city of the customer's business location. |
| `contact` | The full name of the primary contact person at the customer's business. |
| `country` | The 3-letter ISO code of the country where the customer's business is located. |
| `email` | The email address of the primary contact at the customer's business. |
| `createUserFlag` | A flag indicating whether to create a user when activating the merchant. The default value is false. |
| `description` | An empty string. |
| `name` | The name of the merchant, which is the customer's trading name with special characters replaced and ' - V2 ' and the customer's ID appended. |
| `phone` | The phone number of the primary contact at the customer's business. |
| `postcode` | The postal code of the customer's business location. |
| `province` | An empty string. |
| `resellerName` | The name of the reseller, which is the name of the partner associated with the customer. |
| `status` | The status of the merchant, set to 'Active'. |
