# Create PaxStore Terminals [![Version](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

## Table of Contents

- [Introduction](#introduction-create-paxstore-terminals)
- [Kernel](#kernel)
- [Job](#job)
- [Command](#command)
- [Command Handle Method](#command-handle-method)
- [Service](#service)
- [createTerminal Data](#createterminal-data)
- [Terminals Creation in The Pax Store: Detailed process description](../mange-terminals-creation-with-pax-store.md#creating-terminal-variables)

## Introduction: Create PaxStore Terminals

This process involves several components including a Kernel, a Job, a Command, and two Services.

## Kernel

The Kernel schedules the `PaxStoreCreateTerminalsCronJob` to run every 5 minutes starting from the 5th minute of the hour. This is done without overlapping and on one server.

| Property | Value |
| --- | --- |
| Scheduler Job Name | `PaxStoreCreateTerminalsCronJob` |
| Environments | `local` `production` |
| Frequency | Every 5 minutes from the 5th to the 59th minute of each hour |
| Overlapping | Prevented, with a 10-minute threshold |
| Server Execution | Runs on only one server |

## Job

The `PaxStoreCreateTerminalsCronJob` handles the job by calling the `pax-store:create-terminals` artisan command.

```php
public function handle(): void
{
    Artisan::call('pax-store:create-terminals');
}
```

## Command

The `PaxStoreCreateTerminalsCron` command retrieves the terminal ID argument, queries the `CustomerProduct` model for terminals that should be created in PaxStore, and creates each terminal using the `PaxService`.

```php
protected function getArguments()
{
    return [
        ['terminalId', InputArgument::OPTIONAL, 'The ID of the terminal (optional)'],
    ];
}
```

### Command Handle Method

| Condition | Description |
| --- | --- |
| `shouldBeCreatedInPaxStore()` | This is a scope on the `CustomerProduct` model that adds additional conditions to the query to only include records that should be created in PaxStore. The exact conditions depend on the implementation of this scope. |
| `where('status', CustomerProductStatus::APPROVED)` | This condition filters the records to only include those where the status is `approved`. |
| `whereNull('pax_terminal_id')` | This condition filters the records to only include those where the `pax_terminal_id` is `null`, meaning the terminal has not been registered in PaxStore yet. |
| `whereHas('customer', function($query) {...})` | This condition filters the records to only include those that are associated with a `customer` that is `active`, registered in PaxStore, and has a partner that is registered in PaxStore. |
| `whereHas('contract', function ($query) {...})` | This condition filters the records to only include those that are associated with a completed and finance `approved contract`. |
| `whereHas('customerMids', function($query) {...})` | This condition filters the records to only include those that are associated with an approved `customer MID`. |

## Service

The `PaxService` creates a terminal by checking if the terminal is already registered, creating a terminal in the Pax Store if not, and storing the registered data into the terminal.

```php
public function createPaxTerminal(CustomerProduct $terminal): CustomerProduct
{
    $modelName = ($terminal->product->order_code === 'A920 PRO' || $terminal->product->order_code === 'A920 PRO WITH SIM')
        ? 'A920Pro'
        : '';
    $terminalLocation = $terminal->customerLocations()->withPivot(['customer_mid_id'])->first();
    $terminalData = [
        'location' => $terminalLocation->name,
        'merchantName' => $terminal->customer->pax_merchant_name,
        'modelName' => $modelName,
        'name' => substr($terminal->product->name, 0, 60),
        'resellerName' => $terminal->customer->partner->pax_reseller_name,
        'status' => PaxStoreApiService::STATUS_PENDING,
        'tid' => $terminal->tid,
    ];
    $terminalId = $this->paxStoreApiService->createTerminal($terminalData);
    $terminal->pax_terminal_id = $terminalId;
    $terminal->pax_status = CustomerProduct::PAX_STATUS_NEW;
    $terminal->save();

    $this->createTerminalVariables($terminal, $terminalLocation);
    $this->pushPositivePlusManagerAppToTerminal($terminal);
    $this->pushPositivePlusAppToTerminal($terminal);

    return $terminal;
}
```

The `PaxStoreApiService` creates a terminal by making a POST request to the Pax Store API and returns the terminal ID.

```php
public function createTerminal($jsonData)
{
    $uri = 'terminals';
    $query = $this->generateQuery();
    $response = $this->restClient->request('POST', $uri, [
        'headers' => ['signature' => $this->generateToken($query)],
        'json' => $jsonData,
        'query' => $query
    ]);

    // ... (code omitted for brevity)

    return $id;
}
```

### createTerminal Data

| Key | Description |
| --- | --- |
| `location` | The name of the terminal location. |
| `merchantName` | The name of the merchant associated with the terminal. |
| `modelName` | The model name of the terminal. |
| `name` | The name of the terminal. |
| `resellerName` | The name of the reseller associated with the terminal. |
| `status` | The status of the terminal. |
| `tid` | The terminal ID. |
