# Update PaxStore Terminals [![Version](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

```php
// Kernel:
// Update PaxStore Terminals
$schedule->job(PaxStoreUpdateTerminalsCronJob::class, JobType::CRON_1)
    ->cron('4-59/5 * * * *')
    ->environments(['local', 'production'])
    ->withoutOverlapping(10)
    ->onOneServer();

// Job > PaxStoreUpdateTerminalsCronJob
public function handle(): void
{
    Artisan::call('pax-store:update-terminals');
}

//Command > PaxStoreUpdateTerminalsCron
protected function getArguments()
{
    return [
        ['terminalId', InputArgument::OPTIONAL, 'The ID of the terminal (optional)'],
    ];
}

public function handle()
{
    // Retrieve arguments.
    $terminalId = $this->argument('terminalId');

    // \DB::enableQueryLog();
    $query = CustomerProduct::query()
        ->shouldBeCreatedInPaxStore()
        ->whereNotNull('pax_terminal_id') // Terminal not registered in PaxStore yet
        ->where('pax_status', '!=', CustomerProduct::PAX_STATUS_POSITIVE_PLUS_APP_PUSHED);

    // Filter specific customer if needed.
    if ($terminalId !== null) {
        $terminal = CustomerProduct::find($terminalId);
        if (!$terminal) {
            $this->error('Terminal not found.');
            return 0;
        }

        $query->where('id', $terminalId);
    }

    $terminals = $query->get();
    // var_dump(\DB::getQueryLog()); die();

    foreach ($terminals as $terminal) {
        try {
            $this->paxService->updatePaxTerminal($terminal);
        } catch (\Throwable $e) {
            LogService::log(LogCode::PAX_STORE_CRON_EXCEPTION, message: 'Update terminal exception', exception: $e);
        }
    }

    return 0;
}
```
