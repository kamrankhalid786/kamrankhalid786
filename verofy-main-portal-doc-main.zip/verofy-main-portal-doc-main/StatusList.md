# List of Status [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Notes](StatusList.txt)

## Table of Contents

- [Overall Status Completion Order (Ascending)](#overall-status-completion-order-ascending)
- [Overall Status](#overall-status)
- [Customer Status](#customer-status)
- [Customer Product Status](#customer-product-status)
- [Customer Finance Agreement Status](#customer-finance-agreement-status)
- [Customer Mid Status](#customer-mid-status)

## Overall Status Completion Order (Ascending)

| Status Constant | ID | Name | Description |
| --- | --- | --- | --- |
| PRE_REGISTRATION | 0 | Seller not completed | Application incomplete |
| AWAITING_MERCHANT_COMPLETION | 10 | Customer not completed | Boarding incomplete |
| AWAITING_SHAREHOLDER_COMPLETION | 20 | Shareholder not completed | Shareholder incomplete |
| AWAITNG_SITE_VISIT | 30 | Site visit not completed | Site Visit required |
| ONBOARDING_COMPLETE | 40 | Application in review | Onboarding complete |
| KYC_REFER | 42 | KYC referred | - |
| REFERRED_APPLICATION | 43 | Application referred | - |
| ADDITIONAL_INFORMATION_REQUESTED | 44 | Information request | - |
| AWAITING_MID | 41 | Awaiting MID | MID approved |
| MID_APPROVED | 45 | MID assigned | MID approved |
| APPLICATION_WITH_UNDERWRITING | 46 | Application with underwriting | - |
| TERMINAL_ORDERED | 100 | Awaiting despatch | Order being prepared |
| 333 | 333 | Despatched | Order Dispatched |
| TERMINAL_FAILED_DELIVERY | 140 | Delivery failed | - |
| GROUP_CUSTOMER_NOT_TRANSACT | 444 | Customer not transacted | - |
| MERCHANT_ACTIVE_AND_TRANSACTING | 130 | Customer has transacted | - |
| MERCHANT_DECLINED | 90 | Declined | - |
| CUSTOMER_ON_HOLD | 555 | On hold | - |

Each status also has a `total` field which is currently set to `0`.

## Overall Status

Here are all the overall status:

| Overall Status | Condition |
|----------------|-----------|
| PRE_REGISTRATION | - |
| AWAITING_MERCHANT_COMPLETION | Default status |
| AWAITING_SHAREHOLDER_COMPLETION | If customer status is AWAITING_COMPLETION and any of the customer's shareholders have not completed KYC |
| AWAITNG_SITE_VISIT | If customer status is AWAITING_COMPLETION and all of the customer's shareholders have completed KYC |
| ONBOARDING_COMPLETE | If customer status is AWAITING_ACTIVATION and no boarding rules were referred |
| AWAITING_MID | If customer status is ACTIVE |
| KYC_REFER | If customer status is AWAITING_ACTIVATION and any KYC boarding rules were referred within 30 minutes of onboarding completion |
| REFERRED_APPLICATION | If customer status is AWAITING_ACTIVATION and any application boarding rules were referred |
| ADDITIONAL_INFORMATION_REQUESTED | - |
| MID_APPROVED | If any of the customer's MIDs have been approved |
| APPLICATION_WITH_UNDERWRITING | If the first approved MID was approved at least 10 minutes ago |
| APPLICATION_APPROVED | If any of the customer's finance agreements have been approved |
| FULL_RESET_TO_PARTNER | - |
| FULL_RESET_TO_PARTNER_FINANCE_RES | - |
| FULL_RESET_TO_PARTNER_PRODUCT_RES | - |
| FULL_RESET_TO_PARTNER_FINANCE_PRODUCT_RES | - |
| PARTIAL_RESET_TO_MERCHANT | If any of the customer's applicants have additional KYC requests with status AWAITING_COMPLETION |
| MERCHANT_DECLINED | If customer status is DECLINED, or any of the customer's MIDs are declined, or any of the customer's finance agreements are declined |
| TERMINAL_ORDERED | If any of the customer's products have been ordered |
| TERMINAL_DISPATCHED | If any of the customer's products have been dispatched |
| TERMINAL_DELIVERED | If any of the customer's products have been delivered |
| MERCHANT_ACTIVE_AND_TRANSACTING | If all of the customer's products are live |
| TERMINAL_FAILED_DELIVERY | If any of the customer's products were dispatched but not delivered by 10pm of the dispatched day |
| TERMINAL_RE_DELIVERY | - |
| FINANCE_COMMISSION_AVAILABLE | - |
| MERCHANT_NOT_TRANSACTED | If none of the customer's products are live and the customer has not transacted within 24 hours of delivery |
| GROUP_CUSTOMER_NOT_TRANSACT | - |
| CUSTOMER_ON_HOLD | - |

## Customer Status

Here are all the customer status:

| Status | Label | Progress Label | Progress Icon | Vtiger ID | Internal Description |
|--------|-------|----------------|---------------|-----------|----------------------|
| AWAITING_MAIN_COMPLETION | Onboarding in progress | Onboarding in progress | 2 | Onboarding In Progress | Completed portal registration - the main applicant has not yet completed the mobile part |
| AWAITING_COMPLETION | Awaiting completion | Onboarding in progress | 2 | Onboarding In Progress | Other shareholders have not yet completed the mobile part or the site visit has not been completed yet |
| AWAITING_ACTIVATION | Onboarding complete - In review | Onboarding complete - In review | 3 | Onboarding Complete | Completed both portal and mobile registration - awaiting boarding rules confirmation |
| ACTIVE | Active | Customer activated | 4 | Active | Active (live) customer - successfully confirmed within boarding process |
| DECLINED | Declined | Customer declined | 1 | Declined | Declined customer for whatever reason |
| ARCHIVED | Archived | Customer archived | 1 | Archived | Archived customer |
| PREREGISTRATION | Application incomplete | Awaiting | 1 | Application Incomplete | The application is incomplete |

Each of these statuses represents a different stage in the customer's journey. The `getActiveStatuses` method returns the statuses that are considered "active", which are `ACTIVE` in this case.

## Customer Product Status

Here are all the customer product status:

| Status | Label | Progress Label | Progress Icon | Vtiger ID |
|--------|-------|----------------|---------------|-----------|
| ORDERED | Ordered | Product ordered | 3 | Ordered |
| DISPATCHED | Dispatched | Product dispatched | 4 | Dispatched |
| NOT_YET_TRANSACTED | Not yet transacted | Not Yet Transacted | 4 | Not Yet Transacted |
| LIVE_TRN_THIS_MONTH | Live TRN this month | Live TRN this month | 4 | Live TRN This Month |
| LIVE_TRN_PREV_MONTH | Live TRN prev month | Live TRN prev month | 4 | Live TRN Prev Month |
| LIVE_TRN_MORE_THAN_2_MONTHS | Live TRN more than 2 months | Live TRN more than 2 months | 4 | Live TRN More than 2 Months |

Each of these statuses represents a different stage in the customer's product journey. The `getActiveStatuses` method returns the statuses that are considered "active", which are `LIVE_TRN_THIS_MONTH`, `LIVE_TRN_PREV_MONTH`, and `LIVE_TRN_MORE_THAN_2_MONTHS` in this case.

## Customer Finance Agreement Status

Here are all the customer finance status:

| Status | Label | Progress Label | Progress Icon | Vtiger ID |
|--------|-------|----------------|---------------|-----------|
| AWAITING_REVIEW | Awaiting review | Awaiting review | 2 | Awaiting review |
| READY_TO_SEND_DATA | Ready to send data | Finance verified | 2 | Ready To Send Data |
| PENDING | Pending | Finance pending | 3 | Pending |
| APPROVED | Approved | Finance approved | 4 | Approved |
| DECLINED | Declined | Finance declined | 1 | Decline |
| WITHDRAWN | Withdrawn | Finance withdrawn | 1 | Withdrawn |

Each of these statuses represents a different stage in the customer's finance journey. The `getStatusOptions` method returns the labels of all the statuses.

## Customer Mid Status

Here are all the customer MID (Merchant ID) status:

| Status | Label | Progress Label | Progress Icon | Vtiger ID |
|--------|-------|----------------|---------------|-----------|
| AWAITING_BOARDING | Awaiting boarding | MID registered | 2 | Awaiting Boarding |
| AWAITING_MID_ACTIVATION | Awaiting MID activation | MID boarded | 3 | Awaiting MID Activation |
| MID_APPROVED | MID approved | MID approved | 4 | MID Approved |
| MID_DECLINED | MID declined | MID declined | 1 | MID Declined |
| WITHDRAWN | Withdrawn | MID withdrawn | 1 | Withdrawn |

Each of these statuses represents a different stage in the customer's MID journey. The `getStatusOptions` method returns the labels of all the statuses.
