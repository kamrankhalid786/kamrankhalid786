## Manage The Terminals Creation in The Pax Store

**Author:** Anouar

### Table of Content
- [Overview](#overview)
- [Code Process](#code-process)
- [Process Description For Creating Terminals In Pax Store](#process-description-for-creating-terminals-in-pax-store)
- [Creating Terminal Variables](#creating-terminal-variables)
- [Pushing Positive Plus Manager App to The Terminal](#pushing-positive-plus-manager-app-to-the-terminal)
- [Pushing Positive Plus App To the terminal](#pushing-positive-plus-app-to-the-terminal)
### Overview
After we have registered the customer with Pax Store using `PaxStoreRegisterMerchants` and update the `Customer` `pax_merchant_id` and `pax_merchant_name` with the relevant values. We have a scheduled job  **`PaxStoreCreateTerminalsCronJob`** that runs every 5 minutes within `local` and `production` environments. 
This job triggers the cron **`PaxStoreCreateTerminalsCron`** that will process the creation of terminals on **Pax Store** :

### Code Process
1. First we will fetch all the terminals (`CustomerProduct`) that much the following criterias:
   - Must be created on Pax Store (`CustomerProduct` that is belongs to `Product` within the `order_code` `A920 PRO` or `A920 PRO WITH SIM`)
   - `CustomerProduct` Status must be `APPROVED`
   - `pax_terminal_id` is null , to exclude the products that we already created in Pax Store
   - The `Customer` of the product must be registerd in Pax Store
   - `CustomerProduct` contract must be completed and the related `CustomerFinanceAgreement`  approved
   - `CustomerProduct` all `CustomerMid` must be approved
2. For each product (terminal) will invoke the function **`PaxService@createPaxTerminal`** to start process the creation of terminals in Pax Store

#### Process Description For Creating Terminals In Pax Store
When the function `createPaxTerminal` is invoked from the `PaxService` service the following actions will be taken
1. Fisrt we fetch the terminal modal name `A920Pro` and the terminal location `$terminal->customerLocations()->withPivot(['customer_mid_id'])->first()`
2. Then we prepare the payload that we will send to Pax Store to create the terminal


    | Field          | Value                                      |
    |----------------|--------------------------------------------|
    | location       | Terminal location name                    |
    | merchantName   | pax_merchant_name of the  `Customer`   |
    | modelName      | Terminal model name (`A920Pro`, or ``)  |
    | name           | Terminal (`CustonerProduct`) name|
    | resellerName   | pax_reseller_name from customer partner |
    | status         | PaxStoreApiService::STATUS_PENDING        |
    | tid            | terminal (`CustomerProduct`) `tid`  |

3. We will invoke the function `PaxStoreApiService@createTerminal`, which create a terminal by sending a `POST` request with the provided `data` to the `/terminals` endpoint of the Pax Store service. then return the `id` of the created terminal.
4. Update the terminal (`CustomerProduct`)  `pax_terminal_id` with the return `id` and set `pax_status` to `PAX_STATUS_NEW`
5. After the terminal is created, we will trigger three main actions:
   - [Creating terminal variables createTerminalVariables()](#creating-terminal-variables)
   - [Pushing Positive Plus Manager App to the terminal pushPositivePlusManagerAppToTerminal()](#pushing-positive-plus-manager-app-to-the-terminal)
   - [Pushing Positive Plus App to the terminal pushPositivePlusAppToTerminal()](#pushing-positive-plus-app-to-the-terminal)
6. At the end we return the terminal(`CustomerProduct`) instance

#### Creating Terminal Variables
When the function `createTerminalVariables` is invoked it triggers the following actions
1. We fetch the `CustomerMid` from the `CustomerLocation`
2. Fetch the virtual account id from the `CustomerMid` `BamboraSubmerchat`s that are approved. If not found an exception will be thrown
3. We fetch the terminal address from the `CustomerLocation` instance
4. Using the above data we have fetched we will generate an array that contains terminal variables

   | Key                          | Type | Value                                    | Remarks | Package Name                          |
   |------------------------------|------|------------------------------------------|---------|---------------------------------------|
   | ADDR4                        | T    |                                          |         | self::POSITIVE_PLUS_PACKAGE_NAME      |
   | ADDR3                        | T    | $terminalAddress->postcode               |         | self::POSITIVE_PLUS_PACKAGE_NAME      |
   | ADDR2                        | T    | $terminalAddress->city                   |         | self::POSITIVE_PLUS_PACKAGE_NAME      |
   | ADDR1                        | T    | $terminalAddress->getFullStreetAddress() |         | self::POSITIVE_PLUS_PACKAGE_NAME      |
   | ADDR0                        | T    | $customerName                            |         | self::POSITIVE_PLUS_PACKAGE_NAME      |
   | MID                          | T    | $terminalVirtualAccountId                |         | self::POSITIVE_PLUS_PACKAGE_NAME      |
   | STID                         | T    | $terminal->tid                           |         | self::POSITIVE_PLUS_PACKAGE_NAME      |
   | app.config.theme.usecustom   | T    | Y                                        |         | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |
   | app.colors.primaryColor      | T    | $partner->paxb_primary_color ?? '#307aff'|         | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |
   | app.colors.primaryVariantColor | T  | $partner->paxb_primary_variant_color ?? '#307aff' |  | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |
   | app.colors.onPrimaryColor    | T    | $partner->paxb_primary_font_color ?? '#FFFFFF'  | | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |
   | app.colors.secondaryColor    | T    | $partner->paxb_secondary_color ?? '#307aff'  | | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |
   | app.colors.secondaryVariantColor | T | $partner->paxb_secondary_variant_color ?? '#307aff' | | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |
   | app.colors.onSecondaryColor  | T    | $partner->paxb_secondary_font_color ?? '#FFFFFF'  | | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |
   | app.colors.actionBarColor    | T    | $partner->paxb_action_bar_color ?? '#307aff'  | | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |
   | app.colors.onActionBarColor  | T    | $partner->paxb_action_bar_font_color ?? '#FFFFFF' | | self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME |


6. If customer of that terminal has `amex_mid` is set we will append the amex varibales

   | Key         | Type | Value                         | Remarks | Package Name                       |
   |-------------|------|-------------------------------|---------|------------------------------------|
   | AMEXMID     | T    | $terminal->customer->amex_mid |         | self::POSITIVE_PLUS_PACKAGE_NAME   |

8. then we invoke the function `PaxStoreApiService@createTerminalVariables` by passing the  terminal `tid` and the list of the variables `variables`, which create a terminal  variable by sending a `POST` request with the provided `data` to the `/terminalVariables` endpoint
9. If the variables are created then we will update the terminal (CustomerProduct) `status` to `PAX_STATUS_VARIABLES_CREATED`
10. At the end we return the terminal `CustomerProdcut`

#### Pushing Positive Plus Manager App To the Terminal
When the function `pushPositivePlusManagerAppToTerminal` is invoked it triggers the following actions
1. First we fetch the `Partner` following logo images `splashlogo` , `headerLogo` and `receiptLogo`; if some logo not found we fallback to the related logo in `s3`
2. Then we encode each file with `base64` and push the encoded content to the `files` list
   - **Action Bar Logo**
   
   | Key       | Value                            | Description                                     |
   |-----------|----------------------------------|-------------------------------------------------|
   | pid       | app.images.actionbar.logo.file    | The PID in template                             |
   | fileName  | action_bar_logo.png                   | The parameter of file type, file name containing suffix |
   | fileData  | $fileContent                     | The parameter of file type, file base64 data    |

   - **Receipt Logo**
   
   | Key       | Value                            | Description                                     |
   |-----------|----------------------------------|-------------------------------------------------|
   | pid       | app.images.receipt.logo.file     | The PID in template                             |
   | fileName  | receipt_logo.png                   | The parameter of file type, file name containing suffix |
   | fileData  | $fileContent                     | The parameter of file type, file base64 data    |
   
   - **Splash Logo**
   
   | Key       | Value                            | Description                                     |
   |-----------|----------------------------------|-------------------------------------------------|
   | pid       | app.images.splash.logo.file      | The PID in template                             |
   | fileName  | splashlogo.png                   | The parameter of file type, file name containing suffix |
   | fileData  | $fileContent                     | The parameter of file type, file base64 data    |

   - **Application whitelist** we fetch it content from the `s3` path `pax_store/application_whitelist.txt`
   
   | Key       | Value                            | Description                                     |
   |-----------|----------------------------------|-------------------------------------------------|
   | pid       | app.param.whitelist.file      | The PID in template                             |
   | fileName  | application_whitelist.txt                   | The parameter of file type, file name containing suffix |
   | fileData  | $fileContent                     | The parameter of file type, file base64 data    |

   - **Config resource file** we fetch it content from the `s3` path `pax_store/config_resource_file.zip`
   
   | Key       | Value                            | Description                                     |
   |-----------|----------------------------------|-------------------------------------------------|
   | pid       | posplus.resource.conf      | The PID in template                             |
   | fileName  | config_resource_file.zip                   | The parameter of file type, file name containing suffix |
   | fileData  | $fileContent                     | The parameter of file type, file base64 data    |

   - **Resource file** we fetch it content from the `s3` path `pax_store/resource_file.zip`
   
   | Key       | Value                            | Description                                     |
   |-----------|----------------------------------|-------------------------------------------------|
   | pid       | term.resource.conf               | The PID in template                             |
   | fileName  | resource_file.zip         | The parameter of file type, file name containing suffix |
   | fileData  | $fileContent                     | The parameter of file type, file base64 data    |

   - **Theme resource file** we fetch it content from the `s3` path `pax_store/theme_resource_file.zip`
   
   | Key       | Value                            | Description                                     |
   |-----------|----------------------------------|-------------------------------------------------|
   | pid       | term.theme.conf                  | The PID in template                             |
   | fileName  | theme_resource_file.zip         | The parameter of file type, file name containing suffix |
   | fileData  | $fileContent                     | The parameter of file type, file base64 data    |
   
3. We fetch the template to be used from the `pax_store_api` configuration, specifically from `positive_plus_manager_push_template`.
4. Invoke the function `PaxStoreApiService@pushAppToTerminal` with the following parameters:
   - `packageName`: `self::POSITIVE_PLUS_MANAGER_PACKAGE_NAME`
   - `tid`: `$terminal->tid`
   - `templateName`: `$templateName`
   - `base64FileParameters`: `$files`
   - `version`: `config('api.pax_store_api.positive_plus_manager_app_version')`
   - When invoked we build the payload we will send based on the given params then we  send a `POST` request with the provided `data` to the `/terminalApks` endpoint

      | Key                        | Value                 |
      |----------------------------|-----------------------|
      | packageName                | $packageName          |
      | tid                        | $tid                  |
      | templateName               | $templateName ?? null|
      | parameters                 | null                 |
      | base64FileParameters       | $base64FileParameters ?? null|
      | app.config.theme.usecustom | 'Y'                   |
      | usecustom                  | 'Y'                   |
      | config.theme.usecustom     | 'Y'                   |
      | app.colors.primaryColor    | '#2596be'             |
      | primaryColor               | '#873e23'             |
      | colors.primaryColor        | '#873e23'             |
     
   - If response status is not `201` a `PaxStoreException` exception will be thrown
   - If the `id` does not exist with the response data a `PaxStoreException` exception will be thrown
   - At the end we return `true`
5. We update the terminal(`CustomerProduct`) `status` `PAX_STATUS_POSITIVE_PLUS_MANAGER_APP_PUSHED`

#### Pushing Positive Plus App To The Terminal
When the function `pushPositivePlusAppToTerminal` is invoked it triggers the following actions
1. Fisrt we prepare the initial configuration for the **Positive Plus App**

   | Setting                              | Value |
   |--------------------------------------|-------|
   | config_file_1_sale_enabled           | 1     |
   | config_file_1_refund_enabled         | 1     |
   | config_file_1_reversal_enabled       | 1     |
   | config_file_1_preauth_enabled        | 0     |
   | config_file_1_completion_enabled     | 0     |
   | config_file_1_moto_enabled           | 0     |
   | config_file_1_amex_supported         | 0     |
   | config_file_1_gratuity_enabled       | 0     |
   | config_file_1_gratuity_percentage_1  | 0     |
   | config_file_1_gratuity_percentage_2  | 5     |
   | config_file_1_gratuity_percentage_3  | 10    |
   | config_file_1_gratuity_percentage_4  | 15    |
   | config_file_1_gratuity_percentage_5  | 20    |
   | config_file_1_v9_endpoint_url       | config('api.pax_store_api.positive_plus_app_endpoint_url') |
   
2. If the terminal(`CustomerProduct`) has the `is_moto_active` `true` we will append `config_file_1_moto_enabled = 1` to the configuration payload
3. If the terminal(`CustomerProduct`) has the `is_gratuity_active` `true` we will append `config_file_1_gratuity_enabled = 1` to the configuration payload
4. If the Customer of the terminal has `amex_mid` is set, we append `config_file_1_amex_supported = 1` to the configuration payload
5. Invoke the function `PaxStoreApiService@pushAppToTerminal` with the following parameters:
   - `packageName`: `self::POSITIVE_PLUS_PACKAGE_NAME`
   - `templateName`: self::POSITIVE_PLUS_APP_TEMPLATE_NAME
   - `tid`: `$terminal->tid`
   - `version`: `config('api.pax_store_api.positive_plus_app_version')`
   -  parameters: $parameters
   -  When invoked we build the payload we will send based on the given params then we  send a `POST` request with the provided `data` to the `/terminalApks` endpoint
      | Key                        | Value                 |
      |----------------------------|-----------------------|
      | packageName                | $packageName          |
      | tid                        | $tid                  |
      | templateName               | $templateName ?? null|
      | parameters                 | $parameters ?? null  |
      | base64FileParameters       |  null                 |
      | app.config.theme.usecustom | 'Y'                   |
      | usecustom                  | 'Y'                   |
      | config.theme.usecustom     | 'Y'                   |
      | app.colors.primaryColor    | '#2596be'             |
      | primaryColor               | '#873e23'             |
      | colors.primaryColor        | '#873e23'             |

6. We update the terminal(`CustomerProduct`) `status` `PAX_STATUS_POSITIVE_PLUS_APP_PUSHED`
