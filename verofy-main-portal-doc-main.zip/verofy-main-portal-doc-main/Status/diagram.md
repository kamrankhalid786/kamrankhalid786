```mermaid
graph TD
    %% Registration process
    PRE_REGISTRATION[PRE_REGISTRATION<br>Seller not completed] -->|"createNewRegistration"| AWAITING_MERCHANT_COMPLETION[AWAITING_MERCHANT_COMPLETION<br>Customer not completed]
    AWAITING_MERCHANT_COMPLETION -->|"updateRegistrationById"| AWAITING_SHAREHOLDER_COMPLETION[AWAITING_SHAREHOLDER_COMPLETION<br>Shareholder not completed]
    AWAITING_SHAREHOLDER_COMPLETION -->|"registrationCompletionV1"| AWAITNG_SITE_VISIT[AWAITNG_SITE_VISIT<br>Site visit not completed]
    AWAITNG_SITE_VISIT -->|"registrationCompletionV1"| ONBOARDING_COMPLETE[ONBOARDING_COMPLETE<br>Application in review]

    %% Activation process
    ONBOARDING_COMPLETE -->|"completeRegistrationShareholderKyc"| AWAITING_ACTIVATION[AWAITING_ACTIVATION]
    AWAITING_ACTIVATION -->|"handle"| KYC_REFER[KYC_REFER<br>KYC referred]
    KYC_REFER -->|"completeRegistrationShareholderKyc"| REFERRED_APPLICATION[REFERRED_APPLICATION<br>Application referred]

    %% Information request process
    REFERRED_APPLICATION -->|"handle"| ADDITIONAL_INFORMATION_REQUESTED[ADDITIONAL_INFORMATION_REQUESTED<br>Additional information requested]
    ADDITIONAL_INFORMATION_REQUESTED -->|"updateCustomerAddressV1"| AWAITING_MID[AWAITING_MID<br>Awaiting MID]
    AWAITING_MID -->|"updateRuleStatus"| MID_APPROVED[MID_APPROVED<br>MID assigned]

    %% Underwriting process
    MID_APPROVED -->|"generateEnrollmentXml"| APPLICATION_WITH_UNDERWRITING[APPLICATION_WITH_UNDERWRITING<br>Application with underwriting]
    APPLICATION_WITH_UNDERWRITING -->|"handleUpdateUnderwritingQuery"| APPLICATION_WITH_UNDERWRITING_QUERY[APPLICATION_WITH_UNDERWRITING_QUERY<br>Application with query]
    APPLICATION_WITH_UNDERWRITING_QUERY -->|"handleUpdateUnderwritingQuery"| APPLICATION_WITH_UNDERWRITING_INFORMATION_REQUEST[APPLICATION_WITH_UNDERWRITING_INFORMATION_REQUEST<br>Underwriting - Information request]

    %% Terminal process
    APPLICATION_WITH_UNDERWRITING_INFORMATION_REQUEST -->|"handleUpdateUnderwritingQuery"| TERMINAL_ORDERED[TERMINAL_ORDERED<br>Awaiting dispatch]
    TERMINAL_ORDERED -->|"onProductOrdered"| TERMINAL_DISPATCHED[TERMINAL_DISPATCHED<br>Dispatched]
    TERMINAL_DISPATCHED -->|"onTerminalDispatched"| TERMINAL_FAILED_DELIVERY[TERMINAL_FAILED_DELIVERY<br>Delivery failed]
    TERMINAL_FAILED_DELIVERY -->|"customerDeliveryLogisticsDataService"| TERMINAL_DELIVERED[TERMINAL_DELIVERED<br>Delivered]

    %% Transaction process
    TERMINAL_DELIVERED -->|"onTerminalDelivered"| MERCHANT_NOT_TRANSACTED[MERCHANT_NOT_TRANSACTED<br>Customer not transacted]
    MERCHANT_NOT_TRANSACTED -->|"listTransactions"| MERCHANT_DECLINED[MERCHANT_DECLINED<br>Application declined]
    MERCHANT_DECLINED -->|"firstDataReportService"| CUSTOMER_ON_HOLD[CUSTOMER_ON_HOLD<br>On hold]
    CUSTOMER_ON_HOLD -->|"APCustomerOnHoldUpdateController"| PRE_REGISTRATION
```