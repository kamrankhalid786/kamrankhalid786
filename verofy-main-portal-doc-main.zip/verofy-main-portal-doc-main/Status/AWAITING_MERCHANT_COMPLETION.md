# Awaiting_Merchant_Completion [![Version 1.0](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

```mermaid
flowchart TD
    A[updateRegistrationById] -->|calls| B[findRegistration]
    B -->|returns| C{PreRegistration Found?}
    C -->|no| D[Throw ApiNotFoundException]
    C -->|yes| E[updateRegistration]
    E --> F[Check if address section updated]
    F -->|yes| G[updateDataAttribute > 'has_valid_google_address', false]
    G --> H[Make GoogleMapsApiService]
    H --> I[validateGoogleAddress]
    F -->|no| J[Check if setup complete]
    J -->|yes| K[initAuth]
    K --> L[Make CustomerService]
    L --> M[Make CustomerOperationLogService]
    M --> N[Make CustomerApplicantsService]
    N --> O[Make CustomerUsersService]
    O --> P[Make CustomerProductsService]
    P --> Q[Make CustomerCardRatesService]
    Q --> R[Make CustomerMidService]
    R --> S[Make CustomerContractService]
    S --> T[Make CustomerFinanceService]
    T --> U[Make SignPackService]
    U --> V[Make VerofyToVtigerService]
    V --> W[Make CustomerStandardFeesService]
    W --> X[Make MessagingEventsService]
    X --> Y[completeWebPortalRegistration]
    Y --> Z[Return success response with CustomerApplicationResource]
    Y --> AA[completeWebPortalRegistration]
    AA --> AB[validatePreRegistrationBeforeCompletion]
    AB --> AC[DB::beginTransaction]
    AC --> AD[createNewCustomerFromPreRegistration]
    AD --> AG[Associate customer with pre-registration]
    AD --> AE[createCustomer]
    AE --> AF[Set OverallStatus = Awaiting_Merchant_Completion]
```

## UpdateCustomerRegistrationApplicationController.php

```php
public function updateRegistrationById(string $appRegistrationId, UpdateRegistrationRequest $request): JsonResponse
{
    $preRegistration = $this->findRegistration($appRegistrationId);

    if (!$preRegistration) {
        throw new ApiNotFoundException('Registration not found.');
    }

    $preRegistration = $this->updateRegistration($appRegistrationId, $request);
    $message = 'Customer registration record has been successfully updated.';

    // Validate Google address once the address section is updated.
    $isAddressSectionUpdated = Arr::get($request, 'data.address_section_updated', false);
    if ($isAddressSectionUpdated) {
        $preRegistration->updateDataAttribute('has_valid_google_address', false);
        $this->googleMapsApiService = App::make(GoogleMapsApiService::class);
        $this->validateGoogleAddress($preRegistration);
    }

    $isSetupComplete = Arr::get($request, 'call_setup_complete', false);
    if ($isSetupComplete) {
        $this->initAuth();
        // Load all services.
        $this->customerService = App::make(CustomerService::class);
        $this->customerOperationLogService = App::make(CustomerOperationLogService::class);
        $this->customerApplicantsService = App::make(CustomerApplicantsService::class);
        $this->customerUsersService = App::make(CustomerUsersService::class);
        $this->customerProductsService = App::make(CustomerProductsService::class);
        $this->customerCardRatesService = App::make(CustomerCardRatesService::class);
        $this->customerMidService = App::make(CustomerMidService::class);
        $this->customerContractService = App::make(CustomerContractService::class);
        $this->customerFinanceService = App::make(CustomerFinanceService::class);
        $this->signPackService = App::make(SignPackService::class);
        $this->verofyToVtigerService = App::make(VerofyToVtigerService::class);
        $this->customerStandardFeesService = App::make(CustomerStandardFeesService::class);
        $this->messagingEventsService = App::make(MessagingEventsService::class);

        $this->completeWebPortalRegistration($this->authPreRegistration);
        $message = 'Portal part of the registration has been successfully completed.';
    }

    return $this->success(
        CustomerApplicationResource::make($preRegistration),
        $message
    );
}
```

```php
private function completeWebPortalRegistration(CustomerApplication $preRegistration): Customer
{
    // Validate data.
    $this->validatePreRegistrationBeforeCompletion($preRegistration);

    try {
        DB::beginTransaction();

        $customer = $this->customerService->createNewCustomerFromPreRegistration($preRegistration);

        // Create addresses.
        $this->customerService->createInitCustomerAddresses($customer, $preRegistration);

        // Update proof of address flag for LTD if needed.
        if ($customer->isLimitedCompany() && $customer->hasSameTradingAndLegalAddress()) {
            $customer->has_proof_of_trading_address = false;
            $customer->save();
        }

        // Create basic auth account.
        $mainCustomerUser = $this->customerUsersService->createBasicAccountFromPreregistration($customer);

        // Create accounts for all shareholders.
        $this->createShareholdersAccounts($customer);

        // Add products.
        $this->customerProductsService->importCustomerProductsFromPreRegistration(
            $customer,
            Arr::get($preRegistration->data, 'contract_length'),
            Arr::get($preRegistration->data, 'products_services_selection')
        );

        // Approve products immediately.
        $this->customerProductsService->approveInitialProducts($customer);

        // Create main location.
        $this->customerService->createInitCustomerLocation($customer);

        // Sync card rates.
        $cardRateSets = Arr::get($preRegistration->data, 'selected_card_rates.form_rate_set'); // Array simulates more card rates sets (possible in the future)
        foreach ($cardRateSets as $set) {
            $customerCardRateSet = $customer->cardRatesSets()
                ->where('card_rates_type_id', Arr::get($set, 'set_id'))
                ->first();

            if ($customerCardRateSet === null) {
                continue;
            }

            // Check active fee setting.
            $oneFeeOnly = CardRatesTypeModel::getTypeOneFeeOnly(Arr::get($set, 'set_id'));
            // $activeFee = $oneFeeOnly ? Arr::get($set, 'active_fee') : 'all';
            $activeFee = 'all'; // Auth + transaction fee is now enabled for all card rates types
            $groupAuthFee = Arr::get($set, 'authorisation_fee_group');
            $transactionFeeNotAvailable = Arr::get($set, 'transaction_fee_not_available', false);
            $authorisationFeeNotAvailable = Arr::get($set, 'authorisation_fee_not_available', false);

            $this->customerCardRatesService->importCardRatesFromPreRegistration(
                $customerCardRateSet,
                Arr::get($set, 'annual_turnover', 0),
                Arr::get($set, 'form_rate_group'),
                $activeFee,
                $groupAuthFee,
                $transactionFeeNotAvailable,
                $authorisationFeeNotAvailable
            );
        }

        // Generate initial MIDs.
        $this->customerMidService->generateInitCustomerMids($customer);

        // Generate initial contracts.
        $this->customerContractService->generateInitialContracts($customer);

        // Generate initial finance agreements.
        $this->customerFinanceService->generateInitialFinanceAgreements($customer);

        // Create initial sign pack.
        $this->signPackService->createInitialPack($customer, $mainCustomerUser);

        // Sync standard fees.
        $this->customerStandardFeesService->importCustomerStandardFeesFromPreRegistration(
            $customer,
            Arr::get($preRegistration->data, 'standard_fees_selection')
        );

        // Sync MID fees.
        $customerCardRateSets = $customer->cardRatesSets()->get();
        foreach ($customerCardRateSets as $customerCardRateSet) {
            $this->customerCardRatesService->importMidFeesFromPreRegistration(
                $customerCardRateSet
            );
        }

        // Log customer operation.
        $this->customerOperationLogService->logOperation($customer, CustomerOperation::PORTAL_REGISTRATION_COMPLETED);

        // Send sms to main contact.
        if ($preRegistration->is_reopen) {
            $this->messagingEventsService->processCustomerNeedsToCompleteResetRegistration($customer);
        } else {
            $this->messagingEventsService->processCustomerNeedsToCompleteRegistration($customer);
        }

        // Set KYC requested timestamp.
        $mainApplicant = $customer->getMainApplicant();
        $mainApplicant->kyc_requested_at = Carbon::now();
        $mainApplicant->save();

        // Log customer operation.
        $this->customerOperationLogService->logOperation($customer, CustomerOperation::MAIN_APPLICANT_PROMPTED_TO_COMPLETE_KYC);

        // Set site visit flag based on the pre-registration data.
        $customer->is_site_visit_required = $customer->isSiteVisitRequired();
        $customer->save();

        // Send site visit required notification to the seller if needed.
        if ($customer->is_site_visit_required) {
            $this->messagingEventsService->processSellerCustomerSiteVisitRequired($customer);
        }

        DB::commit();

        // At this stage the customer can be synchronized with Vtiger.
        $customer->is_syncable = true;
        $customer->saveQuietly(); // Save without triggering the observer.

        // Dispatch the job to sync the customer with Vtiger straight away.
        SyncVtigerCustomerJob::dispatch($customer->id);

        // Mark the seller as active if needed.
        $seller = $customer->seller;
        if (empty($seller->active_since)) {
            $seller->active_since = Carbon::now();
            $seller->save();

            $this->messagingEventsService->processSystemNewSellerActive($customer);
        }

    } catch (ApiValidationException $exception) {
        DB::rollBack();

        LogService::log(
            LogCode::CUSTOMER_PORTAL_REGISTRATION_EXCEPTION,
            message: 'Complete web portal registration exception',
            exception: $exception
        );

        throw $exception;
    } catch (\Throwable $exception) {
        DB::rollBack();

        LogService::log(
            LogCode::CUSTOMER_PORTAL_REGISTRATION_EXCEPTION,
            message: 'Complete web portal registration exception',
            exception: $exception
        );

        // Re-throw exception.
        throw new ApiFailedException('Unable to complete the registration', identUserMessage: false);
    }

    return $customer;
}
```

```php
public function createNewCustomerFromPreRegistration(CustomerApplication $preRegistration)
{
    $preRegistration->loadMissing('partner');
    $preRegistration->loadMissing('seller');
    $preRegistrationData = $preRegistration->data;

    // Create new customer record
    $customer = $this->createCustomer(
        partner: $preRegistration->partner,
        seller: $preRegistration->seller,
        createdAt:  $preRegistration->created_at,
        status: CustomerStatus::AWAITING_MAIN_COMPLETION,
        businessType: CustomerApplication::convertCompanyTypeToBusinessType(
            Arr::get($preRegistrationData, 'company_type'),
            Arr::get($preRegistrationData, 'partnership_type', null)
        )?->getValue()
    );

    // Associate the customer with pre-registration
    $customer->customerApplication()->associate($preRegistration);

    // Associate the pre-registration with newly created customer
    $preRegistration->customer()->associate($customer);
    $preRegistration->save();

    // Parse business establishment date
    $merchantStartedTrading = Arr::get($preRegistrationData, 'merchant_started_trading');
    $customer->business_establishment_date = !empty($merchantStartedTrading)
        ? Carbon::parse($merchantStartedTrading)->format('Y-m-d')
        : null;

    // Update common attributes
    $estTurnoverPeriod = Arr::get($preRegistrationData, 'estimated_turnover_period', 'monthly');
    $estTurnover = Arr::get($preRegistrationData, 'estimated_turnover', 0);
    $customer->pre_registration_id = $preRegistration->id;
    $customer->description_of_goods = Arr::get($preRegistrationData, 'description_of_goods');
    $customer->est_annual_turnover = ($estTurnoverPeriod === 'monthly') ? $estTurnover * 12 : $estTurnover;
    $customer->est_atv = Arr::get($preRegistrationData, 'estimated_atv');
    $customer->possible_atv = Arr::get($preRegistrationData, 'possible_atv');
    $customer->highest_anticipated_transaction_amount = Arr::get($preRegistrationData, 'highest_anticipated_transaction_amount');
    $customer->cp_trn_percentage = Arr::get($preRegistrationData, 'card_present_transactions', 0);
    $customer->cnp_trn_percentage = Arr::get($preRegistrationData, 'card_not_present_transactions', 0);
    $customer->has_proof_of_trading_address = !empty(Arr::get($preRegistrationData, 'proof_of_address', null));
    $customer->has_valid_google_address = $preRegistration->has_valid_google_address;
    $customer->is_sdi_mode_active = $preRegistration->is_sdi_mode_active;
    $customer->is_vat_registered = Arr::get($preRegistrationData, 'vat_registered', false);
    $customer->website_url = Arr::get($preRegistrationData, 'website');
    $customer->boarding_additions = [
        'goods_or_services_list' => collect(Arr::get($preRegistrationData, 'goods_or_services_list', []))
            ->map(function($item) {
                return [
                    'name' => Arr::get($item, 'name'),
                    'percentage' => Arr::get($item, 'percentage')
                ];
            })->toArray(),
        'deposits' => Arr::get($preRegistrationData, 'deposits'),
        'deposits_individual_sales' => Arr::get($preRegistrationData, 'deposits_individual_sales'),
        'deposits_average' => Arr::get($preRegistrationData, 'deposits_average'),
        'deposits_days_between_delivery' => Arr::get($preRegistrationData, 'deposits_days_between_delivery'),
        'deposits_days_between_balance_payment' => Arr::get($preRegistrationData, 'deposits_days_between_balance_payment'),
        'upfront_payments' => Arr::get($preRegistrationData, 'upfront_payments'),
        'upfront_payments_days_between_delivery' => Arr::get($preRegistrationData, 'upfront_payments_days_between_delivery'),
        'seasonal_payments' => Arr::get($preRegistrationData, 'seasonal_payments'),
        'guarantees_warranty' => Arr::get($preRegistrationData, 'guarantees_warranty'),
        'quarantees_warranty_explanation' => Arr::get($preRegistrationData, 'quarantees_warranty_explanation'),
        'third_party' => Arr::get($preRegistrationData, 'third_party'),
        'recently_taken_over_business' => Arr::get($preRegistrationData, 'recently_taken_over_business'),
        'business_acquired_at' => Arr::get($preRegistrationData, 'business_acquired_at'),
        'traded_under_different_entity' => Arr::get($preRegistrationData, 'traded_under_different_entity'),
        'traded_under_different_entity_type' => Arr::get($preRegistrationData, 'traded_under_different_entity_type'),
        'traded_under_different_entity_from' => Arr::get($preRegistrationData, 'traded_under_different_entity_from'),
        'traded_under_different_entity_to' => Arr::get($preRegistrationData, 'traded_under_different_entity_to'),
        'start_trading_at' => Arr::get($preRegistrationData, 'start_trading_at'),
        'location_of_sale' => Arr::get($preRegistrationData, 'location_of_sale'),
    ];
    $customer->save();

    // Store additional settings
    $customer->settings()->update([
        'is_amex_required' => !empty(Arr::get($preRegistrationData, 'is_amex_mid_available', null))
    ]);

    // Add VAT registration validation log.
    $externalData = $customer->externalData;
    $externalData->google_address_validation_log = Arr::get($preRegistration->validation_results, 'google_address');
    $externalData->vat_validation_log = Arr::get($preRegistration->validation_results, 'vat_registration');
    $externalData->save();

    // Continue based on the business type
    if ($customer->getBusinessType() === BusinessType::SOLE_TRADER()) {
        // SOLE TRADER
        $this->completeSoleTraderPreRegistration($customer, $preRegistration);
    } elseif ($customer->getBusinessType() === BusinessType::PARTNERSHIP()) {
        // PARTNERSHIP
        $this->completePartnershipPreRegistration($customer, $preRegistration);
    } else {
        // LIMITED COMPANY
        $this->completeCompanyPreRegistration($customer, $preRegistration);
    }

    return $customer;
}
```

```php
public function createCustomer(Partner|null $partner = null, Seller|null $seller = null, string $contactEmail = null, string $contactPhoneNumber = null, Carbon|null $createdAt = null, int $status = null,int $businessType = null): Customer 
{
    // Load default partner.
    $partner = $partner ?? Partner::first();
    $seller = $seller ?? $partner->sellers()->first();

    $customer = new Customer();
    $customer->primary_contact_email = $contactEmail;
    $customer->primary_contact_phone = $contactPhoneNumber;
    $customer->status = $status ?? CustomerStatus::AWAITING_MAIN_COMPLETION;
    $customer->overall_status = CustomerOverallStatus::AWAITING_MERCHANT_COMPLETION;
    $customer->overall_status_updated_at = Carbon::now();
    $customer->business_type = $businessType;
    $customer->payment_provider = PaymentProvider::PAYMENT_IQ;
    $customer->partner()->associate($partner);
    $customer->seller()->associate($seller);
    $customer->language()->associate(Language::getDefault());
    $customer->currency()->associate(Currency::getDefault());
    $customer->save();

    // ------------------------------------------------------------
    // create external Data - one row for every customer
    // ------------------------------------------------------------
    $externalData = new CustomerExternalData();
    $externalData->customer()->associate($customer);
    $externalData->save();
    // ------------------------------------------------------------

    // Check auto decision setting.
    $isAutoDecisionDisabled = (
        empty($partner->auto_decision_enabled_from)
        || $partner->auto_decision_enabled_from->gt(Carbon::now())
    );

    // Create settings
    $customer->settings()->create([
        'send_overall_status_notification_to_customer' => false,
        'is_auto_decision_enabled' => !$isAutoDecisionDisabled
    ]);

    // Generate hash
    $hash = Str::random(25);
    $externalData = $customer->externalData;
    $externalData->registration_hash = $hash;
    $externalData->customer()->associate($customer);
    $externalData->save();

    // Log customer operation.
    $this->customerOperationLogService->logOperation(
        $customer,
        CustomerOperation::NEW_REGISTRATION,
        '',
        $createdAt ?? Carbon::now()
    );

    return $customer;
}
```
