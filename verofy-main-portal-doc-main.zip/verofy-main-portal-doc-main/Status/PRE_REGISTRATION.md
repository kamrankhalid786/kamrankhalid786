# PRE_REGISTRATION [![Version 1.0](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

```mermaid
graph TD
    createNewRegistration[createNewRegistration] --> store[store]
    store -->|type == 'registration'| setPreRegistrationStatus[setPreRegistrationStatus]
    setPreRegistrationStatus --> createRegistration[createRegistration]
    store -->|type != 'registration'| createRegistration1[QUOTE_STATUS_NEW]
    createRegistration --> save[save]
```

## Controller: StoreCustomerRegistrationApplicationController.php
```php
public function createNewRegistration(CreateNewRegistrationRequest $request): JsonResponse
{
    $preRegistration = $this->store($request, 'registration');
    return $this->success(
        CustomerApplicationResource::make($preRegistration),
    );
}
```

```php
private function store(CreateNewRegistrationRequest $request, string $type): CustomerApplication
{
    $partner = Partner::find($request->input('partner_id'));

    // Try to load seller from the logged-in user.
    $seller = null;
    if (Auth::check()) {
        $user = Auth::user();
        $seller = $user->seller;
    }

    $preRegistration = $this->createRegistration($type, $partner, $seller);
    // Get the fee services.
    $feeService = new FeesService();
    $preRegistration->standardFees = StandardFeeResource::collection($feeService->getStandardFees($partner->id));

    return $preRegistration;
}
```

```php
private function createRegistration($type, Partner|null $partner =  null,
Seller $seller = null): CustomerApplication
{
    // Load default partner / seller.
    if ($partner === null) {
        $partner = Partner::getDefaultPartner();
    }

    if ($seller === null) {
        $seller = $partner->sellers()->first();
    }

    $preRegistration = new CustomerApplication();
    $preRegistration->app_registration_id = Str::uuid();
    $preRegistration->status = $type == 'registration' ? CustomerApplication::STATUS_NEW : CustomerApplication::QUOTE_STATUS_NEW;
    $preRegistration->overall_status = $type == 'registration' ? CustomerOverallStatus::PRE_REGISTRATION : null;
    $preRegistration->mode = $type == 'registration' ? CustomerApplication::MODE_PREREGISTRATION : CustomerApplication::MODE_QUOTE;
    $preRegistration->data = CustomerApplication::PROGRESS_STEPS;
    if ($partner instanceof Partner) {
        $preRegistration->partner()->associate($partner);
    }
    if ($seller instanceof Seller) {
        $preRegistration->seller()->associate($seller);
    }
    $preRegistration->save();

    return $preRegistration;
}
```