# Awaiting_Shareholder_Completion [![Version 1.0](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

```mermaid
graph TD
    A[registrationCompletionV1] --> B[initAuthFromRegistrationCode]
    B --> C[getCustomerFromRegistrationCode]
    C -->|customer found| D[getCustomerUserCustomerFromRegistrationCode]
    C -->|customer not found| E[forbidden]
    D --> F[check additional KYC]
    F -->|additional KYC active| G[completeKyc]
    F -->|additional KYC not active| H[completeRegistration]
    G --> I[success]
    H -->|is_main_user| J[completeRegistrationMainApplicantKyc]
    H -->|not is_main_user| K[completeRegistrationShareholderKyc]
    J --> I
    K --> L[completeRegistrationShareholderKyc]
    L --> M[setDefaultCustomer]
    M --> N[mark applicant as KYC done]
    N --> O[log customer operation]
    O --> P[onShareholderKycCompleted]
    P --> Q[completeCustomerAction]
    Q --> R[updateCustomerOverallStatus]
    R -->|shareholders KYC completed| S[all shareholders completed]
    R -->|site visit required| T[site visit outstanding]
    R -->|onboarding completed| U[onboarding completed]
    S --> V[messagingEventsService: processCustomerKycCompletedShareholdersOutstanding]
    T --> W[messagingEventsService: processCustomerKycCompletedSiteVisitOutstanding]
    U --> X[messagingEventsService: processCustomerRegistrationComplete]
    X --> Y[messagingEventsService: processSellerCustomerRegistrationCompleted]
    Y --> Z[return customer]
    E -->|exception| AA[invalid]
    AA --> AB[fail]
```

## CRCompletionController.php

```php
public function registrationCompletionV1(Request $request)
{
    // Complete the user registration.
    try {
        $this->initAuthFromRegistrationCode($request);

        $customer = $this->getCustomerFromRegistrationCode($request);
        if (!$customer) {
            return $this->forbidden('Customer for registration code not found');
        }

        $customerUserCustomer = $this->getCustomerUserCustomerFromRegistrationCode($request);

        // Check additional KYC.
        $appAction = $request->get('app_action', null);
        $customerUser = $customerUserCustomer->customerUser;
        $customerApplicant = $customerUser->getCustomerApplicant($customer);
        if (
            $customerApplicant->isAdditionalKycActive
            && ($appAction === CustomerAppAction::CUSTOMER_REGISTRATION_ADDITIONAL_KYC)
        ) {
            $customerAdditionalKycService = app()->make(CustomerAdditionalKycService::class);
            $customerAdditionalKycService->completeKyc($customerApplicant->getAwaitingAdditionalKyc());
            return $this->success();
        }

        $customerRegistrationsService = app()->make(CustomerRegistrationsService::class);
        if ($customerUserCustomer->is_main_user) {
            $customerRegistrationsService->completeRegistrationMainApplicantKyc(
                $customer,
                $customerUserCustomer->customerUser
            );
        } else {
            $customerRegistrationsService->completeRegistrationShareholderKyc(
                $customer,
                $customerUserCustomer->customerUser
            );
        }

        return $this->success();
    } catch (ApiValidationException $e) {
        return $this->invalid($e->getMessage());
    } catch (Exception $e) {
        return $this->fail($e->getMessage());
    }
}
```

```php
public function completeRegistrationShareholderKyc(Customer $customer, CustomerUser $customerUser): CustomerUser
{
    try {
        DB::beginTransaction();

        // Set current customer as the default one.
        $this->customerUsersService->setDefaultCustomer($customerUser, $customer);

        // Mark applicant as KYC done.
        $customerApplicant = $customerUser->getCustomerApplicant($customer);

        // Check KYC already done
        if ($customerApplicant->is_kyc_done) {
            return $customerUser;
        }

        $customerApplicant->is_kyc_done = true;
        $customerApplicant->kyc_completed_at = Carbon::now();
        $customerApplicant->save();

        $this->customerService->onShareholderKycCompleted($customer);

        // Log customer operation.
        $this->customerOperationLogService->logOperation(
            $customer,
            CustomerOperation::KYC_COMPLETED,
            info: 'Applicant: ' . $customerApplicant->full_name,
            customerApplicant: $customerApplicant
        );

        DB::commit();
    } catch (\Throwable $exception) {
        DB::rollBack();

        // Re-throw exception.
        throw $exception;
    }

    return $customerUser;
}
```

```php
public function onShareholderKycCompleted(Customer $customer): Customer
{
    // Try to complete customer.
    $this->completeCustomerAction->handle($customer);

    return $customer->fresh();
}
```

```php
public function handle(Customer $customer): Customer
{
    $this->updateCustomerOverallStatusAction->handle($customer);

    // Check shareholder's KYC completed.
    $incompleteShareholders = $customer->applicants()->shareholder()->where('is_kyc_done', false)->count();
    $shareholdersOutstanding = ($incompleteShareholders > 0);

    // Check seller site visit.
    $isSiteVisitRequired = $customer->isSiteVisitRequired();
    $siteVisitOutstanding = false;
    if ($isSiteVisitRequired) {
        $customerLocation = $customer->locations()->first();
        $siteVisit = $customerLocation->siteVisits()
            ->orderByDesc('id')
            ->first();
        if (!$siteVisit || ($siteVisit->status !== CustomerSiteVisit::STATUS_COMPLETED)) {
            $siteVisitOutstanding = true;
        }
    }

    // All shareholders completed their KYC.
    if ($shareholdersOutstanding) {
        $this->messagingEventsService->processCustomerKycCompletedShareholdersOutstanding($customer);
        // Moved to ChaseMessagingEventsCron postponed by 4 hours
        // $this->messagingEventsService->processSellerCustomerKycCompletedShareholdersOutstanding($customer);
        return $customer;
    }

    // Site visit has been completed.
    if ($siteVisitOutstanding) {
        $this->messagingEventsService->processCustomerKycCompletedSiteVisitOutstanding($customer);
        return $customer;
    }

    // Onboarding completed
    $customer->status = CustomerStatus::AWAITING_ACTIVATION;
    $customer->onboarding_completed_at = Carbon::now();
    $customer->save();

    $this->updateCustomerOverallStatusAction->handle($customer);

    $this->generateInitialBoardingRules($customer);

    // Notify customer and seller
    $this->messagingEventsService->processCustomerRegistrationComplete($customer);
    $this->messagingEventsService->processSellerCustomerRegistrationCompleted($customer);

    return $customer->fresh();
}
```

## Summary of the Process

```mermaid
graph TD
    start[Start] --> updateStatus[Update Customer Overall Status]
    updateStatus --> checkShareholderKyc{Check if Shareholder's KYC is completed}
    checkShareholderKyc -- Yes --> checkSiteVisit{Check if Site Visit is required}
    checkShareholderKyc -- No --> processKycOutstanding[Process KYC Outstanding]
    processKycOutstanding --> end1[End]
    checkSiteVisit -- Yes --> checkSiteVisitStatus{Check Site Visit Status}
    checkSiteVisit -- No --> end2[End]
    checkSiteVisitStatus -- Completed --> end3[End]
    checkSiteVisitStatus -- Not Completed --> processSiteVisitOutstanding[Process Site Visit Outstanding]
    processSiteVisitOutstanding --> end4[End]
```