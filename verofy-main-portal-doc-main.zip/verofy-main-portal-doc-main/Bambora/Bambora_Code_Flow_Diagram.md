# Bambora Code Flow Diagram [![Version 1.0](../Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid

## Simplified Diagram Flow: Generate Enrollment Xml

                            +-------------------------------------------+
                            |Dispatch Bambora > EnrollmentsCron > Job   |
                            +-------------------------------------------+
                                                |
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Run `bamboraEnrollments` Artisan Command    |
                            +-------------------------------------------+
                                                |
                                                |
                                                |
                                                v
                            +--------------------------------------------------+
                            |Call `handle()` method of `BamboraEnrollments Cron`|
                            +--------------------------------------------------+
                                                |
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Call `generateEnrollmentXml()` and `process|
                            |EnrollmentResults()` on `BamboraSubmerchantService`|
                            +-------------------------------------------+
                                                |
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Fetch submerchants ready for enrollment     |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Fetch customer and business address data    |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Generate XML string for each submerchant    |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Add summary to XML                          |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Encrypt and store XML locally               |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------------+
                            |Upload encrypted file to SFTP server and S3 bucket|
                            +-------------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Store unencrypted XML locally and upload to S3 bucket|
                            +-------------------------------------------+

## Simplified Diagram Flow: Process Enrollment Results

                            +------------------------------------------------------+
                            |Fetch files from 'fromBAMBORA' directory on SFTP server|
                            +------------------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Check file extension                        |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Copy file from SFTP server to local disk    |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Process Result XML                          |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Fetch content of file from SFTP server      |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Decrypt content of file                     |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Store decrypted content locally             |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Load XML content into SimpleXML object      |
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +-------------------------------------------+
                            |Convert SimpleXML object to associative array|
                            +-------------------------------------------+
                                                |
                                                |
                                                v
                            +---------------------------------------------------+
                            |Fetch summary, rejections, and approvals from array|
                            +---------------------------------------------------+
