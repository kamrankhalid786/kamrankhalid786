# Flowchart for tracking the statuses when going through the customer onboarding process
**Author:** Anouar

### Ovevriew
During customer onboarding, various entities update their statuses to reflect progress and completion. Below are flowcharts that illustrate the status changes throughout the different stages of the onboarding process.

## Customer onboarding partner (seller) completion flowchart

```mermaid
graph TB
A[PUT /api/v1/customer-registration/customer-registration/customer_application_id]
    A --> C[Customer created]
      C -->|status| D[AWAITING_MAIN_COMPLETION]
      C -->|overall_status| E[AWAITING_MERCHANT_COMPLETION]

    A --> F[CustomerUser created]
      F -->|status| G[STATUS_AWAITING_ACTIVATION]
      F -->|is_kyc_required| H[true]

    A --> I[CustomerProduct created]
      I -->|status| J[ADDED]
      J -->|approve| K[APPROVED]
      I --> L{is_delivery_required}
      L --> |YES| M[CustomerDeliveryPackage Assigned]
      L --> |NO| N[None]

    A --> O[CustomerMid created]
      O -->|status| P[AWAITING_BOARDING]
      O -->|provider_id| Q[BAMBORA]

    A --> R[CustomerContract created]
      R -->|status| S[AWAITING_COMPLETION]

    A --> T[CustomerFinanceAgreement created]
      T -->|status| U[CustomerFinanceStatus::NEW]

    A --> V[SignPack created]
      V -->|status| W[SignPack::STATUS_NEW]
```

## Customer onboarding completion from the customer side flowchart
After the customer applicant has uplaod it KYC documents, now it time to complete his application

```mermaid
graph TB
A[PUT /api/v1/customer-portal/completion]
    A --> B{Is main user ?}
      B -->|YES| C[Complete Main applicant registration]
      B -->|NO| D[Complete share holders registartion]

      C --> E[CustomerApplicant update ]
          E --> |is_kyc_done| F(true)
          E --> |kyc_completed_at| G(current time)

      C --> H[Customer update ]
          H --> |status| I(AWAITING_COMPLETION)
          I -->  |is shareholder kyc completed && site visit not required| J(AWAITING_ACTIVATION)
          H -->  |overall_status| KK{if status AWAITING_COMPLETION}
          KK --> |if customer shareholders KYC not completed|LL(AWAITING_SHAREHOLDER_COMPLETION)
          H -->  |overall_status| K{if status AWAITING_ACTIVATION}
          K --> |KYC borading rule refrred 30 min after onboarding completion| L(KYC_REFER)
          K --> |has referred application | M(REFERRED_APPLICATION)
          K --> |none of the ther condition is true| N(ONBOARDING_COMPLETE)

      C --> O[CustomerBoardingRule with initial customer requirement created ]
          O --> |status| P(STATUS_AWAITING_DATA)
```
## Customer onboarding confirmation and activation from the customer side flowchart

#### Activating the CustomerUser

```mermaid
graph TB
A[PUT /api/v1/customer-portal/pin]
    A --> B[CustomerUser updated ]
      B -->|status| C[STATUS_ACTIVE]
```

 #### Customer confirmation
```mermaid
graph TB
A[PUT /api/v1/customer-portal/confirmation]
    A --> B[CustomerApplicant ]
      B -->C{IS SDI SHAREDHOLDER}
          C --> |is_kyc_done|D(true)
          C --> |kyc_completed_at| E(current time)

      B -->F{IS MAIN APPLICANT}
          F --> G[CustomerUser all sharedholders ]
              G --> |status| H(STATUS_ACTIVE)
              H --> |update| I[CustomerApplicant]
              I --> |is_kyc_done| J(true)
              I --> |kyc_completed_at| K(current time)
```


 ## Handling the Customer boarding using the cron `BoardCustomers` flowchart
```mermaid
graph TB
A[RUN BoardCustomers]
    A --> |Fetches |B[Customer should be boarded ]
      B -->|Fetches| C[CustomerBoardingRule STATUS_AWAITING_DATA]
          C --> D{IS RULE DEPENDENCIES COMPLETED}
              D --> |NO| E( we do nothing just return the rule object)
              D --> |YES| F[STATUS_AWAITING_CHECK]
          F --> G{IS RULE PASSED}
                G --> |NO| H{is manual check enabled for the rule?}
                      H --> |YES| I(STATUS_AWAITING_MANUAL_CHECK)
                      H --> |NO| J(STATUS_DID_NOT_PASS)

                G --> |Yes| K{is auto pass enabled for the rule?}
                      K --> |YES| L(STATUS_PASS)
                      K --> |NO| M(STATUS_AWAITING_MANUAL_CHECK)
   
     L --> N{is all customer rules passed?}
         N --> |NO| O(NONE)
         N --> |YES| P[Customer updated]
            P --> |is_boarded| Q(true)
            P --> |boarded_at| R(current time)
            P --> |status| S(ACTIVE)
            P --> |overall_status| T(AWAITING_MID)
```

 ## Manage Customer Mids Awaiting Boarding using the cron `BoardMidsCron` flowchart

 ```mermaid
graph TB
A[RUN BoardMidsCron]
    A --> |Fetches |B[CustomerMid AWAITING_BOARDING ]
      B --> |fetch fisrt product with given mid| BB[CustomerProduct]
      BB --> |fetch bambora proxy mid| CC[BamboraProxyMid mcc , country code]
      CC -->|Create| C[BamboraSubmerchant]
          C --> |proxy_mid| D[Set from ecom_proxy_mid if product_id in 23,24 or proxy_mid from BamboraProxyMid]
          C --> |pf_account_id| E( Set by 10000000 + $bamboraSubmerchant->id)
          C --> |customer_mid_id| MF[customer mid id]
          C --> |customer_id| CF[customer id]
          C --> |status| F[SUBMERCHANT_STATUS_NEW]

      C --> |update| G(CustomerMid)
          G --> |status| H[AWAITING_MID_ACTIVATION]
```

 ## Managing Bambora Submerchants enrollements using the cron `BamboraEnrollmentsCron` flowchart
```mermaid
graph TB
A[RUN BamboraEnrollmentsCron]
    A --> |GenerateEnrollmentXml|B[Fetches BamboraSubmerchants]
      B -->|Create| C[BamboraEnrollment SUBMERCHANT_STATUS_NEW]
      B --> |Generate| D[XML file for enrollment]
            D --> |Update| E( BamboraSubmerchat)
                  E --> |status| F[SUBMERCHANT_STATUS_PROCESSED]

    A --> |processEnrollmentResults|G[Bambora Service ]
      G -->|Fetch all files to process folder:fromBAMBORA| H[Banmora Results]
          H --> I{IS REJECTIONS EXISTS ?}
            I --> |YES| J[BamboraSubmerchat]
                J --> |approved| K(0)
                J --> |rejection_code| Ll(reason_code from bambora response)
     
          H --> L{IS APPROVAL EXISTS ?}
             L --> |YES| M[BamboraSubmerchat]
                M --> |approved| N(true)
                M --> |virtual_account_id| O(virtual_account_id from bambora response)
                M --> |For each approved BamboraSubmerchat| P[CustomerMid]
                    P --> |mid| Q(combined values of submerchant pf_account_id and proxy_mid)
                    P --> |status| R(MID_APPROVED)
                    R --> |Dispatch| MU(CustomerMidApproved Event)
                    MU --> |Update VT if exists and current APPROVED | S(CustomerProduct)
                        S --> |status| T(DISPATCHED)
                    MU --> |Update PBLif exists and current APPROVED | U(CustomerProduct)
                        U --> |status| W(DISPATCHED)
                    MU --> |Update| X(Customer)
                        X --> |overall_status| Y(MID_APPROVED)
                    MU --> |Dispacth| Z(Send Finance Agreements to FIRST DATA => next flowchar)
```

 ## Send Finance Agreement using the cron `SendFinanceAgreementsCron` flowchart

 ```mermaid
graph TB
A[RUN SendFinanceAgreementsCron]
    A --> |Fetches |B[CustomerFinanceAgreement NEW OR READY_TO_SEND_DATA ]
          B --> C{status}
          C --> |NEW| D(prepareAgreementToBeSent)
              D --> F(Generate Signed Finance Agreement file)
              D --> G(Generate Additonal details file)
              D --> |If Customer has valid google addr|H(Generate google addres file)
              D --> |update| I[CustomerFinanceAgreement]
              I --> |status| J(READY_FOR_AUDIT_TRAIL)
              D --> |update| K(SignPack)
              K --> |status| L(STATUS_READY_FOR_AUDIT_TRAIL)
              L --> | Dispatch| LL[SignCustomerDocumentsCronJob]
              LL --> |Generate| LE[Evevlop Doc]
              LE --> |Update| LS[SignPack]
              LS --> |status| LSC(STATUS_COMPLETED)
              LSC --> | Fetch | LF[CustomerFinanaceAgreement READY_FOR_AUDIT_TRAIL]
              LF --> |status| LR(READY_TO_SEND_DATA)
              LR --> |Dispacth| LRS(SendFinanceAgreementsCron)
          C --> |READY_TO_SEND_DATA| E(sendToFinanceCompany)
              E --> EE{first_data_staus}
              EE --> |FIRST_DATA_STATUS_NEW| M( Prepare data we will send to First Data )
                  M --> |send to First-Data|N( return ID)
                  N --> |update| O(CustomerFinanceAgreement)
                  O --> |first_data_id| P(return ID)
                  O --> |first_data_status| Q(FIRST_DATA_STATUS_API_SENT )

              EE --> |FIRST_DATA_STATUS_API_SENT| R(fetch docs FianceAgreement  ID , additional data, proof of addr ..etc)
              R --> |Send by email| S(succeed)
              S --> |update| T[CustomerFinanceAgreement]
                    T --> |first_data_status| U(FIRST_DATA_STATUS_EMAIL_SENT)
                    T --> |satus| V(PENDING)
```

 ## Check first data approval reports `CheckFirstDataApprovalReportsCron` flowchart

  ```mermaid
graph TB
A[RUN CheckFirstDataApprovalReportsCron]
    A --> |Connect with Imap |B[Outlook incoming_reports]
      B -->|Fetches| C[Messages from fdgladmin@fiserv.com]
          C --> |Upload reports| D[Attachement to s3]
      D --> |retrieve and store with| E(FirstDataApprovalReportRow set status to REPORT_PROCESS_STATUS_NEW)
            E --> |Fetches the stored reports| F[Start Processing]
            F --> |Fecth| G[Customer]
            G --> H{IS FOUND ?}
            H --> |NO| I[FirstDataApprovalReportRow update and skip]
                I --> |process_status| J(REPORT_PROCESS_STATUS_FAILED)
                I --> |process_message| K(MESSAGE_CUSTOMER_NOT_FOUND)
            H --> |YES| L[CustomerFinanceAgreement Fetched base on contract and customer id]
                L --> M{IS FOUND ? }
                M --> |NO| N[FirstDataApprovalReportRow update and skip]
                    N --> |process_status| O(REPORT_PROCESS_STATUS_FAILED)
                    N --> |process_message| P(MESSAGE_AGREEMENT_NOT_FOUND)
                M --> |YES| Q{FirstDataApprovalReportRow Status}
                    Q --> |NOT EQUAL S or A| R(FirstDataApprovalReportRow update and skip)
                        R --> |process_status| S(REPORT_PROCESS_STATUS_FAILED)
                        R --> |process_message| T(MESSAGE_UNKNOWN_STATUS)

                    Q --> |EQUAL| U(S or A)
                        U --> |On Finance Approved: Update| V[CustomerFinanceAgreement]
                            V --> |status| W(APPROVED)
                            V --> |approved_at| X(current time)

                        U --> |On Finance Approved: Update| Y[Customer]
                            Y --> |overall_status| Z(APPLICATION_APPROVED)

                        U --> |On Finance Approved: Check completion| AA[CustomerContract]
                            AA -->  BB{Check status}
                            BB --> |NOT EQUAL SIGNED| CC[ we return contract and do nothing]
                            BB --> |EQUAL SIGNED| DD{Contract finance agreements all approved ? }
                            DD --> |NO| EE[we return contract and do nothing]
                            DD --> |YES| FF[CustomerContract update]
                            FF --> |status| GG(CONTRACT_COMPLETED)
```

 ## Check first data declined reports `CheckFirstDataDeclinedReportsCron` flowchart

  ```mermaid
graph TB
A[RUN CheckFirstDataDeclinedReportsCron]
    A --> |Connect with Imap |B[Outlook fd_comms]
      B -->|Fetches| C[Messages from INBOX folder]
          C --> |Store with| D(FirstDataDeclinedReport set status to PROCESS_STATUS_NEW)
                D --> E[Create first data case in vtiger]


```

 ## Manage The Merchants Registration in The Pax Store `PaxStoreRegisterMerchants` flowchart

  ```mermaid
graph TB
A[RUN PaxStoreRegisterMerchants]
    A --> |Fetch customers |B[Customer with pax_merchant_id is null]
      B -->|Preparind data| C[Payload data to be sent to pax store]
          C --> |Send to| D(Pax Store API)
                D --> |customer created under paxstore| E[Customer updated]
                E --> |pax_merchant_id| F(ID returned for the created merchant)
                E --> |pax_merchant_name| G(**trading_name**-V9 **customer_id**)
```

 ## Manage The Terminals Creation in The Pax Store `PaxStoreCreateTerminalsCron` flowchart

```mermaid
graph TB
A[RUN PaxStoreCreateTerminalsCron]
    A --> |Fetches| B[CustomerProduct order_code:A920 PRO, A920 PRO WITH SIM, and sttaus APPROVED]
       B -->C[Start creation process]
          C --> |prepare the payload| D[location, merchant name, model name, reseller , status, tid]
                D --> |Send to /terminals | E[Pax Store API]
                E --> |update| F[CustomerProduct]
                    F --> |pax_status| G(PAX_STATUS_NEW)
                    F --> |pax_terminal_id| H(ID returned for the created terminal)
                E --> |Create| I(Terminal variables)
                    I --> |Prepare variables| J(ADDR4,ADDR3,ADDR2,ADDR1,MID, STID...etc)
                    J --> |Send to /terminalVariables| K[Pax Store API]
                    K --> |variables created under pax store| L[CustomerProduct updated]
                    L --> |pax_status| M(PAX_STATUS_VARIABLES_CREATED)
                E --> |Pushing| N(positive plus manager app)
                    N --> |Fetches partner logo files| O(splashlogo,headerLogo,receiptLogo)
                    O --> |Prepare data to be sent| P(packageName,tid,templateName,base64FileParameters...etc)
                    P --> |Send to /terminalApks| Q[Pax Store API]
                    Q --> |positive plus manager app pushed| R[CustomerProduct updated]
                    R --> |pax_status| S(PAX_STATUS_POSITIVE_PLUS_MANAGER_APP_PUSHED)
                E --> |Pushing| T(positive plus app)
                    T --> |Prepare data to be sent| U(config_file_1_sale_enabled,config_file_1_refund_enabled	,config_file_1_reversal_enabled,config_file_1_preauth_enabled...etc)
                    U --> |Send to /terminalApks| V[Pax Store API]
                    V --> |positive plus app pushed| W[CustomerProduct updated]
                    W --> |pax_status| X(PAX_STATUS_POSITIVE_PLUS_APP_PUSHED)
```

 ## Manage The CustomerProduct Order Creation in The Service Logistics `OrderProductsCron` flowchart

  ```mermaid
graph TB
A[RUN OrderProductsCron]
    A --> |Fetch prodcusts |B[CustomerProduct; created in pax store, approved, related contract completed and agreement approved]
      B -->|start process creation by| C[Creating spreadsheet]
          C --> |Add products to| D(Spreadsheet)
                D --> |generate and save the spreadsheet| E[Localy]
                E --> |upload file| F(S3)
                F --> |send file by email| G(Service logistic)
                G --> H{when all the order products sent to service logistic}
                H --> |update| I[CustomerProduct]
                    I --> |status| J(ORDERED)
                H --> |update| K[Customer]
                    K --> |overall_status| L(TERMINAL_ORDERED)
                H --> |update| M[CustomerDeliveryPackage]
                    M --> |status| N(STATUS_ORDER_RECEIVED)                
```

 ## Manage The Import of the Delivery Logistics Data `CustomerDeliveryLogisticsCron` flowchart

  ```mermaid
graph TB
A[RUN CustomerDeliveryLogisticsCron]
    A --> |Fetch all delivery logistic files from | B[S3]
      B -->|start process creation by| C[Creating spreadsheet]
          C --> |parse the file| D(ParserName, `VerofyPOD`, `VerofyDespatches`, `VerofyAllocations`, `VerofySwap`)
                D --> |VerofyPOD| E[Parse CSV file to array]
                    E --> |Fetch latest tid|F[DeliveryServiceLogistics]
                    F --> G{IS OLD VERSIOB}
                    G --> |YES| H(skip)
                    G --> |No| I(Status from file)
                    I --> |prepare DeliveryServiceLogistics model data| J(created_date, mid,tid,carrier_reference, state,message, file, updated_date_from_pod_file)
                    J --> |create| K[DeliveryServiceLogistics]
                    K --> L{status ?}
                    L --> M[DELIVERED]
                        M --> |update| NN(CustomerProduct)
                        NN --> |delivered_at| OOO(delivery time)
    
                        M --> |update| N(CustomerDeliveryPackage)
                        N --> |delivered_at| O(delivery time)
                        N --> |status| OO(STATUS_DELIVERED)
    
                        M --> |update| P[Customer]
                        P --> |overall_status| Q(TERMINAL_DELIVERED)
                    L --> R[FAIL]
                    R --> S(notify customer that the terminal is not delivered)
                    L --> T[IN_TRANSIT]
                    T --> U(notify customer that the terminal is in transit)
                    T --> |update| V[CustomerDeliveryPackage]
                        V --> |status| W(STATUS_IN_TRANSIT)

                D --> |VerofyDespatches| X[Parse CSV file to array]
                    X --> |prepare DeliveryServiceLogistics model data| Y(created_date, mid,tid,serial_number,carrier_reference, state, file)
                    Y --> |create| YY[DeliveryServiceLogistics]
                    YY --> |update| Z[CustomerProduct]
                        Z --> |status| AA(DISPATCHED)
                        Z --> |serial_number| BB(serial_number from file data)
                        Z --> |dispatched_at| CC(dispatched date from file data)
                    YY --> |update| ZZ[Customer]
                        ZZ --> |overall_status| DD(TERMINAL_DISPATCHED)
                    YY --> |update| HH[CustomerDeliveryPackage]
                        HH --> |status| MM[STATUS_READY_FOR_COLLECTION]
                        HH --> |tracking_number| MMM[carrier_reference from file data]

                D --> |VerofyAllocations| A_X[Parse CSV file to array]
                    A_X --> |prepare DeliveryServiceLogistics model data| A_Y(created_date, mid,tid,serial_number, state, file)
                    A_Y --> |create| A_YY[DeliveryServiceLogistics]
                    A_YY --> |update| A_Z[CustomerDeliveryPackage]
                        A_Z --> |status| A_MM[STATUS_PACKED_FOR_SHIPMENT]

                D --> |VerofySwap| S_X[Parse csv file to array]
                    S_X --> |prepare DeliveryServiceLogistics model data| S_A_Y(created_date, mid,tid,serial_number, state, file)
                    S_A_Y --> |create| S_A_YY[DeliveryServiceLogistics]
                    S_A_YY --> S_A_Z[No status changes triggered]
```

 ## Manage Customer Product Live state  `SetProductsLiveCron` flowchart

```mermaid
graph TB
A[RUN SetProductsLiveCron]
    A --> |Fetch products |B[CustomerProduct for active customer, DISPATCHED, and with pax code, VT, or PBL]
      B -->|call transaction service| C[Transactions results]
          C --> |total_amount greater or equals 15 update| D(CustomerProduct only applies to charging cradle ??)
                D --> |status| E[LIVE_TRN_THIS_MONTH]
                D --> |live_at| F(set to transaction date)
```
