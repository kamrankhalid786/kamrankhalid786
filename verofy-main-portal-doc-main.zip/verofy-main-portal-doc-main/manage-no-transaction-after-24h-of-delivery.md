
## Manage No Transaction Has Been Done After 24 Hours of Delivery: `CheckNoPaymentTakenCustomersCronJob`

**Author:** Anouar

### Overview
After we have delivered the terminal to the customer, we have a scheduled job **`CheckNoPaymentTakenCustomersCronJob`** that runs daily at `8:00 pm` within `local` and `production` environments. This job triggers the cron **`CheckNoPaymentTakenCustomersCron`** which checks if the customer accepted any transaction using that terminal after `24` hours of delivery.

### Code Process

1. Invoke the function `TransactionsServiceApiService@listTransactions` to fetch all the transactions from the **Transaction Service**.
2. From the returned results, filter down the transactions that have `total_count` set to `0`, then return the `customer_id` of the filtered list (customers that made transactions).
3. Fetch all `Customer` records that are not in the given list (customers that did not transact) after `24 hours` of delivery.
4. For each customer, notify their **Seller** that the customer did not transact within `24 hours` of delivery.
5. Update `Customer` `overall_status` to `MERCHANT_NOT_TRANSACTED`.
