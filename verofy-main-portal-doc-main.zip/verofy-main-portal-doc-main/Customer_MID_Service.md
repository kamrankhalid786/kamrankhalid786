# MID Boarding Process [![Version 1.0](Version/v.1.0.svg)](https://github.com/kamran-khalid-v9/kamran-khalid-v9)

**Author:** Kamran Khalid | [Code Execution Flow](Customer_MID_Service.txt)

## Table of Contents

- [Introduction](#introduction)
- [Code Flow Diagram](#code-flow-diagram)
- [Kernel Configuration](#kernel-configuration)
- [Job: BoardMidsCronJob](#job-boardmidscronjob)
- [Command: customer-mids:board](#command-customer-midsboard)
- [Business Logic](#business-logic)
- [Service: CustomerMidService](#service-customermidservice)
  - [Method: boardMids](#method-boardmids)
  - [Method: boardMid](#method-boardmid)
  - [Method: getProxyMid](#method-getproxymid)
  - [Method: awaitingMidActivation](#method-awaitingmidactivation)
- [Manage Customer Mids Awaiting Boarding; Detailed process](https://github.com/kamran-khalid-v9/kamran-khalid-v9/blob/main/manage-customer-mid-awaiting-boarding.md)
### Introduction

This document outlines the process for boarding Merchant Identification Numbers (MIDs) for customers. This process involves creating a Bambora sub-merchant and assigning a proxy MID. The process is initiated by a scheduled job and utilizes several components including a kernel configuration, job, command, and service.

### Code Flow Diagram

```mermaid
graph TD;
  E[CustomerMidService]
  E -->|boardMids| F[Query Builder]
  F -->|filter & get customerMids| G[Array of CustomerMids]
  subgraph "Loop (CustomerMids)"
    G --> H[CustomerMid 1]
    H -->|boardMid called| I[CustomerMidService]
    I -->|getProxyMid| J[BamboraProxyMid]
    J -->|create BamboraSubmerchant| K[BamboraSubmerchant]
    K -->|awaitingMidActivation| L[CustomerMid]
    L -->|update status| M[Database]
  end
```

### Kernel Configuration

The `BoardMidsCronJob` is scheduled to run every 5 minutes on local, staging, and production environments. It runs without overlapping for 10 seconds and is executed on a single server.

| Property | Value |
| --- | --- |
| Scheduler Job Name | `BoardMidsCronJob` |
| Environments | `local` `staging` `production` |
| Frequency | Every 5 minutes from the 1st to the 59th minute of each hour |
| Overlapping | Prevented, with a 10-minute threshold |
| Server Execution | Runs on only one server |

### Job: `BoardMidsCronJob`

The `BoardMidsCronJob` is responsible for triggering the `customer-mids:board` artisan command.

```php
public function handle(): void
{
    Artisan::call('customer-mids:board');
}
```

### Command: `customer-mids:board`

The `customer-mids:board` command retrieves the customer ID (optional) from the arguments and calls the `boardMids` method of the `CustomerMidService`.

```php
public function handle()
{
    // Retrieve arguments.
    $customerId = $this->argument('customerId');

    // Board MIDs.
    $this->customerMidService->boardMids($customerId);
}
```

### Business Logic

The `CustomerMidService` handles the core logic of the MID boarding process.

#### Service: `CustomerMidService`

##### Method: `boardMids`

This method retrieves MIDs that need to be boarded based on their status and customer ID (optional). It then iterates through each MID and calls the `boardMid` method.

```php
public function boardMids($customerId = null)
{
    // Find MIDs that needs to be boarded.
    $query = CustomerMid::query()
        ->hasActiveCustomer()
        ->where('status', CustomerMidStatus::AWAITING_BOARDING);

    // Filter specific customer if needed.
    if ($customerId !== null) {
        $query->where('customer_id', $customerId);
    }

    $customerMids = $query->get();
    foreach ($customerMids as $customerMid) {
        $this->boardMid($customerMid);
    }
}
```

##### Method: `boardMid`

This method attempts to board the given MID by calling the `getProxyMid` method from the `BamboraSubmerchantService`. If successful, it updates the MID status to `AWAITING_MID_ACTIVATION`. If an exception occurs, it sets the customer's attention required flag and logs the error.

```php
public function boardMid(CustomerMid $customerMid)
{
    try {
        $this->bamboraSubmerchantService->getProxyMid($customerMid);

        // Update status.
        $this->awaitingMidActivation($customerMid);
    } catch (Exception $e) {
        $this->setAttentionRequired($customerMid->customer);

        LogService::log(LogCode::MID_BOARDING_EXCEPTION, [
            'customer_id' => $customerMid->customer->id,
            'issue' => 'Unable to create Bambora MID',
            'issue_type' => BoardingIssueModel::CREATE_BAMBORA_MID_ERROR,
            'exception' => $e
        ]);
    }
}
```

##### Method: `getProxyMid`

This method retrieves the appropriate proxy MID for the given customer based on their business address and MCC code. It then creates a new Bambora sub-merchant with the retrieved proxy MID and saves it. Finally, it returns the proxy MID.

```php
public function getProxyMid(CustomerMid $customerMid)
{
    // ... logic for retrieving proxy MID based on customer details ...

    $bamboraSubmerchant = new BamboraSubmerchant();
    // ... set Bambora sub-merchant properties ...
    $bamboraSubmerchant->save();
    $bamboraSubmerchant->pf_account_id = 10000000 + $bamboraSubmerchant->id;
    $bamboraSubmerchant->save();
    return $proxyMidRow->proxy_mid;
}
```

| Field | Value |
| --- | --- |
| `customer_id` | `$customer->id` |
| `customer_mid_id` | `$customerMid->id` |
| `proxy_mid` | `$proxyMid` |
| `approved` | `null` |
| `status` | `self::SUBMERCHANT_STATUS_NEW` |
| `pf_account_id` | `10000000 + $bamboraSubmerchant->id` |

##### Method: `awaitingMidActivation`

This method updates the given MID's status to `AWAITING_MID_ACTIVATION` and saves it.

```php
public function awaitingMidActivation(CustomerMid $mid)
{
    $mid->status = CustomerMidStatus::AWAITING_MID_ACTIVATION;
    $mid->save();
}
```
